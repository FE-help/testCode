<template>
  <el-dialog
    :title="title"
    :visible.sync="dialogVisible"
    width="600px"
    :before-close="handleClose"
    :modal-append-to-body="true"
    append-to-body
  >
    <div class="wrapper">
      <div class="plan">
        <div class="plan-title">选择：</div>
        <div class="tab">
          <div class="tab-title" v-if="onlyType == ''">
            <span
              :class="type == 1 ? 'active' : ''"
              @click="changeList('type', 1)"
              >角色</span
            >
            <span
              :class="type == 2 ? 'active' : ''"
              @click="changeList('type', 2)"
              >成员</span
            >
          </div>
          <div class="approvers">
            <div>
              <el-input
                v-show="type == 1"
                placeholder="输入角色名"
                v-model="filterApprovers"
                clearable
              ></el-input>
              <el-input
                v-show="type == 2"
                placeholder="输入姓名"
                v-model="filterNotifiers"
                clearable
              ></el-input>
              <el-tree
                :load="loadNode"
                v-loading="loading"
                lazy
                :class="onlyType != '' ? 'filter-tree' : ''"
                :props="defaultProps"
                default-expand-all
                show-checkbox
                node-key="id"
                :default-checked-keys="defaultCheck"
                :filter-node-method="filterNode"
                @check="handleCheckChange1"
                ref="approvers"
              ></el-tree>
            </div>
          </div>
        </div>
      </div>
      <div :span="11" class="plan">
        <div class="plan-title">已选：</div>
        <div class="child">
          <div class="checklist">
            <el-row v-if="roleList.length > 0">
              <el-col :span="6">
                <span>角色:</span>
              </el-col>
              <el-col :span="16">
                <div
                  class="check-list"
                  v-for="(item, index) in roleList"
                  :key="index"
                >
                  <span>{{ item.name }}</span>
                  <i
                    class="el-icon-circle-close"
                    @click="removeList('roleList', item)"
                  ></i>
                </div>
              </el-col>
            </el-row>
            <el-row v-if="userList.length > 0">
              <el-col :span="6">
                <span>成员:</span>
              </el-col>
              <el-col :span="16">
                <div
                  class="check-list"
                  v-for="(item, index) in userList"
                  :key="index"
                >
                  <span>{{ item.name }}</span>
                  <i
                    class="el-icon-circle-close"
                    @click="removeList('userList', item)"
                  ></i>
                </div>
              </el-col>
            </el-row>
          </div>
        </div>
      </div>
    </div>
    <div>
      <slot></slot>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" @click="save">保 存</el-button>
    </span>
  </el-dialog>
</template>

<script>
import apiApproval from "@/api/apiApproval";
export default {
  name: "",
  mixins: [],
  extends: {},
  components: {},
  props: {
    //题目
    title: {
      type: String,
      default: "选择"
    },
    //已选成员或角色
    formData: {
      type: Object,
      default: () => {
        return {
          roleList: [],
          userList: []
        };
      }
    },
    //只展示角色 1; 只展示成员 2;  两个都显示 ''
    onlyType: {
      type: String,
      default: "2"
    },
    isRadio: {
      type: Boolean,
      default: false
    },
    memberNo: {
      type: [String, Array],
      default: () => {
        return [];
      }
    },
    flag: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      loading: true,
      editChekcId: "",
      dialogVisible: true,
      filterNotifiers: "",
      filterApprovers: "",
      type: "1",
      defaultProps: {
        children: "children",
        label: "name"
      },
      roleList: [],
      userList: [],
      defaultCheck: []
    };
  },
  watch: {
    filterApprovers(val) {
      this.$refs.approvers.filter(val);
    },
    filterNotifiers(val) {
      this.$refs.approvers.filter(val);
    },
    formData: {
      immediate: true,
      deep: true,
      handler: function(newVal, oldVal) {
        this.roleList = newVal.roleList;
        this.userList = newVal.userList;
        this.$nextTick(() => {
          if (this.onlyType == "2") {
            this.defaultCheck =
              this.userList.length > 0
                ? this.userList.map(item => item.id)
                : [];
          } else {
            this.defaultCheck =
              this.roleList.length > 0
                ? this.roleList.map(item => item.id)
                : [];
          }
        });
      }
    },
    onlyType: {
      immediate: true,
      handler: function(newVal, oldVal) {
        if (newVal == "") {
          return;
        } else {
          this.type = newVal;
        }
      }
    }
  },
  computed: {},
  methods: {
    handleClose() {
      this.roleList = [];
      this.userList = [];
      this.defaultCheck = [];
      this.$emit("close");
    },
    save() {
      let json = {
        roleList: this.roleList,
        userList: this.userList
      };
      this.$emit("save", json);
      if (!this.flag) {
        this.handleClose();
      }
    },
    filterNode(value, data) {
      if (!value) return true;
      return data.name.indexOf(value) !== -1;
    },
    handleCheckChange1(data, checked) {
      console.log(data);
      console.log(checked);
      console.log(this.isRadio);
      if (this.type == 1) {
        if (this.isRadio) {
          let flg = checked.checkedKeys.indexOf(data.id) > -1;
          this.roleList = !flg ? [] : [data];
          this.$refs.approvers.setCheckedNodes(this.roleList);
        } else {
          let list = this.$refs.approvers
            .getCheckedNodes()
            .filter((item, index) =>
              item.type == undefined && item.children == undefined
                ? true
                : false
            );
          this.roleList = list;
        }
      } else {
        if (this.isRadio) {
          let flg = checked.checkedKeys.indexOf(data.id) > -1;
          this.userList = !flg ? [] : [data];
          this.$refs.approvers.setCheckedNodes(this.userList);
        } else {
          let list = this.$refs.approvers
            .getCheckedNodes()
            .filter((item, index) =>
              item.type == undefined && item.children == undefined
                ? true
                : false
            );
          this.userList = list;
        }
      }
    },
    changeList(type, num) {
      this[type] = num;
      if (num == 1) {
        this.$refs.approvers.setCheckedNodes(this.roleList);
      } else {
        this.$refs.approvers.setCheckedNodes(this.userList);
      }
    },
    func(arr) {
      arr.forEach(v => {
        if (v.contacts) {
          if (v.contacts.length !== 0) {
            v.contacts.forEach(val => {
              v.children.push(val);
              this.func(v.children);
              this.treeData = arr;
            });
          }
        }
      });
    },
    async loadNode(node, resolve) {
      this.loading = true;
      let _this = this;
      if (node.level === 0) {
        let res = await apiApproval.organizationList();
        let data = [];
        data.push(res.data.data);
        this.userList = [];
        this.defaultCheck = [];
        if (data[0].contacts.length > 0) {
          let contacts = data[0].contacts.map(j => {
            // j.disabled = j.imAccount == _this.$htgl_user.imAccount
            return j;
          });
          data[0].children = data[0].children.concat(contacts);
          data[0].imAccount = "account" + data[0].id;
        }
        this.loading = false;
        if (this.isRadio) {
          data[0].disabled = !data[0].memberNo;
        }
        if (this.memberNo && this.memberNo.length > 0) {
          data.forEach(item => {
            if (
              item.memberNo &&
              (this.memberNo.indexOf(item.id) > -1 ||
                this.memberNo.indexOf(item.memberNo) > -1)
            ) {
              this.userList.push(item);
              this.defaultCheck.push(item.id);
            }
          });
        }
        return resolve(data);
      } else {
        if (node.data.children) {
          let data = node.data.children;
          data.forEach(item => {
            if (item.contacts && item.contacts.length > 0) {
              let contacts = item.contacts.map(j => {
                // j.disabled = j.imAccount == _this.$htgl_user.imAccount
                return j;
              });
              item.children = item.children.concat(contacts);
            }
            // item.disabled = item.imAccount !== _this.$htgl_user.imAccount ? false : true
            if (this.isRadio) {
              item.disabled = !item.memberNo;
            }
            item.imAccount = item.imAccount
              ? item.imAccount
              : "account" + item.id;
          });
          this.loading = false;
          if (this.memberNo && this.memberNo.length > 0) {
            data.forEach(item => {
              if (
                item.memberNo &&
                (this.memberNo.indexOf(item.id) > -1 ||
                  this.memberNo.indexOf(item.memberNo) > -1)
              ) {
                this.userList.push(item);
                this.defaultCheck.push(item.id);
              }
            });
          }
          return resolve(data);
        } else {
          this.loading = false;
          return resolve([]);
        }
      }
    },
    removeList(type, obj) {
      this[type] = this[type].filter(item => item.id !== obj.id);
      this.$refs.approvers.setCheckedNodes(this[type]);
    }
  },
  created() {},
  mounted() {
    console.log(this.memberNo);
  }
};
</script>
<style lang="scss" scoped>
.wrapper {
  display: flex;
  .plan {
    .plan-title {
      height: 44px;
      line-height: 44px;
      padding-left: 10px;
      color: #666666;
      border-bottom: 1px solid #e4e7ed;
    }
    flex: 1;
    height: 420px;
    border: 1px solid #ccc;
    border-radius: 4px;
    width: 50%;
    &:nth-of-type(2) {
      margin-left: 10px;
    }
    .tab-title {
      display: flex;
      justify-content: center;
      padding: 20px 0 10px 0;
      span {
        display: block;
        text-align: center;
        line-height: 30px;
        width: 50px;
        cursor: pointer;
        border: 1px solid #e4e7ed;
        &:nth-of-type(1) {
          border-radius: 4px 0 0 4px;
        }
        &:nth-of-type(2) {
          border-radius: 0 4px 4px 0;
        }
        &.active {
          border-color: #0286df;
        }
      }
    }
    .tab-title-app {
      height: 30px;
      margin-bottom: 10px;
      display: flex;
      justify-content: center;
      span {
        display: block;
        border: 1px solid #ccc;
        width: 60px;
        line-height: 30px;
        text-align: center;
        cursor: pointer;
        &:nth-of-type(1) {
          border-radius: 4px 0 0 4px;
        }
        &:nth-of-type(2) {
          border-radius: 0 4px 4px 0;
        }
        &.active {
          border-color: #0b9dfe;
        }
      }
    }
    .approvers {
      padding: 10px;
    }
    .notifiers {
      padding: 10px;
    }
    .checklist {
      padding: 10px;
    }
  }
  .approver-type {
    display: flex;
    padding: 20px 0;
    span {
      width: 90px;
      &:before {
        content: "*";
        color: #f56c6c;
        margin-right: 4px;
      }
    }
    div {
      flex: 1;
      /deep/.el-radio {
        display: block;
        margin-bottom: 10px;
      }
    }
  }
  .check-list {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 4px;
    .el-icon-circle-close {
      cursor: pointer;
    }
  }
  /deep/ .el-dialog__body {
    padding: 10px 20px;
  }
  /deep/ .el-tree-node__loading-icon .el-icon-loading {
    font-size: 16px;
  }
  /deep/ .el-tree {
    margin-top: 8px;
    height: 240px;
    overflow-y: auto;
  }
  /deep/ .el-tree-node__loading-icon {
    font-size: 20px;
  }
  /deep/ .el-tree-node__label {
    width: 240px;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
  }
  .filter-tree {
    height: 300px !important;
  }
}
.child {
  max-height: 368px;
  overflow: auto;
}
</style>
