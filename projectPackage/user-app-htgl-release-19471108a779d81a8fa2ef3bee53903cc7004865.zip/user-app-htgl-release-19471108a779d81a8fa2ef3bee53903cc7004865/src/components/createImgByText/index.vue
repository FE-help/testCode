// 根据文字自动生成图片，且文字大小自适应
<template>
  <div v-show="show" ref="box" :style="{color:this.textColor}">
    <canvas
      class="hidden-html"
      :id="canvasId"
      :width="width"
      :height="width"
    ></canvas>
    <img v-if='showImg' :src="imgUrl" alt="" />
    <div
      v-show="!showImg"
      :class="overflow"
      :style="styles"
      class="auto-text"
    >
      <slot>{{text}}</slot>
    </div>
  </div>
</template>

<script>
import apiCompanyService from "@/api/apiCompanyService";

export default {
  name: "auto-text",
  props: {
    // 文本限定宽度, 单位px, 可选, 如果不传, 则默认是父元素宽度
    width: {
      type: Number,
      default: 140
    },
    height: {
      //生成图片的高度
      type: Number,
      default: 140
    },
    // 给定文本, 可选, 如果不传, 则获取插槽内文本, 但无法检测变化
    text: String,
    // 初始默认 font-size 大小, 数字
    size: {
      type: Number,
      default: 48
    },
    // 最小 font-size 大小, 默认是 12 px
    minSize: {
      type: Number,
      default: 12
    },
    // 当文本超出时处理方式, ellipsis 超出省略号, clip 超出截断, break 超出换行
    overflow: {
      type: String,
      default: "clip",
      validator(value) {
        return value === "ellipsis" || value === "clip" || value === "break";
      }
    },
    show: {
      default: false
    },
    canvasId: {
      type: String,
      default: `canvas_${Math.ceil(Math.random(5) * 10000)}`
    },
    textColor: {
      //文字颜色
      type: String,
      default: "#B79255"
    },
    showImg: {
      //展示形式，是否以图片的形式展示（默认为非图片的形式展示，此时会触发生成并上传图片，一般用于编辑页面）
      type: Boolean,
      default: false
    },
    bgColor: {
      //商标背景颜色
      type: String,
      default: "#fff"
    }
  },
  data() {
    return {
      fontSize: this.size,
      styles: {},
      imgUrl: ""
    };
  },
  watch: {
    text: {
      handler: function() {
        this.computeFontsize();
      },
      immediate: true
    },
    show() {
      this.computeFontsize();
    }
  },
  mounted() {
    // this.computeFontsize();
  },
  methods: {
    createTempSpan(str) {
      // 确保类的唯一性
      const className = "get-text-width-" + this._uid;
      const spanNode = document.createElement("span");
      spanNode.innerText = str;
      spanNode.className = className;
      spanNode.style.whiteSpace = "nowrap";
      this.$el.appendChild(spanNode);
      return spanNode;
    },
    removeTempSpan(spanNode) {
      this.$el.removeChild(spanNode);
    },
    getTextWidth(fontSize, spanNode) {
      spanNode.style.fontSize = fontSize + "px";
      return spanNode.offsetWidth;
    },
    computeFontsize() {
      this.$nextTick(() => {
        // 传递过来的文本或者插槽内容
        const text = this.text;
        // 获取宽度
        const width = this.width;
        // 获取最小字体值
        const minSize = this.minSize;
        // 获取字体值
        let fontSize = this.size;
        // 创建临时span
        const spanNode = this.createTempSpan(text);
        // 获取当前字号下占用的宽度
        let textWidth = this.getTextWidth(fontSize, spanNode);
        // 字体占用宽度 > 设置宽度, 且没到最小字体, 则缩小字体
        while (textWidth > width && fontSize > minSize) {
          fontSize = fontSize - 1;
          textWidth = this.getTextWidth(fontSize, spanNode);
        }
        // 移除span
        this.removeTempSpan(spanNode);
        this.fontSize = fontSize;
        this.styles = {
          fontSize: fontSize + "px",
          width: width + "px"
        };
        this.showImg ? this.createImg() : "";
      });
    },
    // 根据商标名称生成图片
    async createImg(ruleForm, callback) {
      if (!this.text || !this.show) return;
      const canvas = document.getElementById(this.canvasId); // 可以理解为一个画笔，可画路径、矩形、文字、图像
      const context = canvas.getContext("2d");
      // 根据图像重新设定了canvas的长宽
      canvas.setAttribute("width", this.width);
      canvas.setAttribute("height", this.height); // 绘制图片
      context.fillStyle = this.bgColor;
      context.fillRect(0, 0, this.width, this.height);
      context.fillStyle = this.textColor; //对画布填充颜色
      context.font = `${this.fontSize}px Microsoft YaHei`;
      context.textAlign = "center";
      context.textBaseline = "middle";
      context.fillText(this.text, this.width / 2, this.height / 2);
      canvas.toBlob(blob => {
        this.imgUrl = window.URL.createObjectURL(blob);
        if (this.showImg) return;
        this.uploadCanvasToServe(blob, ruleForm, callback)
      });
    },
    // 将生成的canvas上传至服务器
    async uploadCanvasToServe(blob,ruleForm, callback) {
      let fd = new FormData();
      fd.append("file", blob, new Date().getTime() + ruleForm.name + ".png");
      let res = await apiCompanyService.uploadImg(fd);
      if (res.data && res.data.code == 200) {
        ruleForm.img = res.data.data || "";
        callback(ruleForm);
      }
    }
  }
};
</script>

<style>
.auto-text {
  display: flex;
  align-items: center;
  justify-content: center;
  /* text-align: center; */
}
.auto-text.clip {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: clip;
}
.auto-text.break {
  word-break: break-word;
}
.auto-text.ellipsis {
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  white-space: nowrap;
}
.hidden-html {
  display: none;
}
</style>
