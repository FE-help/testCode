// 手机号验证
export function isvalidPhone (str) {
  const reg = /^1[1|3|4|5|6|7|8|9][0-9]\d{8}$/
  return reg.test(str)
}
// 身份证号码验证
export function isvalidIdCard (str) {
  const reg = /^([0-9]){7,18}(x|X)?$ 或 ^\d{8,18}|[0-9x]{8,18}|[0-9X]{8,18}?$/
  return reg.test(str)
}
// 姓名

export function isvalidName (str) {
  const reg = /^([\u4e00-\u9fa5]+|([a-z]+\s?)+)$/
  return reg.test(str)
}
// 纯中文名字
export function isChineseName (str) {
  const reg = /[\u4e00-\u9fa5]/
  return reg.test(str)
}

export function isvalidPhone1 (str) {
  const reg = /^\d{11}|\d{20}|-$/
  return reg.test(str)
}
export function bakno (str) {
  const reg = /^\d{6}|\d{30}$/
  return reg.test(str)
}
export function bankName (str) {
  const reg = /^[\u4e00-\u9fa5]+$/
  return reg.test(str)
}
export function contacts1 (str) {
  const reg = /^([\u4e00-\u9fa5]+|([a-z]+\s?)+)$/
  return reg.test(str)
}
export function contactNumber1 (str) {
  const reg = /^\d{11}|\d{20}|-$/
  return reg.test(str)
}
