<template>
  <el-upload
    :action="action"
    :before-upload="beforeAvatarUpload"
    :on-success="handleAvatarSuccess"
    :on-error="uploadError"
    :show-file-list="false"
    element-loading-text="拼命上传中"
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(0, 0, 0, 0.8)"
    >
      <div v-loading="uploadImgLoading" slot="trigger" class="pointer">
        <slot></slot>
      </div>
    <div slot="tip" class="el-upload__tip">{{tip}}</div>
  </el-upload>
</template>
<script>
export default {
  name: "uploadFile",
  data() {
    return {
      action: `${process.env.VUE_APP_API_USER}/file/add`,
      uploadImgLoading:false
    };
  },
  props:{
    tip:{
      type:String,
      default:'支持扩展名：rar .zip .doc .docx .pdf .jpg，最多上传5个文件，每个大小不超过10Mb'
    },
    aceptType: {
      //限制上传图片格式
      type: String
    },
    size: {
      //限制上传图片大小
      type: Number
    },
    width: {
      //限制上传图片宽
      type: Number
    },
    height: {
      //限制上传图片高
      type: Number
    },
    showFileList:{
      type: Boolean,
      default:false
    },
    typeErrorMsg: {
      //格式错误提示
      type: String,
    }
  },
  mounted() {},
  methods: {
    beforeAvatarUpload(file) {
      this.uploadImgLoading = true;
      let istype = true;
      let isSize = true;
      let isWidthAndHeight = true;
      // 限制图片格式
      if (this.aceptType) {
        // let type = file.type.split("/");
        let type = file.name.split(".");
        type = type[type.length - 1] || "";
        type = type.toLowerCase();
        let aceptType = this.aceptType.split(",");
        istype = aceptType.indexOf(type) !== -1;
        if (!istype) {
          this.$message.error(this.typeErrorMsg || `图片支持格式：${aceptType.join("、")}！`);
          this.uploadImgLoading = false;
        }
      }
      if (this.size) {
        // 限制图片大小
        isSize = file.size / 1024 / 1024 < this.size;
        if (!isSize) {
          this.$message.error(`上传图片大小不能超过 ${this.size}MB!`);
          this.uploadImgLoading = false;
        }
      }
      if (this.width && this.height) {
        // 限制图片宽高
        isWidthAndHeight = new Promise((resolve, reject) => {
          let _URL = window.URL || window.webkitURL;
          let image = new Image();
          image.src = _URL.createObjectURL(file);
          image.onload = () => {
            let valid =
              image.width == this.width && image.height == this.height;
            valid ? resolve() : reject(new Error("error"));
          };
        }).then(
          () => {
            return file;
          },
          () => {
            this.$message.error(
              `上传图片尺寸不符合，只能是${this.width}*${this.height}!`
            );
            this.uploadImgLoading = false;
            return Promise.reject(new Error("error"));
          }
        );
      }

      return istype && isSize && isWidthAndHeight;
    },
    handleAvatarSuccess(response, file) {
      if (response.code == 200) {
        this.$emit("uploadSuccess",{
          name:file.name,
          url:response.data,
          size: file.size,
          type: file.raw && file.raw.type
        });
      }
      this.uploadImgLoading = false;
    },
       // 文件上传失败
    uploadError(err, file, fileList) {
      this.$message.error(`文件上传失败`);
      this.uploadImgLoading = false;
    }
  },
};
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
.pointer{
  display: inline-block;
  cursor: pointer;
}
/deep/ .el-upload__tip{
  height: 18px !important;
  line-height: 18px !important;
  // margin-top: -5px;
  color: #969696;
}
/deep/ .upload-container{
  border: 1px dashed #E4E7ED;
}
// .upload-file /deep/ .el-upload__tip{
//   line-height: 22px;
// }
</style>
