/* 多文件分批上传--将所有的文件分成小于服务器设定最大值的list后，分别请求接口
用于当多文件上传时文件总和大小超过后端接口设置的最大值时，接口报错问题 */
<template>
  <div class="uploader-container">
    <el-upload
      multiple
      ref="uploader"
      :auto-upload="false"
      :http-request="addFile"
      :action="action"
      :on-success="handleAvatarSuccess"
      :on-change="fileChange"
      :on-preview="handlePreview"
      :on-remove="handleRemove"
      :before-remove="beforeRemove"
      :on-exceed="handleExceed"
      :limit="limit"
      v-loading="uploadImgLoading"
      :show-file-list="showFileList"
      :list-type="listType"
      :file-list="allFileList"
      :accept="aceptType"
    >
      <div slot="trigger" class="pointer">
        <slot></slot>
      </div>
      <div slot="tip" class="el-upload__tip">{{ tip }}</div>
    </el-upload>
    <el-dialog :visible.sync="dialogVisible" append-to-body>
      <img width="100%" :src="dialogImageUrl" alt="" />
    </el-dialog>
  </div>
</template>
<script>
import apiOrder from "@/api/apiOrder";
export default {
  name: "uploadFile",
  data() {
    return {
      action: `${process.env.VUE_APP_API_USER}/file/add`,
      uploadImgLoading: false,
      // fileFromData: {},
      fromDataList: [], //要上传的文件流数组
      allFileList: [], //所有的文件
      dialogVisible: false,
      dialogImageUrl: "",
      errMsg: {
        //文件上传错误提示
      },
      serveLimitSize: 20 * 1024 * 1024 //服务器限制一次上传文件总大小
    };
  },
  props: {
    tip: {
      type: String,
      default:
        "支持扩展名：rar .zip .doc .docx .pdf .jpg，最多上传5个文件，每个大小不超过10Mb"
    },
    aceptType: {
      //限制上传图片格式
      type: String
    },
    size: {
      //限制上传图片大小
      type: Number
    },
    width: {
      //限制上传图片宽
      type: Number
    },
    height: {
      //限制上传图片高
      type: Number
    },
    showFileList: {
      type: Boolean,
      default: true
    },
    listType: {
      //文件列表的样式。
      type: String,
      default: "text"
    },
    limit: {
      type: Number,
      default: 5
    },
    fileList: {
      type: Array,
      default: () => []
    },
    needUploadTime: {
      //是否需要上传时间
      type: Boolean,
      default: false
    }
  },
  mounted() {
    this.getAllFile();
  },
  methods: {
    // currentFileSize -- 当前文件大小
    // currentFile---当前文件
    getFileFromDataList(currentFileSize, currentFile) {
      let listLenght = this.fromDataList.length;
      let lastIndex = listLenght > 0 ? listLenght - 1 : 0;
      let lastItem = this.fromDataList[lastIndex] || {};
      const { totalSize = 0 } = lastItem;
      if (
        listLenght == 0 ||
        totalSize + currentFileSize > this.serveLimitSize
      ) {
        //超出服务器限制的文件大小则重新请求接口上传文件
        let newItem = {
          totalSize: currentFileSize,
          fileList: [],
          fileFromData: new FormData()
        };
        newItem.fileList.push(currentFile);
        newItem.fileFromData.append("file", currentFile);
        this.fromDataList.push(newItem);
        return;
      }
      lastItem.totalSize = totalSize + currentFileSize;
      lastItem.fileList.push(currentFile);
      lastItem.fileFromData.append("file", currentFile);
    },
    // // 获取所有的文件
    getAllFile() {
      this.allFileList = [...this.fileList];
    },
    // 验证文件是否符合要求
    verifyFile(file) {
      try {
        file = file.raw || {};
        let istype = true;
        let isSize = true;
        let isWidthAndHeight = true;
        // 限制图片格式
        if (this.aceptType) {
          // let type = file.type.split("/");
          //  type = type[1] || "";
          let type = file.name.split(".");
          type = type[type.length - 1] || "";
          type = type.toLowerCase();
          let aceptType = this.aceptType;
          istype = aceptType.indexOf(type) !== -1;
          if (!istype) {
            let aceptTypeList = this.aceptType.split(",");
            this.showErrorMsg(
              `图片支持格式：${aceptTypeList.join("、")}！`,
              "type"
            );
          }
        }
        if (this.size) {
          // 限制图片大小
          isSize = file.size / 1024 / 1024 < this.size;
          if (!isSize) {
            this.showErrorMsg(`上传图片大小不能超过 ${this.size}MB!`, "size");
          }
        }
        if (this.width && this.height) {
          // 限制图片宽高
          isWidthAndHeight = new Promise((resolve, reject) => {
            let _URL = window.URL || window.webkitURL;
            let image = new Image();
            image.src = _URL.createObjectURL(file);
            image.onload = () => {
              let valid =
                image.width == this.width && image.height == this.height;
              valid ? resolve() : reject(new Error("error"));
            };
          }).then(
            () => {
              return file;
            },
            () => {
              this.showErrorMsg(
                `上传图片尺寸不符合，只能是${this.width}*${this.height}!`,
                "widthAndHeight"
              );
              return Promise.reject(new Error("error"));
            }
          );
        }

        let isRight = istype && isSize && isWidthAndHeight;
        isRight ? "" : this.$refs.uploader.abort();
        return isRight;
      } catch (error) {
        console.log("beforeAvatarUpload", error);
      }
    },
    // 错误提示
    showErrorMsg(msg, type) {
      const { type: errType, msg: errMsg } = this.errMsg || {};
      if (type == errType && msg == errMsg) return; //避免同类型的错误重复提示
      this.errMsg = { type, msg };
      this.$message({
        type: "error",
        message: msg,
        showClose: true,
        onClose: () => {
          this.errMsg = {};
        }
      });
    },
    handleAvatarSuccess(response, file, fileList) {
      this.uploadImgLoading = false;
    },
    handleRemove(file, fileList, noUpdateParent) {
      this.allFileList = fileList;
      noUpdateParent ? "" : this.$emit("changeFile", fileList);
    },
    handleExceed(files, fileList) {
      this.$message.warning(
        `当前限制选择 ${this.limit} 个文件，本次选择了 ${
          files.length
        } 个文件，共选择了 ${files.length + fileList.length} 个文件`
      );
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`);
    },
    // // 选择上传文件后
    fileChange(file, fileList) {
      if (this.verifyFile(file)) {
        this.allFileList.push(file);
      } else {
        /*  需要将当前不满足条件的文件在fileList中删除，
        不然在上传组件允许展示file-list的情况下，
        file-list还是会展示当前不满足条件的文件
        */
        let index = fileList.findIndex(item => item.uid === file.uid);
        index !== -1 ? fileList.splice(index, 1) : "";
      }
      this.$emit("changeFile", this.allFileList);
    },
    // 将选中的文件添加到fileList中
    addFile(file) {
      let currentFile = file.file;
      this.getFileFromDataList(currentFile.size, currentFile);
    },
    // 上传文件请求--手动上传
    async uploadRequest() {
      try {
        if (this.allFileList.length == 0) return;
        this.uploadImgLoading = true;
        this.$refs.uploader.submit();
        await this.uploadFileToServe();
      } catch (error) {
        console.log("上传文件请求--uploadRequest", error);
      } finally {
        this.uploadImgLoading = false;
      }
    },
    // 将文件上传到服务器
    uploadFileToServe() {
      let reqList = [];
      this.fromDataList.map((item, index) => {
        let reqItem = this.requestItem(item, index);
        reqList.push(reqItem);
      });
      return Promise.all([...reqList]).then(() => {
        this.setFileData();
      });
    },
    requestItem(item, index) {
      return new Promise((reslove, reject) => {
        apiOrder.uploadFileList(item.fileFromData).then(res => {
          if (res && res.data && res.data.code == 200) {
            this.handleResFile(item, res.data.data || []);
            reslove();
          }
          reject();
        });
      });
    },
    // 处理返回的文件
    handleResFile(item, resFileUrlList) {
      const { fileList } = item;
      let newFileList = [];
      fileList.map((fileItem, fileIndex) => {
        const { name } = fileItem;
        let newFileItem = {
          name: name,
          uploadeTime: this.needUploadTime ? new Date().getTime() : undefined,
          fileUrl: resFileUrlList[fileIndex] || ""
        };
        newFileList.push(newFileItem);
      });
      item.fileList = newFileList;
    },
    setFileData() {
      let fileList = [];
      this.fromDataList.map((item, index) => {
        fileList = fileList.concat(item.fileList);
      });
      this.$emit("uploadSuccess", fileList);
    },
    // 预览
    handlePreview(file) {
      if (this.listType !== "picture-card") return;
      this.dialogImageUrl = file.url || file.fileUrl;
      this.dialogVisible = true;
    }
  }
};
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
.uploader-container {
  display: inline-block;
}
.pointer {
  cursor: pointer;
}
/deep/ .el-upload__tip {
  margin-top: -5px;
  color: #969696;
}
/deep/ .upload-container {
  border: 1px dashed #e4e7ed;
}
/deep/ .el-upload--picture-card {
  line-height: 125px;
}
/deep/ .el-upload-list--picture-card .el-upload-list__item {
  width: 125px;
  height: 125px;
}
</style>
