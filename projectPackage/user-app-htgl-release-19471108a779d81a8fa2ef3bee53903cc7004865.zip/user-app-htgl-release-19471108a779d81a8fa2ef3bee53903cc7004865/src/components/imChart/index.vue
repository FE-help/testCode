<!-- im -聊天 -->
<template>
  <div v-if="imAccount && imToken" class="zjkj-im">
    <zjkj-im
      ref="zjkjImRef"
      v-show="isShowIm"
      :key="random"
      :imAccount="imAccount"
      :imToken="imToken"
      @close="closeIm"
    ></zjkj-im>
  </div>
</template>

<script>
import eventBus from "@/eventBus";
export default {
  name: "Im",
  data() {
    return {
      random: 0,
      isShowIm: false
    };
  },
  computed: {
    userInfo: function() {
      return this.$htgl_user || {};
    },
    imAccount() {
      return this.userInfo.imAccount;
    },
    imToken() {
      return this.userInfo.imToken;
    }
  },
  mounted() {
    this.$nextTick(() => {
      let self = this;
      eventBus.$on("sendImMessage", imAccount => {
        this.isShowIm = true;
        this.$nextTick(() => {
          self.$refs.zjkjImRef.findFriend(imAccount);
        });
      });
    });
  },
  methods: {
    closeIm() {
      this.isShowIm = false;
    }
  }
};
</script>

<style scoped>
.zjkj-im /deep/ .container {
  margin: 0 !important;
  padding: 0;
}
</style>
