<template>
  <el-dialog
    class="contactDialog"
    :title="chartsCompany && chartsCompany.companyName"
    :visible.sync="chartsDialog"
    :before-close="handleClose"
    :close-on-press-escape="false"
    :close-on-click-modal="false"
    width="600px"
  >
    <div v-loading="load" class="charts-container">
      <div class="contact-list" v-for="(item, i) in serveList" :key="i">
        <div class="list-left">
          <img src="@/assets/images/kefu.png" alt />
          <span>{{ item.post }}</span>
        </div>
        <div class="list-right">
          <el-button type="primary" @click="toChat(item.imAccount)"
            >马上沟通</el-button
          >
        </div>
      </div>
      <div v-if="!load && serveList.length === 0" class="noData">
        <img src="@/assets/images/empty.png" />
        <p class="text">店铺还未设置客服人员</p>
      </div>
    </div>
  </el-dialog>
</template>
<script>
import apiCommon from "@/api/apiCommon";
import eventBus from "@/eventBus";
export default {
  name: "Venice",
  data() {
    return {
      // serveList: [],
      load: false
    };
  },
  computed: {
    chartsDialog() {
      return this.$store.state.imChat.chartsDialog || false;
    },
    chartsCompany() {
      let chartsCompany = this.$store.state.imChat.chartsCompany || {};
      return chartsCompany || {};
    },
    serveList() {
      return this.chartsCompany.companyNo
        ? this.$store.state.imChat.companyChartList || []
        : [];
    }
  },
  watch: {
    chartsCompany: {
      handler: function() {
        if (this.chartsCompany.companyNo) {
          this.showContact();
        }
        // else {
        //   this.serveList = [];
        // }
      },
      immediate: true,
      deep: true
    }
    // chartsList: {
    //   handler: function() {
    //     this.serveList = this.$store.state.imChat.companyChartList || []
    //   },
    //   immediate: true,
    //   deep: true
    // }
  },
  methods: {
    handleClose() {
      // this.serveList = [];
      this.$store.commit("SET_CHARTSdIALOG", false);
      this.$store.commit("SET_CHARTS_COMPANY", {});
      this.$store.commit("SET_COMPANY_CHAT_LIST", []);
    },
    async showContact() {
      if (this.serveList && this.serveList.length > 0) return;
      this.load = true;
      let chartsCompany = this.chartsCompany || {};
      this.companyName = chartsCompany.companyName;
      let res = await apiCommon.getIMAccount(chartsCompany.companyNo);
      if (res.data.code === 200) {
        this.$store.commit("SET_COMPANY_CHAT_LIST", res.data.data || []);
      }
      this.load = false;
    },
    //进入聊天
    toChat(imAccount) {
      if (!imAccount) {
        this.$message.error("商家暂不支持聊天");
        return;
      }
      eventBus.$emit("sendImMessage", imAccount);
      this.$store.commit("SET_CHARTSdIALOG", false);
      this.$store.commit("SET_CHARTS_COMPANY", {});
    }
  },
  mounted() {},
  destroyed() {}
};
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
.contactDialog {
  /deep/ .el-dialog__header {
    border-bottom: 1px solid #dfe4ea;
    /*padding: 15px 19px;*/
    /*color: #000000;*/
    /*font-size: 18px;*/
    /*height: 40px;*/
    /*.el-dialog__headerbtn{*/
    /*top: 10px;*/
    /*}*/
    .el-dialog__headerbtn {
      top: 5px !important;
      right: 5px !important;
    }
  }
  /*/deep/ .el-dialog__body{*/
  /*padding: 30px 50px;*/
  .contact-list {
    padding: 5px 0;
    display: flex;
    justify-content: space-between;
    height: 40px;
    line-height: 40px;
    margin-bottom: 30px;
    &:last-child {
      margin-bottom: 0;
    }
    img {
      margin-right: 5px;
      vertical-align: middle;
    }
    .list-left {
      span {
        color: #333333;
      }
    }
    .list-right {
      button {
        background-color: #b79255;
        border-color: #b79255;
      }
    }
  }
  .noData {
    width: 100%;
    margin: 0 auto;
    img {
      width: 100px;
      height: 100px;
      display: block;
      margin: 0 auto;
    }
    p {
      margin-top: 20px;
      font-size: 16px;
      font-weight: 400;
      color: #666;
      line-height: 28px;
      text-align: center;
    }
  }
  /*}*/
}
.charts-container {
  min-height: 250px;
}
</style>
