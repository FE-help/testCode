<template>
  <el-dialog title="新增城市" :visible.sync="dialogVisible" width="600px">
    <div class="dialog-container">
      <ul class="left">
        <el-scrollbar>
          <li
            :class="{
              'active-province':
                selectProvince.id === 100000 ||
                selectCity.findIndex(
                  (cityItem) => cityItem.id == 100000
                ) !== -1,
            }"
            @click="getCityList({id:100000,name:'全国'})"
          >
            全国
          </li>
          <li
            v-for="item in provinceList"
            :key="item.id"
            :class="{
              'active-province':
                selectProvince.id === item.id ||
                selectCity.findIndex(
                  (cityItem) => cityItem.parentId == item.id || cityItem.id == item.id || cityItem.id == 100000
                ) !== -1,
            }"
            @click="getCityList(item)"
          >
            {{ item.name }}
          </li>
        </el-scrollbar>
      </ul>
      <div class="right">
        <el-scrollbar class="city-scrollbar">
          <div class="city-container">
            <span
              v-if="selectProvince.id != 100000"
              class="city-item"
              @click="selectAll"
              :class="{'select-city':selectCity.findIndex(
                    (cityItem) => cityItem.id === selectProvince.id || cityItem.id == 100000
                  ) !== -1}
              "
            >
              全省</span
            >
            <span  
              v-if="selectProvince.id == 100000"
              class="city-item"
              @click="selectCountry"
              :class="{'select-city':selectCity.findIndex(
                    (cityItem) => cityItem.id === selectProvince.id || cityItem.id ==100000
                  ) !== -1}
              ">全国
            </span>
            <span
              v-for="item in cityList"
              class="city-item"
              :class="{
                'select-city':
                  selectCity.findIndex(
                    (cityItem) => cityItem.id === item.id || cityItem.id === selectProvince.id || cityItem.id ==100000
                  ) !== -1
              }"
              :key="item.id"
              @click="cityChange(item)"
            >
              {{ item.name  }}
            </span>
          </div>
        </el-scrollbar>
        <div class="btn-container">
          <p>
            已选择：
            <span class="red-color">{{ selectCity.length }}</span>
            /20
          </p>
          <p>
            <el-button @click="cancel">取消</el-button>
            <el-button type="primary" @click="submit">确定</el-button>
          </p>
        </div>
      </div>
    </div>
  </el-dialog>
</template>

<script type="text/babel">
import apiCommon from "@/api/apiCommon";
export default {
  name: "cityDialog",
  data() {
    return {
      dialogVisible: false,
      provinceList: [],
      cityList: [],
      selectProvince: {},
      selectCity: []
    };
  },
  props: ["fromCity", "allArea"],
  watch: {
    dialogVisible: function() {
      if (this.dialogVisible == true) {
        this.selectCity = this.fromCity
          ? JSON.parse(JSON.stringify(this.fromCity))
          : [];
        this.getDefultShow();
      }
    }
  },
  components: {},
  created() {
    this.getPrc();
  },
  mounted() {},
  methods: {
    // 默认显示的省，（默认显示选中的第一个省，若没有选中的省份，则默认显示所有城市列表中的第一个身份）
    getDefultShow() {
      let provinceItem = { id: 100000, name: "全国" }; //默认显示全国
      if (this.selectCity.length > 0) {
        if (this.selectCity[0].id == 100000) {
          provinceItem = { id: 100000, name: "全国" };
        } else {
          //显示第一个被选中的省份
          let provinceLength = this.provinceList.length;
          for (let i = 0; i < provinceLength; i++) {
            let provinceId = this.provinceList[i].id;
            let hasCity = this.selectCity.some(
              item => provinceId == item.parentId || provinceId == item.id
            );
            if (hasCity) {
              provinceItem = this.provinceList[i];
              break;
            }
          }
        }
      }
      this.getCityList(provinceItem);
    },
    // 获取省
    async getPrc() {
      let res = await apiCommon.getAllAreaList();
      if (res.data && res.data.code == 200) {
        let data = res.data.data || [];
        this.provinceList = data;
        this.getCityList({ id: 100000, name: "全国" }); //默认显示全国
      }
    },
    getCityList(item) {
      this.selectProvince = item;
      this.cityList = item.children || [];
    },
    //全省
    selectAll() {
      const {
        id: provinceId,
        name: provinceName,
        children: citys
      } = this.selectProvince;
      // // 判断是否选中全国，取消选中全国
      let delCountry = this.delCountryAddPro(provinceId);
      if (delCountry) return;
      // 没有选中全国
      let index = this.selectCity.findIndex(item => item.id == provinceId);
      if (index === -1) {
        //当前还未选中全省时，点击选中全省
        // 先去掉selectCity中已经选中的城市，避免重复数据（因为全省已经包含了所有的城市）
        let cityList = citys || [];
        let cityIds = []; //城市id的集合,后端需要值
        cityList.map(item => {
          cityIds.push(item.id);
          let selectIndex = this.selectCity.findIndex(
            selectItem => selectItem.id == item.id
          );
          selectIndex !== -1 ? this.selectCity.splice(selectIndex, 1) : "";
        });
        // 将选中的省份加到选中的数据中
        this.selectCity.push({ id: provinceId, name: provinceName, cityIds });
        // 判断是否选中全国
        this.checkSelectAllProvice();
        return;
      }
      // 当前已经选中全省时，点击取消选中全省
      this.selectCity.splice(index, 1);
    },
    // 选中/取消选中城市
    cityChange(item) {
      const {
        id: provinceId,
        name: provinceName,
        children: citys
      } = this.selectProvince;
      // 选中全国
      let delCountry = this.delCountryAddPro(provinceId, item.id);
      if (delCountry) return;
      // 没有选中全国
      let delProvice = this.delProviceAddCity(provinceId, item.id);
      if (delProvice) return;
      // 当前展示的全省没有被选中，则先判断当前点击的城市是否已经被选中，若是，则取消选中，否，则选中
      let hasItemIndex = this.selectCity.findIndex(
        cityItem => cityItem.id === item.id
      );
      if (hasItemIndex === -1) {
        //未被选中
        this.selectCity.push({
          id: item.id,
          parentId: provinceId,
          name: item.name
        });
        this.checkSelectAll();
        return;
      }
      // 已经被选中
      this.selectCity.splice(hasItemIndex, 1);
    },
    // 判断是否选中全省
    checkSelectAll() {
      const {
        id: provinceId,
        name: provinceName,
        children: citys
      } = this.selectProvince;
      // 当前展示的省已经选中的城市
      let selectCityOfPro = this.selectCity.filter(
        item => item.parentId == provinceId
      );
      if (selectCityOfPro.length === citys.length) {
        // //已经全选,选中数据列表中添加省数据，去掉所有选中的城市数据
        let copySelectCity = JSON.parse(JSON.stringify(this.selectCity));
        copySelectCity.map(cityItem => {
          let selectIndex = this.selectCity.findIndex(
            selectItem =>
              cityItem.id == selectItem.id && selectItem.parentId == provinceId
          );
          if (selectIndex !== -1) {
            this.selectCity.splice(selectIndex, 1);
          }
        });
        let cityIds = citys.map(item => item.id);
        this.selectCity.push({ id: provinceId, name: provinceName, cityIds });
      }
      // 判断是否选中全国
      this.checkSelectAllProvice();
    },
    // 删除当前点击的省份，添加当前省份下面的其他城市
    delProviceAddCity(provinceId, cityId, noProvice) {
      const { children: citys } = this.selectProvince;
      if (noProvice) {
        //当前点击的省份数据已经被删除
        citys.map(cityItem => {
          if (cityItem.id !== cityId) {
            this.selectCity.push({
              id: cityItem.id,
              parentId: provinceId,
              name: cityItem.name
            });
          }
        });
        return true;
      }
      // 当前点击的省份数据还没有被删除
      let proviceIndex = this.selectCity.findIndex(
        cityItem => cityItem.id === provinceId
      );
      if (proviceIndex !== -1) {
        this.selectCity.splice(proviceIndex, 1);
        //已经选中当前展示的全省,取消选中当前点击的城市
        citys.map(cityItem => {
          if (cityItem.id !== cityId) {
            this.selectCity.push({
              id: cityItem.id,
              parentId: provinceId,
              name: cityItem.name
            });
          }
        });
        return true;
      }
      return false;
    },
    // 选中全国
    selectCountry() {
      let selectOne = this.selectCity[0] || {};
      selectOne.id == 100000
        ? (this.selectCity = [])
        : (this.selectCity = [{ id: 100000, name: "全国" }]);
      this.$forceUpdate();
    },
    // 判断是否选中全国
    checkSelectAllProvice() {
      let selectProvice = this.selectCity.filter(item => item.cityIds);
      if (selectProvice.length === this.provinceList.length) {
        //选中全国
        this.selectCity = [{ id: 100000, name: "全国" }];
        return;
      }
    },
    // 取消选中全国，添加其他未点击的所有省份
    delCountryAddPro(provinceId, cityId) {
      // 判断是否选中全国，取消选中全国
      let selectOne = this.selectCity[0] || {};
      if (selectOne.id == 100000) {
        //已经选中全国，则删除selectCity中全国数据，添加除了当前点击的其他所有省份
        this.selectCity.splice(0, 1);
        this.provinceList.map(proviceItem => {
          let cityList = proviceItem.children || [];
          let cityIds = cityList.map(cityItem => cityItem.id);
          if (proviceItem.id !== provinceId) {
            this.selectCity.push({
              id: proviceItem.id,
              name: proviceItem.name,
              cityIds
            });
          }
        });
        if (cityId) {
          this.delProviceAddCity(provinceId, cityId, "noProvice");
        }
        return true;
      }
      return false;
    },
    submit() {
      let length = this.selectCity.length;
      if (length > 20) {
        return this.$message({
          message: "最多选择20个城市！",
          type: "warning"
        });
      }
      this.dialogVisible = false;
      this.$emit("addCity", this.selectCity);
    },
    // 取消
    cancel() {
      this.dialogVisible = false;
      this.selectCity = this.fromCity
        ? JSON.parse(JSON.stringify(this.fromCity))
        : [];
      this.$forceUpdate();
    }
  }
};
</script>
<style lang="scss" rel="stylesheet/scss" scoped>
.dialog-container {
  border-top: 1px solid #e8e8e8;
  margin: -30px -20px;
  display: flex;
}
.el-scrollbar {
  height: 300px;
  width: 100%;
  /deep/ .el-scrollbar__wrap {
    overflow-x: hidden;
    overflow-y: auto;
  }
}
.left {
  width: 155px;
  flex-shrink: 0;
  text-align: center;
  padding: 10px 0 20px 20px;
  border-right: 1px solid #e8e8e8;
  line-height: 40px;
  cursor: pointer;
}
.right {
  flex-grow: 1;
}
.city-container {
  min-height: 219px;
  padding: 20px;
}
.city-scrollbar {
  height: 259px;
}
.city-item {
  display: inline-block;
  height: 30px;
  line-height: 30px;
  padding: 0 15px;
  border: 1px solid #e8e8e8;
  margin: 0 10px 10px 0;
  cursor: pointer;
}
.btn-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  border-top: 1px solid #e8e8e8;
  .el-button {
    width: 80px;
    height: 30px;
    padding: 0;
    line-height: 30px;
  }
}
.red-color {
  color: red;
}
.active-province {
  color: #409eff;
}
.select-city {
  background-color: #409eff;
  color: #fff;
}
</style>
