// 下拉框-选项数据分页加载
<template>
  <el-select     
    v-loadmore="loadMore"
    :loading="loading"
    clearable
    :placeholder="dictPlaceholder"
    v-model="selectVal"
    @change="change"
    @focus="focus"
  >
    <el-option
      v-for="item in options"
      :key="dictProp && dictProp.value ? item[dictProp.value] : item.value"
      :label="dictProp && dictProp.label ? item[dictProp.label] : item.label"
      :value="dictProp && dictProp.value ? item[dictProp.value] : item.value">
    </el-option>
  </el-select>
</template>

<script>
export default {
  name: "PageSelect",
  directives: {
    loadmore: {
      bind: function(el, binding, vnode) {
        const SELECTWRAP = el.querySelector(".el-select-dropdown__list");
        SELECTWRAP.addEventListener("scroll", function() {
          const CONDITION =
            this.scrollHeight - this.scrollTop <= this.clientHeight;
          if (CONDITION) {
            binding.value();
          }
        });
      }
    }
  },
  props: {
    // 列表数据
    options: {
      type: Array,
      default: () => []
    },
    dictProp: {
      type: Object,
      default: () => {}
    },
    dictPlaceholder: {
      type: String,
      default: "请选择"
    },
    // 调用页数的接口
    request: {
      type: Function,
      default: () => {}
    },
    // 传入的页码
    page: {
      type: [Number, String],
      default: 1
    },
    // 是否还有更多数据
    hasMore: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      loading: false,
      selectVal:''
    };
  },
  methods: {
    // 请求下一页的数据
    async loadMore() {
      // 如果没有更多数据，则不请求
      if (!this.hasMore) {
        return;
      }
      // 如果intercept属性为true则不请求数据，
      if (this.loadMore.intercept) {
        return;
      }
      this.loadMore.intercept = true;
      await this.request({
        page: this.page + 1
      });
      this.loadMore.intercept = false;
    },
    // 选中下拉框没有数据时，自动请求第一页的数据
    focus() {
      if (!this.options.length) {
        this.request({ page: 1 });
      }
    },
    change(val){
      this.selectVal = val;
      let item = this.options.find(item => (this.dictProp && this.dictProp.value ? item[this.dictProp.value] : item.value) == val)
      this.$emit('change',item)
    }
  }
};
</script>
