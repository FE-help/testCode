/**
* 适用于模态框温馨提示（成功、警告、失败）
* @authors huangxiaolin
* @date 2021.06.15
* @version 1.0.0
*/
<template>
    <el-dialog
            custom-class="common-modal"
            :title="title"
            :visible.sync="isVisible"
            :width="mWidth"
            :before-close="handleClose"
            :destroy-on-close="isDistory"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
    >
        <div class="con-container">
            <img src="@/assets/images/tips-succ.png" alt="" v-if="mStatus === 'success'">
            <img src="@/assets/images/tips-warn.png" alt="" v-if="mStatus === 'warning'">
            <img src="@/assets/images/tips-err.png" alt="" v-if="mStatus === 'error'">
            <h2 v-html="tipsText"></h2>
        </div>
        <slot name="footer"></slot>
    </el-dialog>
</template>

<script>
export default {
  name: 'CommonModalTips',
  props: {
    title: { // 标题
      type: String,
      require: true,
      default: '温馨提示'
    },
    isVisible: { // 是否展示
      type: Boolean,
      require: true,
      default: false
    },
    mWidth: { // 组件宽度
      type: String,
      require: false,
      default: '600px'
    },
    isDistory: { // 是否销毁
      type: Boolean,
      require: false,
      default: false
    },
    mStatus: { // 组件状态
      type: String,
      require: false,
      default: 'success'
    },
    tipsText: { // 提示内容
      type: String,
      require: true,
      default: ''
    }
  },
  components: {},
  data() {
    return {}
  },
  methods: {
    handleClose() {
      this.$emit('close')
    }
  },
  mounted() {
  }
}
</script>

<style lang="scss" scoped>
/deep/ .common-modal {
  .el-dialog__header {
    padding: 0 15px !important;
    height: 58px !important;
    line-height: 58px;
    background-color: #FFFFFF;
    border-bottom: 1px solid #E4E7ED !important;

    .el-dialog__title {
      color: #000000 !important;
    }
  }

  .el-dialog__body {
    padding: 30px 70px 40px 70px;
  }

  .con-container {
    text-align: center;
    margin-bottom: 38px;

    h2 {
      font-size: 16px;
      color: #969696;
      font-weight: normal;
      margin: 13px 0 0 0;
    }
  }

  .foot-btn-group-blue {
    text-align: center;

    .el-button--default {
      color: #969696 !important;

      &:hover {
        color: #0286DF !important;
        border: 1px solid #0286DF;
        background-color: #FFFFFF;
      }
    }

    .el-button--primary {
      &:hover {
        border: 1px solid #53a8eb !important;
        background-color: #53a8eb !important;
      }
    }
  }

  .foot-btn-group-golden {
    text-align: center;

    .el-button--default {
      color: #969696 !important;

      &:hover {
        color: #B79255 !important;
        border: 1px solid #B79255;
        background-color: #FFFFFF;
      }
    }

    .el-button--primary {
      background-color: #B79255 !important;
      border: 1px solid #B79255 !important;

      &:hover {
        border: 1px solid #be9d66 !important;
        background-color: #be9d66 !important;
      }
    }
  }
}

.m-l-20 {
  margin-left: 20px !important;
}
</style>
