<template>
  <div class="upload-container">
    <el-button :style="{background:color,borderColor:color}" icon="el-icon-upload" size="mini" @click=" dialogVisible=true" class='tool-btn' v-if='false'>
      图片
    </el-button>
    <el-dialog :visible.sync="dialogVisible">
      <el-upload
        accept=".jpg,.jpeg,.png,.gif,.JPG,.JPEG,.PBG,.GIF"
        :multiple="true"
        :file-list="fileList"
        :show-file-list="true"
        :on-remove="handleRemove"
        :headers="{Authorization:`Bearer ${token}`}"
        :limit="10"
        :on-exceed="exceedHandler"
        :on-success="handleSuccess"
        :before-upload="beforeUpload"
        class="editor-slide-upload"
        :action="uploadUrl"
        list-type="picture-card"
      >
        <el-button size="small" type="primary">
          点击上传
        </el-button>
      </el-upload>
      <el-button @click="cancel">
        取消
      </el-button>
      <el-button type="primary" @click="handleSubmit" :loading='subloading'>
        确认
      </el-button>
    </el-dialog>
  </div>
</template>

<script>
// import { getToken } form 'api/qiniu'
import cookie from "@/storage/cookies";
import { Message } from 'element-ui';
export default {
  name: 'EditorSlideUpload',
  props: {
    color: {
      type: String,
      default: '#1890ff'
    },
    fileNum: {
      type: Number,
      require: true
    }
  },
  data() {
    return {
      dialogVisible: false,
      listObj: {},
      fileList: [],
      uploadUrl: `${process.env.VUE_APP_APIUSER}/file/add`,
      subloading: false
    }
  },
  watch: {
    dialogVisible(val) {
      if(!val) {
        this.cancel();
      }
    }
  },
  computed: {
    token() {
      return cookie.cookieRead("token");
    }
  },
  methods: {
    cancel() {
      this.listObj = {}
      this.fileList = []
      this.dialogVisible = false
      this.subloading = false
    },
    show() {
      this.dialogVisible = true;
    },
    checkAllSuccess() {
      return Object.keys(this.listObj).every(item => this.listObj[item].hasSuccess)
    },
    handleSubmit() {
      // console.log(this.listObj)
      this.subloading = true
      const arr = Object.keys(this.listObj).map(v => this.listObj[v])

      if (!this.checkAllSuccess()) {
        this.subloading = false
        this.$message('请等待所有图片上传成功!')
        return
      }
      this.$emit('successCBK', arr)
      // console.log(arr)
      // debugger
      this.listObj = {}
      this.fileList = []
      this.dialogVisible = false
      this.subloading = false
      this.$message({
        message: '上传成功!',
        type: 'success'
      })
    },
    handleSuccess(response, file) {
      const uid = file.uid
      const objKeyArr = Object.keys(this.listObj)
      for (let i = 0, len = objKeyArr.length; i < len; i++) {
        if (this.listObj[objKeyArr[i]].uid === uid) {
          this.listObj[objKeyArr[i]].url = response.data
          this.listObj[objKeyArr[i]].hasSuccess = true
          return
        }
      }
    },
    handleRemove(file) {
      const uid = file.uid
      const objKeyArr = Object.keys(this.listObj)
      for (let i = 0, len = objKeyArr.length; i < len; i++) {
        if (this.listObj[objKeyArr[i]].uid === uid) {
          delete this.listObj[objKeyArr[i]]
          return
        }
      }
    },
    beforeUpload(file) {
      const _self = this
      const isLt3M = file.size / 1024 / 1024 < 3;
      const FileExt = file.name.replace(/.+\./, "");
      if ("jpg,jpeg,png,gif,JPG,JPEG,PBG,GIF".indexOf(FileExt.toLowerCase()) === -1) {
        this.$message({
          message: '上传失败，请上传后缀名为.jpg.jpeg.png.gif.JPG.JPEG.PBG.GIF的附件！',
          type: "warning",
        });
        this.imgLoad = false;
        return false
      }
      if (!isLt3M) {
        this.$message({
          type: "warning",
          message: "上传失败，图片最大不超过3M!"
        });
        return false;
      }
      const objKeyArr = Object.keys(this.listObj)
      let sum = objKeyArr.length + this.fileNum
      if (sum > 49) {
        Message.closeAll()
        this.$message({
          type: "warning",
          message: "详情页图片最多上传50张，超出的部分不予以上传!"
        });
        return false;
      }
      const _URL = window.URL || window.webkitURL
      const fileName = file.uid // 记录图片的uid
      this.listObj[fileName] = {} // listObj为上传的文件,把每个文件名作为 key
      return new Promise((resolve, reject) => {
        const img = new Image()
        img.src = _URL.createObjectURL(file)
        img.onload = function() {
          _self.listObj[fileName] = { hasSuccess: false, uid: file.uid, width: this.width, height: this.height } // 上传成功之后给相应的key赋值
        }
        resolve(true)
      })
    },
    exceedHandler() {
      this.$message('每次最多选10张!')
      return
    }
  }
}
</script>

<style lang="scss" scoped>
  /deep/ .tool-btn.el-button {
    background: transparent !important;
    border: 1px solid transparent !important;
    color: #595959;
    i {
      color: #595959;
    }
  }
.editor-slide-upload {
  margin-bottom: 20px;
  ::v-deep .el-upload--picture-card {
    width: 100%;
  }
}
/deep/.el-dialog__body{
  padding-bottom: 20px;
}
/deep/.el-dialog__title{
  height: 24px;
  display: block;
}
</style>
