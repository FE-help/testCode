// Here is a list of the toolbar
// Detail list see https://www.tinymce.com/docs/advanced/editor-control-identifiers/#toolbarcontrols

const toolbar = ['cut paste copy fontselect fontsizeselect forecolor bold italic underline aligncenter alignjustify alignleft alignright lineheight indent outdent numlist multipleimage link rotateright']

export default toolbar
