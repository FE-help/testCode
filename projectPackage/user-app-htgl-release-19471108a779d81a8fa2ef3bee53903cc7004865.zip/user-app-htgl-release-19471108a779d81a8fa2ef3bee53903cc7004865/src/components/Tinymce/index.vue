<template>
  <div :class="{fullscreen:fullscreen}" class="tinymce-container" :style="{width:containerWidth}">
    <textarea :id="tinymceId" class="tinymce-textarea"/>
  </div>
</template>

<script>
	/**
	 * docs:
	 * https://panjiachen.github.io/vue-element-admin-site/feature/component/rich-editor.html#tinymce
	 */
	import plugins from './plugins'
	import toolbarc from './toolbar'
	import load from './dynamicLoadScript'

	// why use this cdn, detail see https://github.com/PanJiaChen/tinymce-all-in-one
	const tinymceCDN = 'https://cdn.static.jingyingbang.com/web/libs/tinymce/5.8.2/js/tinymce/tinymce.min.js'
	// const tinymceCDN = 'https://lib.baomitu.com/tinymce/5.8.2/tinymce.min.js'
	export default {
		name: 'Tinymce',
		props: {
			id: {
				type: String,
				default: function() {
					return 'vue-tinymce-' + +new Date() + ((Math.random() * 1000).toFixed(0) + '')
				}
			},
			value: {
				type: String,
				default: ''
			},
			toolbar: {
				type: Array,
				required: false,
				default() {
					return []
				}
			},
			menubar: {
				type: String,
				default: 'file edit insert view format table'
			},
			height: {
				type: [Number, String],
				required: false,
				default: 360
			},
			width: {
				type: [Number, String],
				required: false,
				default: 'auto'
			},
			fileNum: {
				type: Number,
				require: true,
				default: 0
			}
		},
		data() {
			return {
				hasChange: false,
				hasInit: false,
				// tinymceId: this.id,
				fullscreen: false,
				languageTypeList: {
					'en': 'en',
					'zh': 'zh_CN',
					'es': 'es_MX',
					'ja': 'ja'
				}
			}
		},
		computed: {
			tinymceId () {
				return this.id
			},
			language() {
				return this.languageTypeList['zh']
			},
			comtoolbar(){
				let toolbar=[...toolbarc]
				if(!this.toolbar.join().includes('multipleimage')){
					toolbar[0]=toolbar[0].replace('multipleimage','')
				}
				return toolbar
			},
			containerWidth() {
				const width = this.width
				if (/^[\d]+(\.[\d]+)?$/.test(width)) { // matches `100`, `'100'`
					return `${width}px`
				}
				return width
			},
    },
		watch: {
			value(val,oldval) {
				if ((!this.hasChange||!oldval) && this.hasInit) {
					this.$nextTick(() =>
						window.tinymce.get(this.tinymceId).setContent(val || ''))
				}
			},
			language() {
				this.destroyTinymce()
				this.$nextTick(() => this.initTinymce())
			}
		},
		mounted() {
			this.initTinymce()
			// this.init()
		},
		activated() {
			if (window.tinymce) {
				this.initTinymce()
			}
		},
		deactivated() {
			this.destroyTinymce()
		},
		destroyed() {
			this.destroyTinymce()
		},
		methods: {
			init() {
				// dynamic load tinymce from cdn
				load(tinymceCDN, (err) => {
					if (err) {
						this.$message.error(err.message)
						return
					}
          console.log(111,window.tinymce)
					this.initTinymce()
				})
			},
			initTinymce() {
				const _this = this
				// console.log('initTinymce', window.tinymce, document.getElementById(this.id))
				window.tinymce.init({
					statusbar: false,
					elementpath: false,//2021.11.25 产品要求去除底部元素路径
					icons_url: require('./icons.js'),
					icons: 'christmas',
					language_url: require('./zh_CN.js'),
					language: this.language,
					selector: `#${this.tinymceId}`,
					height: this.height,
					body_class: 'panel-body ',
					object_resizing: false,
					toolbar: this.comtoolbar,
					// height: 650, //编辑器高度
					// min_height: this.height,
					content_style: "img {max-width:100%;}",
					branding: false,
					// content_css: [ //可设置编辑区内容展示的css，谨慎使用
					//     require('@/static/css/reset.css')
					// ],
					fontsize_formats: '12px 14px 16px 18px 24px 36px 48px 56px 72px',
					font_formats: '微软雅黑=Microsoft YaHei,Helvetica Neue,PingFang SC,sans-serif;默认字体=Verdana;苹果苹方=PingFang SC,Microsoft YaHei,sans-serif;宋体=simsun,serif;仿宋体=FangSong,serif;黑体=SimHei,sans-serif;Arial=arial,helvetica,sans-serif;Arial Black=arial black,avant garde;Book Antiqua=book antiqua,palatino;',
					menubar: false,

					plugins: plugins,
					end_container_on_empty_block: true,
					powerpaste_word_import: 'clean',
					code_dialog_height: 450,
					code_dialog_width: 1000,
					advlist_bullet_styles: 'square',
					advlist_number_styles: 'default',
					imagetools_cors_hosts: ['shigongbang.oss-cn-hangzhou.aliyuncs.com'],
					default_link_target: '_blank',
					link_title: false,
					nonbreaking_force_tab: true, // inserting nonbreaking space &nbsp; need Nonbreaking Space Plugin
					style_formats_merge: true, //设置行高
					style_formats_autohide: true, //设置行高
					init_instance_callback: editor => {
						console.log('editor初始化成功回调', _this.value)
						if (_this.value) {
							editor.setContent(_this.value)
						}
						_this.hasInit = true
						editor.on('NodeChange Change KeyUp SetContent', () => {
							this.hasChange = true
							this.$emit('input', editor.getContent())
						})
						// console.log('editor', editor)
					},
					setup(editor) {
						editor.on('init', function()
						{
							this.getDoc().body.style.fontFamily = 'Microsoft YaHei';
						});
						editor.on('FullscreenStateChanged', (e) => {
							_this.fullscreen = e.state
						})
					},
					convert_urls: false
				})
			},
			destroyTinymce() {
				const tinymce = window.tinymce.get(this.tinymceId)
				if (this.fullscreen) {
					tinymce.execCommand('mceFullScreen')
				}

				if (tinymce) {
					tinymce.destroy()
				}
			},
			setContent(value) {
				window.tinymce.get(this.tinymceId).setContent(value)
			},
			getContent() {
				window.tinymce.get(this.tinymceId).getContent()
			},
		}
	}
</script>

<style lang="scss" scoped>
  .tinymce-container {
    position: relative;
    line-height: normal;
    border: 1px solid #E4E7ED;
    border-radius: 0;
  }

  .tinymce-container {
    ::v-deep {
      .mce-fullscreen {
        z-index: 10000;
      }
    }
  }

  .tinymce-textarea {
    visibility: hidden;
    z-index: -1;
  }

  .editor-custom-btn-container {
    position: absolute;
    right: 4px;
    top: 4px;
    /*z-index: 2005;*/
  }

  .fullscreen .editor-custom-btn-container {
    z-index: 10000;
    position: fixed;
  }

  .editor-upload-btn {
    display: inline-block;
  }
  /deep/ .tox-toolbar__group{
    [aria-label="字号"]{
      .tox-tbtn__select-label{
        width: auto;
      }
    }
    [aria-label="字体"]{
      .tox-tbtn__select-label{
        width: auto;
      }
    }
  }
</style>
