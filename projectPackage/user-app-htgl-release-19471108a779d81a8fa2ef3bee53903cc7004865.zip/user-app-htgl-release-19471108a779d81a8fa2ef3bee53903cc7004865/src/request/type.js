import htglAxios from "./index.js";

const http = {
  get(url, params) {
    return new Promise((resolve, reject) => {
	    htglAxios({
        method: "get",
        params,
        url
      }).then(res => {
        resolve(res);
      });
    });
  },
  getLogin(url, params, options = {}) {
    return new Promise((resolve, reject) => {
	    htglAxios({
        // ...options,
        method: "get",
        params,
        url,
        withCredentials: true
      }).then(res => {
        console.log(res);
        resolve(res);
      });
    });
  },
  post(url, data) {
    return new Promise((resolve, reject) => {
	    htglAxios({
        method: "post",
        data,
        url
      }).then(res => {
        resolve(res);
      });
    });
  },
  postParams(url, params) {
    return new Promise((resolve, reject) => {
	    htglAxios({
        method: "post",
        params,
        url
      }).then(res => {
        resolve(res);
      });
    });
  },

  put(url, data) {
    return new Promise((resolve, reject) => {
	    htglAxios({
        method: "put",
        data,
        url
      }).then(res => {
        resolve(res);
      });
    });
  },
  putParams(url, params) {
    return new Promise((resolve, reject) => {
	    htglAxios({
        method: "PUT",
        params,
        url
      }).then(res => {
        resolve(res);
      });
    });
  },
  patch(url, data) {
    return new Promise((resolve, reject) => {
	    htglAxios({
        method: "patch",
        data,
        url
      }).then(res => {
        resolve(res);
      });
    });
  },
  delete(url) {
    return new Promise((resolve, reject) => {
	    htglAxios({
        method: "delete",
        url
      }).then(res => {
        resolve(res);
      });
    });
  },
  postHeaders(url, data, headers) {
    return new Promise((resolve, reject) => {
	    htglAxios({
        method: "post",
        data,
        url,
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        }
      }).then(res => {
        resolve(res);
      });
    });
  }
};
export default http;
