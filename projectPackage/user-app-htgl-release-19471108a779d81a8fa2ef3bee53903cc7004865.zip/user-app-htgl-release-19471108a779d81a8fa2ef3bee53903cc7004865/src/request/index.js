/**
 * 用户中心 request 实例
 * */
import axios from "axios";
import store from "@/store";
import cookie from "@/storage/cookies";
import { errorInterceptors } from "./interceptors";
const htglAxios = axios.create();
htglAxios.defaults.timeout = 50000;
htglAxios.defaults.baseURL = process.env.VUE_APP_APIUSER;
htglAxios.interceptors.request.use(
  config => {
    let token = cookie.cookieRead("token") || "";
    config.headers.Authorization = token ? `Bearer ${token}` : "";
    return config;
  },
  error => {
    return Promise.reject(error);
  }
);
htglAxios.interceptors.response.use(
  response => {
    return response;
  },
  error => {
    errorInterceptors(error);
    return Promise.reject(error);
  }
);

export default htglAxios;
