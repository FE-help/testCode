/**
 * code types
 * */

/**
 * status code 常量
 * */
export const NEED_LOGIN_STATUS_CODE = 401
