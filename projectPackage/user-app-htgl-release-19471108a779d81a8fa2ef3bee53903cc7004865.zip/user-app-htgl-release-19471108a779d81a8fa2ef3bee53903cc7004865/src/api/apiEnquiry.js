import http from "@/request/type.js";
const user = process.env.VUE_APP_API_USER;
export default {
  enquiryType: businessType =>
    http.get(
      user + `/enquiryCompanyConfig/pc/list?businessType=${businessType}`
    ), // 函询类型
  enquirySave: data =>
    http.post(user + `/enquiryCompanyService/saveOrUpdate`, data) // 保存函询或者编辑函询
};
