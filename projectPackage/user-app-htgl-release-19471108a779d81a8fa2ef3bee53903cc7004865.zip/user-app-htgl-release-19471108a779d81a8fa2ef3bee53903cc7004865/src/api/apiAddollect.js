import http from '@/http/type'
import HTTP from '@/http'
let url = process.env.VUE_APP_FOCUSPURCHASES;
let url3 = process.env.VUE_APP_API
const authUrlType = process.env.VUE_APP_ENTERPRISE
const qiyefuwu = process.env.VUE_APP_ENTERPRISESERVICES
// 审批流程

const apiAddollect = {
  // 集采状态
  status: () => http.get(url + '/usercenter/search/status'),
  // 集采地
  cityList: (data) => http.get(url + '/mygroupbuying/cityList?cityType=' + data),
  // 获取供方发起的范围
  getCityList: () => http.get(url + `/productSaleRecord/uCenterCityItem`),
  // 列表
  list: (data) => http.post(url + '/mygroupbuying/list', data),
  // 获取详情
  detail: (data) => http.get(url + "/groupbuyingRecord/detail?no=" + data),
  exit: (id) => http.get(url + `/groupbuyingParticipantRecord/exit?participantNo=` + id),
  // 客服列表
  getOrganizationAndContacts: () => http.get(url3 + authUrlType + `/v1/organization/getOrganizationAndContacts`),
  // 交流
  getImInfoByUserNo: params => http.get(qiyefuwu + "/im/getImInfoByUserNo", params),
};

export default apiAddollect
