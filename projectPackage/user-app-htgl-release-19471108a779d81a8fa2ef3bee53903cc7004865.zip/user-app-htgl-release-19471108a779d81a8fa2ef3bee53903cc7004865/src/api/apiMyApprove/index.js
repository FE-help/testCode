//审批
import request from '@/http';

let url = process.env.VUE_APP_API_LIUCHENG;

export default {
  // 审批流程
  ApprovalProcess: params => request.post(`${url}/v1/pc/process/approval/queryProcessList`, params),
  //审批日志
  ApprovalLog: params => request.post(`${url}/v1/pc/process/approval/queryOptLogApp`, params),
  //判断当前人是否有审批权限
  approvalAuthority: params => request.post(`${url}/v1/pc/process/queryProcessDataById`, params)
}
