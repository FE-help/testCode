import request from '@/http'
const QGBUrl = process.env.VUE_APP_COMPANYS
const apiSystem = {
  //获取当前用户所在部门
  getOrganizationDepByUserAndParentId: (data) => request.post(`${QGBUrl}/v1/organization/getOrganizationDepByUserAndParentId`,data),

}
export default apiSystem
