/*
 * @Author: chenx
 * @Descripttion:
 * @Date: 2021-09-07 15:21:03
 * @LastEditors: chenx
 * @LastEditTime: 2021-09-22 11:20:09
 */
import request from "@/request/type";
const url = process.env.VUE_APP_CONSTRUCTIONPOWER
const apiUser = {
    getCurrentUserCompanyInfo: () => request.get('/api/user/getCurrentUserCompanyInfo'), // 获取企业信息新接口
}
export default apiUser
