const url = process.env.VUE_APP_APIMATERIALS
export default url
