/*
 * @Author: your name
 * @Date: 2021-07-22 14:41:39
 * @LastEditTime: 2021-07-22 16:50:30
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \pc\src\api\apiContract\apiContract.js
 */
import request from '@/http'
import url from './index'
const contractUrl = process.env.VUE_APP_CONTRACT
// const contractUrl = 'http://192.168.2.72:2031'
let urlLIUCHENG = process.env.VUE_APP_API_LIUCHENG;
const apiContractTemplate = {
	sendContractId: (params) => request.post(url + '/v2/api/contract/sendContract', params),	// 发送合同
	postSignSeal: (params) => request.post(url + '/v2/api/contract/signSeal', params),	// 盖章


	postSubmitSign: (params) => request.post(url + '/v2/api/contract/submitSign', params),	// 提交盖章
	getContractStatus: (orderNo) => request.get(url + '/v2/api/contract/buyContractDetail', orderNo),	// 获取合同详情
	getDownloadContract: (contractNo) => request.get(url + '/v2/api/contract/downloadContract', contractNo),	// 下载
	postRecall: (params) => request.post(url + '/v2/api/contract/recall', params),	// 撤回
	postAgainContract: (params) => request.post(url + '/v2/api/contract/againContract', params),	// 撤回
	getLogInfo: (params) => request.post(url + '/v2/api/contractLog/getList', params),	// 获取日志
	gettemplateList: (params) => request.post(url + '/v2/api/contract/templateList', params),	// 获取模板
	postDelTemplate: (id) => request.post(url + '/v2/api/contract/delTemplate', id),	// 获取模板

	getOpenAccount: (userNo) => request.get(contractUrl + `/v1/contract/checkContractStatus/${userNo}`),	// 判断用户是否开通电子合同账户

	getContract: (id,no) => request.get(contractUrl + `/v1/contract/detail/${id}/${no}`),	// 获取合同详情
	getContractLog: (no) => request.get(contractUrl + `/v1/contractLog/list/${no}`),	// 获取合同日志
	findByContractNo: (no) => request.get(contractUrl + `/v1/updateLog/findByContractNo?contractNo=${no}`),	// 获取合同修改记录
	getContractCompany: (id) => request.get(contractUrl + `/v1/contractInvolve/list/${id}`),	// 获取合同锁涉及公司
	postSendContrac: (data) => request.post(contractUrl + `/v1/contract/update`,data),	// 发送合同
	/*1.0.5*/
	postAmendContrac: (data) => request.post(contractUrl + `/v1/contract/updateContractAtSign`,data),	// 修改合同
	/*1.0.5*/
	putDiscardContrac: (params) => request.post(contractUrl + `/v1/contract/discard/`,params),	// 作废合同
	postRejectContrac: (params) => request.post(contractUrl + `/v1/contract/reject`,params),	// 驳回合同
	getContractpdf: (data) => request.post(contractUrl + `/pdf/base64s/to`,data),	// pdf
	postBase64ToPdf: (data) => request.post(contractUrl + `/pdf/base64/to`,data),	// 单个pdfbase64转pdf
	postImgBase64ToPdf: (data) => request.post(contractUrl + `/pdf/images/to`,data),	// 多个图片base64转pdf
	getBase64ToPdfCode: (code) => request.get(contractUrl + `/pdf/base64/to/${code}`),	// 轮询请求
	getSendCode: (params) => request.get(contractUrl + '/v1/contract/sendCode', params),	// 安心签发送验证码
	postpersonalSubmitSign: (params) => request.post(contractUrl + '/v1/contract/personalSubmitSign', params),	// 个人签署发送短信短链接
	postverifyCode: (params) => request.post(contractUrl + '/v1/contract/submitSign', params),	// 签署合同
	search: (data) => request.post(contractUrl + '/v1/contract/search', data), // 合同列表
	getStatus: (data) => request.get(contractUrl + '/v1/contract/getStatus', data), // 合同状态

	getOpenAccountMsg: (params) => request.get(contractUrl + `/v1/account/detail/${params}`), // 获取用户开户信息
	getValidateCode: (params) => request.get(contractUrl + `/v1/account/getValidateCode`,params),   //电话短信
	openAccount: (data) => request.post(contractUrl + `/v1/account/openAccount`,data),// 企业开户
	personOpenAccount: (data) => request.post(contractUrl + `/v1/account/personOpenAccount`,data),// 个人开户
	updateAccount: (data) => request.post(contractUrl + `/v1/account/updateAccount`,data),// 企业修改开户信息
	updatePersonAccount: (data) => request.post(contractUrl + `/v1/account/updatePersonAccount`,data),// 个人修改开户信息
	getContracStatusStatus: (data) => request.get(contractUrl + `/v1/contract/checkStatusByNowStatus`,data),// 合同-校验合同状态
	getContractType: () => request.get(contractUrl + `/v1/contract/getContractType`),// 合同分类
	postContractCategory: (data) => request.post(contractUrl + `/v1/template/category`,data),// 合同类型
	saveContractTemplate: (params) => request.post(contractUrl + '/v1/template/save', params),	// 保存合同模板
	createContract: (data) => request.post(contractUrl + `/v1/contract/create`, data),// 创建合同
	getModuleList: (data) => request.post(contractUrl + `/v1/template/myList`, data),// 获取合同模版列表
	deleteModule: (id) => request.delete(contractUrl + `/v1/template/${id}`),// 删除合同模版
	getModuleDetail: (id) => request.get(contractUrl + `/v1/template/${id}`),// 模版详情
	postSendContractApproval: (data) => request.post(contractUrl + `/v1/contract/contractApproval`,data),// 立即申请
	//审批状态
	getfindAuditStatus: params => request.get(`${contractUrl}/v1/contract/findAuditStatus`, params),
	//审批日志
	ApprovalLog: params => request.post(`${urlLIUCHENG}/v1/pc/process/approval/queryOptLogApp`, params),
	//审批详情
	getfindAuditDetail: params => request.get(`${contractUrl}/v1/contract/findAuditDetail`, params),
	//根据合同no删除发送审批流程
	delAuditByContractNo: (contractNo) => request.post(`${contractUrl}/v1/contract/delAuditByContractNo/${contractNo}`),
	//代办 合同来源
	postContractCategoryApproval: (contractNo) => request.post(`${contractUrl}/v1/contract/category`),
	postCheckSignature: (contractNo) => request.post(`${contractUrl}/v1/contract/checkSignature/${contractNo}`),
	postWriteSignature: (data) => request.post(`${contractUrl}/v1/contract/signature`, data),
	getfindByTypeNoList: (no) => request.get(contractUrl + `/v1/admin/templateConfig/findEnableByTypeNo`,no),	// 根据分类编号查询列表

}
export default apiContractTemplate
