import http from "@/request/type.js";
let api = process.env.VUE_APP_APIMACHINERY;
const apiCenter = process.env.VUE_APP_API_USER;
const apiBase = process.env.VUE_APP_BASE_API;
const apiQyfw = process.env.VUE_APP_API_SERVICE;
const apiCommon = {
  sysMachineryBasicArea: () => http.get(api + "/sysMachineryBasicArea"),
  getAllAreaList: params =>
    http.get(apiCenter + "/api/auth/getAllAreaList", params),
  getIMAccount: no =>
    http.get(`${apiBase}/memberCenter/companyInfoCustomer/pc/list/${no}`), //获取企业客服列表
  getImInfoByUserNo: params =>
    http.get(apiQyfw + "/im/getImInfoByUserNo", params) //获取聊天好友的iM信息
};
export default apiCommon;
