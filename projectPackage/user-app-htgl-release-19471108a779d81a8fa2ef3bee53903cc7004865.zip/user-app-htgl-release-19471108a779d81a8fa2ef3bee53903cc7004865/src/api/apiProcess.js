import request from "@/http"
const baseUrl = process.env.VUE_APP_API + "/sgb-meta-design"
// const baseUrl = 'http://localhost:8080'
import qs from "qs"
const url = process.env.VUE_APP_API
const qiguan = process.env.VUE_APP_QIGUAN
const appUrl = url + qiguan;
const hyUrl = process.env.VUE_APP_APIMEMBER

// 保存流程
export const saveProcess = async(params) => request.postHeaders(`${baseUrl}/v1/pc/process/addProcess`, qs.stringify(params))
// 提交申请
export const saveApply = async(params) => request.postHeaders(`${baseUrl}/v1/pc/process/applyProcess`, qs.stringify(params))
// 获取流程详情
export const getProcessDetail = async(params) => request.postHeaders(`${baseUrl}/v1/pc/process/queryProcessById`, qs.stringify(params))
// 更新流程
export const updateProcess = async(params) => request.postHeaders(`${baseUrl}/v1/pc/process/updateProcess`, qs.stringify(params))
//更新流程为新版数据结构
export const updateProcessToNew = async(params) => request.postHeaders(`${baseUrl}/v1/pc/process/updateOldProcessToNewProcess`, qs.stringify(params))
// 根据userId获取流程
export const queryProcessByCompanyAndUser = async(params) => request.post(`${baseUrl}/v1/pc/process/queryProcessByCompanyAndUser`, params)
// 获取动态流程
export const queryProcessList = async(params) => request.post(`${baseUrl}/v1/pc/process/queryProcessList`, params)
// 邀请申请-个人
export const personMemberJoin = (params) => request.post(`${url}/sgb-member/ov1/member/league/person/memberJoin`, params)

// 获取所有我的申请列表
export const applyList = async(params) => request.post(`${baseUrl}/v1/pc/process/applyListOfmine`, params)
//申请邀请--新
export const memberJoin = (params) => request.post(`${url}/sgb-member/ov1/member/league/memberJoin`, params)
// 审批通过
export const approverMakerAsPass = async(params) => request.post(`${baseUrl}/v1/pc/process/approverMakerAsPass`, params)
// 审批不通过
export const approverMakerAsRefuse = async(params) => request.post(`${baseUrl}/v1/pc/process/approverMakerAsRefuse`, params)
// 获取当前申请的日志记录信息
export const queryOptLog = async(params) => request.post(`${baseUrl}/v1/pc/process/queryOptLog`, params)
// 根据 ID 获取指定数据记录信息
export const queryProcessDataById = async(params) => request.post(`${baseUrl}/v1/pc/process/queryProcessDataById`, params)
// 根据类型查询自定义流程信息
export const queryProcessByType = async(params) => request.post(`${baseUrl}/v1/pc/process/queryProcessByType`, params)
// 获取我的审批列表
export const getMyApproval = async(params) => request.post(`${baseUrl}/v1/pc/process/queryApproverListOfMine`, params)
// 流程转交
export const deliverProcess = async(params) => request.post(`${baseUrl}/v1/pc/process/deliverProcess`, params)
// 自定义表单申请提交
export const applyProcessCustomForm = async(params) => request.postHeaders(`${baseUrl}/v1/pc/process/applyProcessCustomForm`, qs.stringify(params))

// app审批
export const approvalOption = async(data) => request.postHeaders(`${appUrl}/v1/app/webMeeting/approvalAuditPc`, qs.stringify(data))

//申请加盟状态
export const changeAuditStatus = async(data) => request.put(`${hyUrl}/ov1/member/approve/changeAuditStatus`, data)
export const changeAuditStatusPerson = async(data) => request.put(`${hyUrl}/ov1/member/approve/person/changeAuditStatus`, data) // 个人

//调级申请状态
export const changeMemberStatus = async(data) => request.post(`${hyUrl}/ov1/member/grade/approve`, data)

//调级个人会员

export const changePersonMemberStatus = async(data) => request.get(`${hyUrl}/ov1/member/approve/person/updatePersonGrade`, data)

//会员解除状态
export const changeDelStatus = async(data) => request.get(`${hyUrl}/ov1/member/league/del`, data)

//解除个人
export const changePersonDelStatus = async(data) => request.get(`${hyUrl}/ov1/member/league/person/del`, data)

//获取主管级别
export const directorLevelList = async() => request.get(`${baseUrl}/v1/pc/process/directorLevelList`)
