import http from "@/request/type.js";
const apiAuth = process.env.VUE_APP_API_AUTH;

export const getAppRouter = appSign =>
  http.post(apiAuth + `/WebMicroServiceController/getByAppId/${appSign}`);
