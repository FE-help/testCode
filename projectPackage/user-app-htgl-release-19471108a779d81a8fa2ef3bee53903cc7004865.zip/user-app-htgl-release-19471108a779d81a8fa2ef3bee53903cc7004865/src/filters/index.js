import { timestampToTime } from "@/utils/time";
// 时间戳转化为 年月日 时分秒
export function formatDate(value) {
  return timestampToTime(value);
}
// 时间戳转化为 年月日 时分
export function formaHoures(value) {
  return timestampToTime(value, "YYYY-MM-DD HH:mm");
}
// 时间戳转化为 年月日
export function formatDay(value) {
  return timestampToTime(value, "YYYY-MM-DD");
}
// 价格保留两位小数
export function priceFixed2(value, unit = "") {
  if (value == -1) {
    return "议价";
  }
  return Number(value || 0).toFixed(2) + unit;
}
