// cookies
import cookies from 'js-cookie'
// 创建cookies （名字，值，时间）  时间单位为天
function cookieSet (cName, value, expiredays) {
	var millisecond = new Date().getTime();
	var expiresTime = new Date(millisecond + 1209600000); //  当前时间 + 14天
	if (process.env.NODE_ENV === 'development') {
		cookies.set(cName, value, { expires: expiresTime })
	} else {
		cookies.set(cName, value, { expires: expiresTime, path: '/', domain: process.env.VUE_APP_COOKIE })
	}

	// cookies.set(cName, value, { expires: expiredays, path: '/', domain: '.zhandiana.com' })
	// cookies.set(cName, value, { expires: expiredays, path: '/', domain: '.gcw.net' })
	// cookies.set(cName, value, { expires: expiredays, path: '/', domain: '.shigongbang.com' })
}

function cookieRead (key, getAll = false) {
	return getAll ? cookies.get() : cookies.get(key)
}

function cookieClear (key) {
	if (process.env.NODE_ENV === 'development') {
		cookies.remove(key)
	} else {
		cookies.remove(key, { path: '/', domain: process.env.VUE_APP_COOKIE })
	}
	// cookies.remove(key, { path: '/', domain: '.zhandiana.com' })
	// cookies.remove(key, { path: '/', domain: '.gcw.net' })
	// cookies.remove(key, { path: '/', domain: '.shigongbang.com' })
}
const cookie = {
	cookieSet,
	cookieRead,
	cookieClear
}
export default cookie
