module.exports = {
  title: '经营帮-用户中心',
  titleSeparator: ' | ', // 分隔符
  publicPath: '/',
  customerTelephone: '400-001-0051', // 客服电话
  copyrightNotice: '版权所有 Copyright ©陕西经营帮网络科技有限公司', // 版权声明
  websiteRecordNumber: '陕ICP备2020015070号-1' // 网站备案号
}
