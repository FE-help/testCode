// 登录 注册 找回密码相关
const _import_ = path => resolve => require([`@/views/Login/${path}.vue`], resolve)
const login = [
  {
    path: '/login',
    name: 'Login',
    meta: {
      auth: false
    },
    component: _import_('Login')
  },
  {
    path: '/passfind',
    name: 'Passfind',
    meta: {
      auth: false
    },
    component: _import_('Passfind')
  },
  {
    path: '/passfindnext',
    name: 'Passfindnext',
    meta: {
      auth: false
    },
    component: _import_('Passfindnext')
  },
  {
    path: '/sign',
    name: 'Sign',
    meta: {
      auth: false
    },
    component: _import_('Sign')
  },
  {
    path: '/signSuccessfully',
    name: 'SignSuccessfully',
    meta: {
      auth: false
    },
    component: _import_('SignSuccessfully')
  }
]
export default login
