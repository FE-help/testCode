import login from '@/router/setting/modules/login'

let Route = [{
  path: '/',
  redirect: {name: 'Home'},
  meta: {
    auth: true // 是否登录状态下可访问
  }
},
  {
    path: '*',
    redirect: '/',
    auth: false
  }]
const baseRoute = Route.concat(login)
export default baseRoute
