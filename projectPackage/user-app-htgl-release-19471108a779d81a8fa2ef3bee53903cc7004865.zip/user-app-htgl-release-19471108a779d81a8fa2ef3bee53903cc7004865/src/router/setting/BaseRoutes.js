import BaseRouter from "@/components/public/BaseRouter.vue";
import cookie from "@/storage/cookies";

let Route = [{
  path: "/login",
  name: "Login",
  meta: {
    auth: false,
    layout: "baselayout"
  },
  component: () => import("@/views/Login/Login.vue")
},
  {
    path: "/Notfound",
    name: "页面不存在",
    meta: {
      isMenu: false,
      hidden: true
    },
    redirect: "/404",
    component: BaseRouter,
    children: [{
      path: "/404",
      name: "找不到相关页面",
      meta: {
        Title: "找不到相关页面",
        isMenu: false,
        hidden: true
      },
      component: () => import("@/views/404.vue")
    }]
  }
];

export default Route;
