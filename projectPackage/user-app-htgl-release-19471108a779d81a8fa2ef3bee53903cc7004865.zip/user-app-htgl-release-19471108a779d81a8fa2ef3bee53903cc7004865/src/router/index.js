import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)
let routes = []
const router = new Router({
  mode: 'history',
  routes: routes
})
export default router
