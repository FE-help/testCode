import axios from 'axios'

const http = {
  get (url, params) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'get',
        params,
        url
      }).then(res => {
        resolve(res)
      })
    })
  },
  getLogin(url, params, options = {}) {
    return new Promise((resolve, reject) => {
        axios({
            // ...options,
            method: "get",
            params,
            url,
            withCredentials: true
        }).then(res => {
            console.log(res);
            resolve(res)})
    })
},
  post (url, data) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'post',
        data,
        url
      }).then(res => {
        resolve(res)
      })
    })
  },
  postParams (url, params) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'post',
        params,
        url
      }).then(res => {
        resolve(res)
      })
    })
  },

  put (url, data) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'put',
        data,
        url
      }).then(res => {
        resolve(res)
      })
    })
  },
  putParams (url, params) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'PUT',
        params,
        url
      }).then(res => {
        resolve(res)
      })
    })
  },
  patch (url, data) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'patch',
        data,
        url
      }).then(res => {
        resolve(res)
      })
    })
  },
  delete (url) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'delete',
        url
      }).then(res => {
        resolve(res)
      })
    })
  }
}
export default http
