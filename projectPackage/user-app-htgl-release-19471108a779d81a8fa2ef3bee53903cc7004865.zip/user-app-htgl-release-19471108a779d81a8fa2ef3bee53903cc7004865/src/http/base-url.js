const userPageBaseUrl = `${process.env.VUE_APP_TRIP}${process.env.VUE_APP_USER_PAGE}`
export { userPageBaseUrl }