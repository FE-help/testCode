/**
 * Created by zzt on 19/1/9.
 * http配置
 */

import axios from 'axios'
import store from '@/store'
import cookie from '@/storage/cookies'
import {Message, MessageBox,} from 'element-ui'
import {gernerateStrV1, decryptJson} from '@/utils/SpiderHack.js'

// import store from '@/store'
// import router from '@/router'

window.pending = []
let pending = window.pending // 声明一个数组用于存储每个请求的取消函数和axios标识
let cancelToken = axios.CancelToken
let removePending = (config) => {
  let excludeApi = (config.url.split('/')).pop() // 身份证与姓名验证接口 可重复
  if (excludeApi !== 'verifyIdCard') {
    for (let p in pending) {
      if (pending[p].u.indexOf('sysArea/getAllArea') != -1 || pending[p].u.indexOf('file/addFiles') != -1) { //请求地区地址、上传多图
      } else {
        if (pending[p].u === config.url + JSON.stringify(config.data) + JSON.stringify(config.params) + '&' + config.method) { // 当当前请求在数组中存在时执行函数体
          pending[p].f() // 执行取消操作
          pending.splice(p, 1)
        }

      }

    }
  }
}

// axios 基础配置
axios.defaults.timeout = 50000
axios.defaults.baseURL = process.env.VUE_APP_APIUSER
// 白名单 指定接口不带token 勿动
let white = [`${process.env.VUE_APP_APIMATERIALS}/itemCat/getTreeNodeByProvinceId`]
axios.interceptors.request.use(
  config => {
    let sign = gernerateStrV1()
    config.headers.sign = sign
    // let token = store.state.token
    let token = cookie.cookieRead('token')
    // 判断指定接口不带token
    if (token&&!white.includes(config.url)) {
      config.headers.Authorization = `Bearer ${token}`
    }
    config.headers.tag = 'member'
    // "JYB", "经营帮
    config.headers.platform = 'JYB'
    // removePending(config) // 在一个axios发送前执行一下取消操作
    // config.cancelToken = new cancelToken((c) => {
    //   // 这里的axios标识我是用请求地址&请求方式拼接的字符串，当然你可以选择其他的一些方式
    //   // 暂留待测试
    //   pending.push({
    //     u: config.url + JSON.stringify(config.data) + JSON.stringify(config.params) + '&' + config.method,
    //     f: c
    //   }) // config.data为请求参数
    // })
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

// http response interceptors
axios.interceptors.response.use(
  response => {
    // removePending(response.config) // 在一个axios响应后再执行一下取消操作，把已经完成的请求从pending中移除
    // 202-物流，身份未刷新时，强制刷新页面重新获取当前身份信息

    if(response.headers.isencryption && response.headers.isencryption == 1 && response.data.payload){
      let param = ['data', 'result', 'records']
      let current = param.find(i=>i in response.data)
      if(current){
      let decryptData = decryptJson(response.data.payload)
      let dataType = response.headers.datatype
      let handler = {'object': JSON.parse, 'list': JSON.parse, 'long': parseFloat,  'integer': parseFloat, 'boolean': (parse) => typeof(parse) == 'boolean' ? parse : typeof(parse) == 'string' && parse == 'true' ? true : false }
      response.data[current] = handler[dataType] ? handler[dataType](decryptData) : decryptData;
      }
   }
    if(response.data.code === 202) {
      MessageBox.confirm(
        response.data.msg,
        '提示', {
          confirmButtonText: '确定',
          showCancelButton: false,
          type: 'warning'
        }
      ).then(() => {
        window.location.reload()
      })
      return
    }
    return response
  },
  error => {
    if (error.response) {
      // switch (error.response.status) {
      //     case 401:
      //     case 403:
      //         Message.error(error.response.data.msg)
      //             // store.commit('LOGIN_OUT')
      //         break
      //     case 500:
      //         if (error.response.data.message) {
      //             Message.error(error.response.data.message)
      //             if (error.response.data.message == 'Token 验证失败') {
      //                 // store.commit('LOGIN_OUT')
      //             }
      //         } else {
      //             if (error.response.data.msg == '身份验证失败') {
      //                 // store.commit('LOGIN_OUT')
      //             }
      //         }
      //         break
      //     default:
      //         // Message.error('服务出错，请重新登陆！')
      //         // store.commit('LOGIN_OUT')
      //         break
      // }
      if (error.response.data.code === 666) {
        Message.error(error.response.data.msg)
        store.commit('LOGIN_OUT')
      } else {
        Message.error(error.response.data.msg)
      }
    }
    return {
      data: error.response ? error.response.data : {}
    }
  }
)
export default {
  get(url, params) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'get',
        params,
        url
      }).then(res => {
        resolve(res)
      })
    })
  },
  getLogin(url, params, options = {}) {
    return new Promise((resolve, reject) => {
        axios({
            // ...options,
            method: "get",
            params,
            url,
            withCredentials: true
        }).then(res => {resolve(res)})
    })
},
  getData(url, params, data) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'get',
        params,
        url,
        data
      }).then(res => {
        resolve(res)
      })
    })
  },
  post(url, data) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'post',
        data,
        url
      }).then(res => {
        resolve(res)
      })
    })
  },
  postParams(url, params) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'post',
        params,
        url
      }).then(res => {
        resolve(res)
      })
    })
  },
  postParamsData(url, params, data) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'post',
        params,
        data,
        url
      }).then(res => {
        resolve(res)
      })
    })
  },
  postHeaders(url, data, headers) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'post',
        data,
        url,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      }).then(res => {
        resolve(res)
      })
    })
  },
  postData(url, params, data) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'post',
        params,
        url,
        data
      }).then(res => {
        resolve(res)
      })
    })
  },
  postLogin(url, params) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'post',
        headers: {
          'Authorization': 'Basic Z2N0eDpnY3R4'
        },
        url,
        params
      }).then(res => {
        resolve(res)
      })
    })
  },
  put(url, data) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'put',
        data,
        url
      }).then(res => {
        resolve(res)
      })
    })
  },
  patch(url, data) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'patch',
        data,
        url
      }).then(res => {
        resolve(res)
      })
    })
  },
  delete(url) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'delete',
        url
      }).then(res => {
        resolve(res)
      })
    })
  },
  deleteParams(url, data) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'delete',
        url,
        data
      }).then(res => {
        resolve(res)
      })
    })
  }
}
