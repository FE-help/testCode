

class MainStore {
  constructor () {
    this.store = {}
  }
  setMainStore (store) {
    this.store = store
  }
}
export default new MainStore()
