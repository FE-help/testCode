/**
 * @Author: cbq
 * @Date: 2020/04/20
 * @Project:
 */
export const validate = {
	// validatePro: validatePro,
	// validateTitle: validateTitle,
	// validateBrand: validateBrand,
	// validateTax: validateTax,
	// validateUnit: validateUnit,
	// validatePrice: validatePrice,
	// validateDesc: validateDesc,
	validPhone:validPhone,
	validateNum: validateNum,
	age:age,
	contactNumberMesges:contactNumberMesges
}
/**@name 手机号验证 */
function contactNumberMesges(rule, value, callback) {
	const mobile = /^1(3|4|5|6|7|8|9)\d{9}$/;
  const phone = /^0\d{2,3}-?\d{7,8}$/;
  if (!value) {
    callback(new Error("请输入联系电话号码,或座机号码"));
  } else if (!phone.test(value) && !mobile.test(value)) {
    callback(new Error("请填写正确的手机号或座机号"));
  } else {
    callback();
  }
}
function validateNum (rule, value, callback) {
	let reg = /^[0-9]*$/;
	if (!value) {
		callback(new Error('请填写团队规模'))
	}else {
		if (parseFloat(value).toString() === 'NaN') {
			callback(new Error('团队规模请输入数字'))
		} else if(!reg.test(value)) {
			callback(new Error('团队规模只能输入数字'))
		}else {
			callback()
		}
	}
}
function age (rule, value, callback) {
	let reg = /^[0-9]*$/;
	if (!value) {
		callback(new Error('请填写年龄'))
	}else {
		if (parseFloat(value).toString() === 'NaN') {
			callback(new Error('年龄请输入数字'))
		} else if(!reg.test(value)) {
			callback(new Error('年龄只能输入数字'))
		}else {
			callback()
		}
	}
}
function validPhone (rule, value, callback) {
	const reg = /^1[2|3|4|5|6|7|8|9][0-9]\d{8}$/;
	if (!value) {
		callback(new Error("请输入联系电话"));
	} else if (!reg.test(value)) {
		callback(new Error("请输入正确的手机号码格式"));
	} else {
		callback();
	}
};
