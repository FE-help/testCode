<template>
<div class='Material-wrap'>
  <template v-for='obj in finallyDetail'>
    <div class='material bor_none' :key='obj.id' v-if="finallyDetail">
      <!-- <div class='material-title'>订单清单</div> -->
      <div class='material-title title_border'>采购清单</div>
      <div class='material-body'>
        <!-- <div class='list-wrap' v-for='(item, index) in obj.list' :key='index'>
          <template v-if="item.list">
            <div class='list-item' v-for='(it, idx) in item.list' :key='idx + index'>
              <div class='mb10'>
                <div class='item-name' :title="it.name">{{it.name}}</div>
                <div class='brand-wrap'>品牌：{{it.brand || '/'}}</div>
                <div class="skuitem">
                  <span v-for='(item2, index2) in it.skuDetails' :key='index2 + idx + index'>
                    {{item2.name}}：{{item2.val}}
                  </span>
                </div>
              </div>
              <div class='price-wrap'>
                <span class='cgsl'>采购数量：{{it.count}}</span>
                <span class='dj'>单价：{{it.money}}元/{{it.unit}}</span>
                <span>商品金额合计：{{it.total}}元</span>
              </div>
            </div>
          </template>
          <template v-else>
            <div class='list-item'>
              <div class='list-item-flex'>
                <div class='item-name' :title="item.name">{{item.name}}</div>
                <div class='brand-wrap'>品牌：{{item.brand}}</div>
                <div class="skuitem">
                  <span v-for='(item2, index2) in item.skuDetails' :key='index2 + index'>
                    {{item2.name}}：{{item2.val}}
                  </span>
                </div>
              </div>
              <div class='flex price-wrap'>
                <span class='cgsl'>采购数量：{{item.count}}</span>
                <span class='dj'>单价：{{item.money}}元/{{item.unit}}</span>
                <span>商品金额合计：<span style="color: #FF6600;">{{item.total | moneyToCurrency}}元</span></span>
              </div>
            </div>
          </template>
        </div> -->
            <base-custom-table :tableData="obj.list" :border="border">
              <el-table-column label="商品名称" prop="name"></el-table-column>
              <el-table-column label="规格型号" prop="skuDetails" show-overflow-tooltip>
                    <template slot-scope="scope">
                      <div v-if="scope.row.skuDetails.length !== 0">
                        <div v-for="(item,index) in scope.row.skuDetails" :key="index">
                          {{item.name}}：{{item.val}}
                        </div>
                      </div>
                      <div v-else>
                        <span>/</span>
                      </div>
                    </template>
                </el-table-column>
                <el-table-column label="单位" prop="unit"></el-table-column>
                <el-table-column label="采购量" prop="count"></el-table-column>
                <el-table-column label="单价(含税)" prop="money">
                  <template slot-scope="scope">
                    <span>{{scope.row.money | moneyToCurrency}}</span>
                  </template>
                </el-table-column>
                <el-table-column label="小计(含税)" prop="total">
                  <template slot-scope="scope">
                    <span>{{scope.row.total | moneyToCurrency}}</span>
                  </template>
                </el-table-column>
            </base-custom-table>
        <div class='material-bottom bottom_border'>
          <div class='pay-list'>
            <el-row style="margin-bottom: 10px" v-if="obj.deliveryCost || obj.handlingCost || obj.installationCost">
              <el-col :span="8" class='flex' v-if="obj.deliveryCost"><div class="title">配送费：</div><div class="pay">{{obj.deliveryCost | moneyToCurrency}} <span >元</span> </div></el-col>
              <el-col :span="8" class='flex' v-if="obj.handlingCost"><div class="title">装卸费：</div><div class="pay">{{obj.handlingCost | moneyToCurrency}} <span >元</span> </div></el-col>
              <el-col :span="8" class='flex' v-if="obj.installationCost"><div class="title">安装费：</div><div class="pay">{{obj.installationCost | moneyToCurrency}} <span >元</span> </div></el-col>
            </el-row>
            <el-row>
              <el-col :span="8" class='flex'><div class="title">订单金额合计：</div><div class="pay">{{getAmount(obj) | moneyToCurrency}}元</div></el-col>
              <el-col :span="16" class='flex'><div class="title">（大写）</div><div class="pay">人民币{{getAmount(obj) | digitUppercase}}</div></el-col>
            </el-row>
          </div>
        </div>
      </div>
    </div>
    <div :key='obj.id' v-if="obj.appointData">
      <div class='material'  v-if="obj.appointData.length">
        <div class='material-title'>约定信息</div>
        <div class="material-appoint">
          <div class="material-appoint-item" v-for="(item, index) in obj.appointData" :key="`appoint_${index}`">
            <div class="material-appoint-label">{{item.appointName}}</div>
            <div class="material-appoint-right">
              <div class="material-appoint-value" v-for="(it, idx) in item.fields" :key="`appoint_${index}_${idx}`">
                {{it.fieldName}}：{{it.fieldValue || '/'}}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="settlement" :key="obj.id" v-if="obj.receiptData">
      <div class="settlement_title">付款及结算  <span
            style="
              font-size: 14px;
              font-weight: 400;
              color: #333;
              margin-left: 5px;
            "
            >货款模式：{{ obj.paymentWay == 2 ? "先货后款" : "先款后货" }}</span></div>

      <base-custom-table :tableData="obj.receiptData" :border="border">
        <el-table-column label="付款类型" prop="paySupplierType">
          <template class="color_333" slot-scope="scope">
            <span class="color_333" v-if="scope.row.paySupplierType == 0">其他</span>
            <span v-else-if="scope.row.paySupplierType == 1">定金</span>
            <span v-else-if="scope.row.paySupplierType == 2">预付款</span>
            <span v-else-if="scope.row.paySupplierType == 3">验收款</span>
            <span v-else-if="scope.row.paySupplierType == 4">质保金</span>
            <span v-else-if="scope.row.paySupplierType == 5">全款</span>
          </template>
        </el-table-column>
        <el-table-column label="金额（元）" prop="money">
          <template slot-scope="scope">
            <div class="moneystyle">
              {{ scope.row.money | numToFixed2 }}
            </div>
          </template>
        </el-table-column>
        <el-table-column label="货币类型" prop="currencyType">
          <template slot-scope="scope">
            <span v-if="scope.row.currencyType == 0">人民币</span>
            <span v-else>/</span>
          </template>
        </el-table-column>
        <el-table-column label="付款时间" prop="payDeadline">
          <template slot-scope="scope">
            <span>{{scope.row.payDeadline | DateDay}}</span>
          </template>
        </el-table-column>
        <el-table-column label="备注" prop="remark">
          <template slot-scope="scope">
            <span v-if="scope.row.remark">{{scope.row.remark}}</span>
            <span v-else>/</span>
          </template>
        </el-table-column>
      </base-custom-table>
    </div>
  </template>
</div>
</template>

<script>
export default {
  props: {
    detail: {
      type: [Object, Array],
      default: () => {
        return []
      }
    },
	  border: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
    }
  },
  computed: {
    finallyDetail ({detail, calcAmount}) {
      return detail.map(item => {
        return {
          ...item.orderInfo,
          amount: calcAmount(item.orderInfo),
          list: this.getArrayList(item.orderInfo.list)
        }
      })
    }
  },
  mounted () {
    // this.getData()
    console.log(this.finallyDetail)
  },
  methods: {
    getArrayList (data = []) {
      // 旧数据
      if (data[0] && data[0].list) {
        let arr = []
        data.map(it => {
          arr.push(...it.list)
        })
        return arr
      } else {
        return data
      }
    },
    getAmount ({deliveryCost = 0, handlingCost = 0, installationCost = 0, amount = 0}) {
      return deliveryCost + handlingCost + installationCost + amount
    },
    calcAmount (orderInfo) {
      const {amount = 0, list = []} = orderInfo
      let price = 0
      list.map(item => {
        const { costs = [] } = item
        costs.map(it => {
          price += it.money
        })
      })
      return amount + price
    },
    // 计算安装费 配送费 装卸费
    calcCosts (data = [], type) {
      let price = 0
      data.map(item => {
        if (item.type === type) {
          price += item.money
        }
      })
      return price
    }
  }
}
</script>

<style lang='scss' scoped>
.settlement{
  margin-top: 15px;
  .settlement_title{
    // height: 28px;
    padding: 11px 20px;
    background: #FAFAFA;
    font-weight: bold;
    border-width: 1px 1px 0px 1px;
    border-style: solid;
    border-color: #E4E7ED;
    box-sizing: content-box;
  }
  /deep/.el-table{
      .el-table__header-wrapper{
        .el-table__header{
          .has-gutter{
            .el-table__cell{
              background: #fff !important;
            }
          }
        }
      }
      .el-table__body-wrapper{
        .el-table__body{
          .el-table__row{
            .el-table__cell{
              color: #333333 !important;
            }
          }
        }
      }
    }
  .color_333{
    color: #333333;
  }
}
.material {
  border: 1px solid #E4E7ED;
  margin-top: 15px;
  .flex {
    display: flex;
    align-items: flex-start;
  }
  .mb15 {
    margin-bottom: 15px;
  }
  .material-body {
    // padding: 0 20px;
    /deep/.el-table{
      .el-table__header-wrapper{
        .el-table__header{
          .has-gutter{
            .el-table__cell{
              background: #fff !important;
            }
          }
        }
      }
      .el-table__body-wrapper{
        .el-table__body{
          .el-table__row{
            .el-table__cell{
              color: #333333 !important;
            }
          }
        }
      }
    }
  }
  .material-title {
    color: #333333;
    font-size: 16px;
    background-color: #fafafa;
    padding: 11px 20px;
    font-weight: bold;
    border-bottom: 1px solid #E4E7ED;
  }
  .title_border{
    border-top: 1px solid #E4E7ED;
    border-left: 1px solid #E4E7ED;
    border-right: 1px solid #E4E7ED;
    border-bottom: none;
  }
  .material-bottom {
    font-size: 14px;
    .pay-list {
      padding: 20px 20px;
      .title {
        color: #666666;
      }
      .pay {
        color: #FF6600;
      }
    }
    .pay-list:not(:last-child) {
      border-bottom: 1px dashed #E4E7ED;
    }
  }
  .bottom_border{
    border-bottom: 1px solid #E4E7ED;
    border-left: 1px solid #E4E7ED;
    border-right: 1px solid #E4E7ED;
  }
  .price-wrap {
    span {
      margin-right: 50px;
    }
  }
  .list-wrap {
    border-bottom: 1px dashed #E4E7ED;
    padding: 20px 0px;
    .pay-list {
      font-size: 14px;
      .pay {
        color: #FF6600;
      }
    }
  }
  .list-item {
    font-size: 14px;
    // padding-bottom: 10px;
    .list-item-flex {
      // display: flex;
      // flex-wrap: wrap;
      padding-bottom: 10px;
    }
    .item-name {
      color: #333333;
      font-weight: bold;
      display: inline;
      // flex: 1;
      // white-space: nowrap;
      // overflow: hidden;
      // text-overflow: ellipsis;
    }
    .skuitem {
      color: #333333;
      font-size: 14px;
      display: inline;
      // white-space: nowrap;
      // overflow: hidden;
      // text-overflow: ellipsis;
      span {
        // padding-left: 10px;
      }
    }
    .brand-wrap {
      margin-left: 20px;
      margin-right: 20px;
      width: 100px;
      color: #333333;
      font-size: 14px;
      display: inline;
    }
  }
  .cgsl {
    max-width: 144px;
    overflow: hidden;
  }
  .dj {
    max-width: 169px;
    overflow: hidden;
  }
  .material-appoint {
    padding: 10px 20px;
    .material-appoint-item {
      display: flex;
      font-weight: bold;
      color: #333333;
      line-height: 24px;
      .material-appoint-label {
        width: 120px;
        font-size: 13px;
      }
      .material-appoint-right {
        flex: 1;
        display: flex;
        flex-wrap: wrap;
        font-size: 12px;
        .material-appoint-value {
          margin-right: 30px;
        }
      }
    }
  }
}
.bor_none{
    border: none;
}
</style>
