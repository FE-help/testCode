<template>
<div class='Material-wrap'>
  <div class='material'>
    <!-- <div class='material-title'>订单清单</div> -->
    <div class='material-title'>租赁清单</div>
    <div class='material-body'>
      <div class='list-wrap' style="padding-bottom: 20px;">
        <el-row>
          <el-col :span="5">
            <span class="titleBox">{{ detailsInfo.module == 1 ? '机械' : '设备' }}名称 : {{goodsInfo.secondCategoryName}}</span>
          </el-col>
          <el-col :span="4" >品牌 :
            <span>{{goodsInfo.brandName || '/'}}</span>
          </el-col>
          <el-col :span="5" >出厂型号 :
            <span>{{goodsInfo.modelName || '/'}}</span>
          </el-col>
          <el-col :span="5" >租赁数量 : {{detailsInfo.rentalNum}}</el-col>
          <el-col :span="5" >
            <span class="titleBox" style="width: auto">租赁时长/工程量 : {{detailsInfo.rentalTime}} {{detailsInfo.rentalPriceUnitName.split('/')[detailsInfo.rentalPriceUnitName.split('/').length - 1]}} </span>
          </el-col>
        </el-row>
        <el-row  style="padding-top: 10px;">
          <el-col  :span="9">
            <span class="titleBox">租赁单价 : <span class="pay">{{detailsInfo.newRentalPrice || detailsInfo.rentalPrice}} {{detailsInfo.rentalPriceUnitName}}</span> </span>
          </el-col>
          <el-col  :span="15">运费 : <span class="pay">{{
                                detailsInfo.transportPrice
                                    ?  Number(detailsInfo.transportPrice).toFixed(2)
                                    : "0.00"
                            }}元</span></el-col>
        </el-row>
      </div>

      <div class='material-bottom'>
        <el-row class='pay-list'>
          <el-col :span="8" class='flex'><div class="title">合计总金额：</div><div class="pay" style="font-weight: bold">{{(Number(detailsInfo.receiveOrderPrice || detailsInfo.rentalTotalPrice) + Number(detailsInfo.transportPrice)).toFixed(2) | moneyToCurrency}}元</div></el-col>
          <el-col :span="16" class='flex'><div class="title">（大写）</div><div class="pay" style="font-weight: bold">人民币{{(Number(detailsInfo.receiveOrderPrice || detailsInfo.rentalTotalPrice) + Number(detailsInfo.transportPrice)).toFixed(2) | digitUppercase}}</div></el-col>
        </el-row>
      </div>
    </div>
  </div>
  <div class='material' >
    <div class='material-title'>租赁约定</div>
    <div class='material-body'>
      <div class='list-wrap1' >
        <el-row class="infoBox">
          <el-col :span="12">
            <span >进场时间 :
              <span class="cl333333">{{detailsInfo.approachTime | timePro}}</span>
            </span>
          </el-col>
          <el-col :span="12">
            <span >工作地址 :<span class="cl333333">{{detailsInfo.address}}</span></span>
          </el-col>
          <el-col :span="12">
            <span >运输要求 : <span class="cl333333">{{
                  detailsInfo.carrier == 1 ? '承租方承担' : "出租方承担"
                }}</span></span>
          </el-col>
          <el-col :span="12">
            <span >{{ detailsInfo.module == 1 ? '驾驶员要求 : ' : '操作员要求 : ' }}<span class="cl333333">{{
                    detailsInfo.driverProvider == 1 ? '承租方提供' : "出租方提供"
                  }}</span></span>
          </el-col>
          <el-col :span="12" v-if="detailsInfo.driverProvider == 2 && detailsInfo.maxDriverAge && detailsInfo.module == 1">
            <span >驾驶员年龄要求 :
              <span class="detail-text cl333333" v-if="detailsInfo.driverProvider == 2 && detailsInfo.maxDriverAge">{{detailsInfo.minDriverAge}}~{{detailsInfo.maxDriverAge}}岁</span>
              <span class="detail-text cl333333" v-else>暂无信息</span>
            </span>
          </el-col>
          <el-col :span="12" v-if="detailsInfo.driverProvider == 2 && detailsInfo.maxDrivingAge && detailsInfo.module == 1">
            <span >驾驶员驾龄要求 :
              <span class="detail-text cl333333" v-if="detailsInfo.driverProvider == 2 && detailsInfo.maxDrivingAge">{{detailsInfo.minDrivingAge}}~{{detailsInfo.maxDrivingAge}}年</span>
              <span class="detail-text cl333333" v-else>暂无信息</span>
            </span>
          </el-col>
          <el-col :span="12">
            <span  >付款方式 : <span class="cl333333">{{
                  '在线付款'
                }}</span></span>
          </el-col>
          <el-col :span="12">
            <span  >支付方式 : <span class="cl333333">{{
                  '全额支付'
                }}</span></span>
          </el-col>

          <el-col :span="24" v-if="detailsInfo.installRequirement && detailsInfo.module != 1">
            <span >安装要求 : <span class="cl333333">{{ detailsInfo.installRequirement ? detailsInfo.installRequirement : "暂无信息"}}</span></span>
          </el-col>
          <el-col :span="24" v-if="detailsInfo.fuelCostExplain">
            <span >油料要求 : <span class="cl333333">{{ detailsInfo.fuelCostExplain ? detailsInfo.fuelCostExplain : "暂无信息"}}</span></span>
          </el-col>
          <el-col :span="24" v-if="detailsInfo.repairCostExplain">
            <span >维修要求 : <span class="cl333333">{{ detailsInfo.repairCostExplain ? detailsInfo.repairCostExplain : "暂无信息"}}</span></span>
          </el-col>
          <div v-if="detailsInfo.costExplainOther && detailsInfo.costExplainOther.length > 0 &&  detailsInfo.costExplainOther != '[]' ">
            <el-col :span="24" v-for="(item, index) in detailsInfo.costExplainOther" :key="index" style="padding-bottom:20px">
              <p class="info-item">
                <span class="title-text">{{item.title}}：</span>
                <span class="detail-text"><span class="cl333333">{{item.value}}</span></span>
              </p>
            </el-col>
          </div>
        </el-row>
        <el-row class="infoBox" v-if="detailsInfo.buyerNeedInvoice == 1 && detailsInfo.invoiceInfoVo && detailsInfo.invoiceInfoVo.invoiceTitle">
          <el-col :span="24">
            <span style="color:#333333;font-weight:700">开票信息</span>
          </el-col>
          <el-col :span="12">
            <span >单位名称 : <span class="cl333333">{{detailsInfo.invoiceInfoVo.invoiceTitle}}</span></span>
          </el-col>
          <el-col :span="12">
            <span >税号 : <span class="cl333333">{{detailsInfo.invoiceInfoVo.creditCode}}</span></span>
          </el-col>
          <el-col :span="12">
            <span >开户银行 : <span class="cl333333">{{detailsInfo.invoiceInfoVo.ownerBank}}</span></span>
          </el-col>
          <el-col :span="12">
            <span >银行账号 : <span class="cl333333">{{detailsInfo.invoiceInfoVo.blankAccount}}</span></span>
          </el-col>
          <el-col :span="12">
            <span >地址 : <span class="cl333333">{{detailsInfo.invoiceInfoVo.address}}</span></span>
          </el-col>
          <el-col :span="12">
            <span >企业电话 : <span class="cl333333">{{detailsInfo.invoiceInfoVo.phone}}</span></span>
          </el-col>
        </el-row>
      </div>
    </div>
  </div>
</div>
</template>

<script>
export default {
  props: {
    detail: {
      type: [Object, Array],
      default: () => {
        return []
      }
    }
  },
  data() {
    return {
      goodsInfo: {},
      detailsInfo: {},
    }
  },
  computed: {
    // finallyDetail ({detail, calcAmount}) {
    //   let d = detail.map(item => {
    //     return {
    //       ...item.detailsInfo,
    //       // amount: calcAmount(item.detailsInfo)
    //     }
    //   })
    //   let obj = JSON.parse(detail[0].orderInfo.orderSnapshotVo.productInfo)
    //   console.log("#########", obj);
    //   this.goodsInfo = obj
    //   this.detailsInfo = detail[0].orderInfo
    //   this.detailsInfo.costExplainOther = detail[0].orderInfo.costExplainOther ? JSON.parse(detail[0].orderInfo.costExplainOther) : []
    //   console.log("#########goodsInfo", obj);
    //   console.log("#########detailsInfo", this.detailsInfo );
    //   return d
    // }
  },
  filters: {
    timePro(times) {
      let date = new Date(Number(times) + 8 * 3600 * 1000);
      let str = date.toJSON() ? date.toJSON().substr(0, 19).replace("T", " ") : ''
      return str.split(' ')[0].replace('-', '年').replace('-', '月') + '日'
    }
  },
  mounted() {
    let obj = JSON.parse(this.detail[0].orderInfo.orderSnapshotVo.productInfo)
    console.log("#########", obj);
    this.goodsInfo = obj
    this.detailsInfo = this.detail[0].orderInfo
    this.detailsInfo.costExplainOther = this.detail[0].orderInfo.costExplainOther ? JSON.parse(this.detail[0].orderInfo.costExplainOther) : []

    console.log("#########goodsInfo", obj);
    console.log("#########detailsInfo", this.detailsInfo );
  },
  methods: {
    calcAmount (detailsInfo) {
      const {amount = 0, list = []} = detailsInfo
      let price = 0
      list.map(item => {
        const { costs = [] } = item
        costs.map(it => {
          price += it.money
        })
      })
      return amount + price
    },
    // 计算安装费 配送费 装卸费
    calcCosts (data = [], type) {
      let price = 0
      data.map(item => {
        if (item.type === type) {
          price += item.money
        }
      })
      return price
    }
  }
}
</script>

<style lang='scss' scoped>
.material {
  border: 1px solid #E4E7ED;
  margin-top: 20px;
  .flex {
    display: flex;
    align-items: flex-start;
  }
  .mb15 {
    margin-bottom: 15px;
  }

  .titleText {
    display: inline-block;
  }

  .titleBox {
    display: inline-block;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }

  .infoBox > div {
    padding-bottom: 20px;
  }

 .pay {
    color: #FF6600;
  }

  .material-body {
    padding: 0 20px;
  }
  .material-title {
    color: #333333;
    font-size: 16px;
    background-color: #fafafa;
    padding: 11px 20px;
    font-weight: bold;
    border-bottom: 1px solid #E4E7ED;
  }
  .material-bottom {
    font-size: 14px;
    .pay-list {
      padding: 20px 0px;
      .title {
        color: #666666;
      }
      .pay {
        color: #FF6600;
      }
    }
    .pay-list:not(:last-child) {
      border-bottom: 1px dashed #E4E7ED;
    }
  }
  .price-wrap {
    span {
      margin-right: 50px;
    }
  }
  .list-wrap1 {
    padding-top: 20px;
    color: #666666;
    font-size: 14px;
  }
  .list-wrap {
    color: #333333;
    font-size: 14px;

    border-bottom: 1px dashed #E4E7ED;
    padding-top: 20px;
    .pay-list {
      font-size: 14px;
      .pay {
        color: #FF6600;
      }
    }
  }
  .list-item {
    font-size: 14px;
    padding-bottom: 10px;
    .item-name {
      color: #333333;
      font-weight: bold;
      flex: 1;
      // white-space: nowrap;
      // overflow: hidden;
      // text-overflow: ellipsis;
    }
    .skuitem {
      flex: 1;
      margin-left: 20px;
      color: #333333;
      font-size: 14px;
      // white-space: nowrap;
      // overflow: hidden;
      // text-overflow: ellipsis;
      span {
        // padding-left: 10px;
      }
    }
    .brand-wrap {
      margin-left: 20px;
      width: 100px;
      color: #333333;
      font-size: 14px;
    }
  }
  .cgsl {
    max-width: 144px;
    overflow: hidden;
  }
  .dj {
    max-width: 169px;
    overflow: hidden;
  }
}
</style>
