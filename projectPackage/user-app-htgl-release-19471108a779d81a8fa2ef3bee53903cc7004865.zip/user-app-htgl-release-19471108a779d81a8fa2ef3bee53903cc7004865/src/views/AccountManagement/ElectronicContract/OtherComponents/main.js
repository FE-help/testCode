import Material from './Material';
import Zulin from './Zulin';

// 业务模块组件名字
const APPLY_MODES = {
  Material: 'Material',
  Zulin: 'Zulin',
}

export {
  Material,
  Zulin,
  APPLY_MODES
}