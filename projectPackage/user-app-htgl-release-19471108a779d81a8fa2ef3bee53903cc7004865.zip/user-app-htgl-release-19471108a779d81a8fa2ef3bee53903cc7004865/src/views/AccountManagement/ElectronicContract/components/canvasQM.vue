/**
* @Descripttion: 未描述
* @Author: Chenbangquan
* @version: 1.0.0
* @CreateDate 2021-12-14 17:54
* @LastEditors: cbq
* @LastEditTime: 2021-12-14
*/
<template>
  <div>
    <section class="signature">
      <div class="signatureBox">
        <div class="canvasBox" ref="canvasHW">
          <canvas ref="canvasF"
                  id="canvas"
                  class="canvasF"
                  @touchstart='touchStart'
                  @touchmove='touchMove'
                  @touchend='touchEnd'
                  @mousedown="mouseDown"
                  @mousemove="mouseMove"
                  @mouseup="mouseUp"></canvas>
          <!--<p style="margin:0 0 10px;line-height:20px;color:#999;">注：重写后请重新上传签名</p>-->
          <div class="btnBox">
            <el-button size="small" type="primary" @click="overwrite">取消</el-button>
            <el-button size="small" type="primary" @click="commit">签字完成</el-button>
          </div>
        </div>
      </div>
      <img class="imgCanvas" :src="imgUrl">
    </section>
  </div>
</template>

<script>
	export default {
		data () {
			return {
				stageInfo: '',
				imgUrl: '',
				client: {},
				points: [],
				canvasTxt: null,
				startX: 0,
				startY: 0,
				moveY: 0,
				moveX: 0,
				endY: 0,
				endX: 0,
				w: null,
				h: null,
				isDown: false,
				isViewAutograph: this.$route.query.isViews > 0,
				contractSuccess: this.$route.query.contractSuccess
			}
		},
		mounted () {
			// 找到 <canvas> 元素
			let canvas = this.$refs.canvasF
			// canvas.height = this.$refs.canvasHW.offsetHeight - 87
			// canvas.width = this.$refs.canvasHW.offsetWidth - 2
			canvas.height = 200
			canvas.width = 1240
			// 创建 context 对象
			this.canvasTxt = canvas.getContext('2d')
			this.stageInfo = canvas.getBoundingClientRect()
		},
		methods: {
			//mobile
			touchStart (ev) {
				ev = ev || event
				ev.preventDefault()
				if (ev.touches.length == 1) {
					let obj = {
						x: ev.targetTouches[0].clienX,
						y: ev.targetTouches[0].clientY,
					}
					this.startX = obj.x
					this.startY = obj.y
					this.canvasTxt.beginPath()
					this.canvasTxt.moveTo(this.startX, this.startY)
					this.canvasTxt.lineTo(obj.x, obj.y)
					this.canvasTxt.stroke()
					this.canvasTxt.closePath()
					this.points.push(obj)
				}
			},
			touchMove (ev) {
				ev = ev || event
				ev.preventDefault()
				if (ev.touches.length == 1) {
					let obj = {
						x: ev.targetTouches[0].clientX - this.stageInfo.left,
						y: ev.targetTouches[0].clientY - this.stageInfo.top
					}
					this.moveY = obj.y
					this.moveX = obj.x
					this.canvasTxt.beginPath()
					this.canvasTxt.moveTo(this.startX, this.startY)
					this.canvasTxt.lineTo(obj.x, obj.y)
					this.canvasTxt.stroke()
					this.canvasTxt.closePath()
					this.startY = obj.y
					this.startX = obj.x
					this.points.push(obj)
				}
			},
			touchEnd (ev) {
				ev = ev || event
				ev.preventDefault()
				if (ev.touches.length == 1) {
					let obj = {
						x: ev.targetTouches[0].clientX - this.stageInfo.left,
						y: ev.targetTouches[0].clientY - this.stageInfo.top
					}
					this.canvasTxt.beginPath()
					this.canvasTxt.moveTo(this.startX, this.startY)
					this.canvasTxt.lineTo(obj.x, obj.y)
					this.canvasTxt.stroke()
					this.canvasTxt.closePath()
					this.points.push(obj)
				}
			},
			//pc
			mouseDown (ev) {
				ev = ev || event
				ev.preventDefault()
				if (1) {
					// 鼠标相对于事件源元素（srcElement）的X,Y坐标
					let obj = {
						x: ev.offsetX,
						y: ev.offsetY
					}
					this.startX = obj.x
					this.startY = obj.y
					// 起始一条路径，或重置当前路径
					this.canvasTxt.beginPath()
					// 把路径移动到画布中的指定点，不创建线条
					this.canvasTxt.moveTo(this.startX, this.startY)
					// 添加一个新点，然后在画布中创建从该点到最后指定点的线条
					this.canvasTxt.lineTo(obj.x, obj.y)
					// 绘制已定义的路径
					this.canvasTxt.stroke()
					// 创建从当前点回到起始点的路径
					this.canvasTxt.closePath()
					this.points.push(obj)
					this.isDown = true
				}
			},
			mouseMove (ev) {
				ev = ev || event
				ev.preventDefault()
				if (this.isDown) {
					let obj = {
						x: ev.offsetX,
						y: ev.offsetY
					}
					this.moveY = obj.y
					this.moveX = obj.x
					this.canvasTxt.beginPath()
					this.canvasTxt.moveTo(this.startX, this.startY)
					this.canvasTxt.lineTo(obj.x, obj.y)
					this.canvasTxt.stroke()
					this.canvasTxt.closePath()
					this.startY = obj.y
					this.startX = obj.x
					this.points.push(obj)
				}
			},
			mouseUp (ev) {
				ev = ev || event
				ev.preventDefault()
				if (1) {
					let obj = {
						x: ev.offsetX,
						y: ev.offsetY
					}
					this.canvasTxt.beginPath()
					this.canvasTxt.moveTo(this.startX, this.startY)
					this.canvasTxt.lineTo(obj.x, obj.y)
					this.canvasTxt.stroke()
					this.canvasTxt.closePath()
					this.points.push(obj)
					this.points.push({ x: -1, y: -1 })
					this.isDown = false
				}
			},
			//重写
			overwrite () {
				this.canvasTxt.clearRect(0, 0, this.$refs.canvasF.width, this.$refs.canvasF.height)
				this.points = []
				this.imgUrl = ""
        this.$emit('setShowsignatureFlag',false)
			},
			isCanvasBlank(canvas) {
				var blank = document.createElement('canvas');//系统获取一个空canvas对象
				blank.width = canvas.width;
				blank.height = canvas.height;
				return canvas.toDataURL() == blank.toDataURL();//比较值相等则为空
			},
			//提交签名
			commit () {
				var c =document.getElementById("canvas"); // 获取html的canvas对象，我这个id="canvas"
				if(this.isCanvasBlank(c)){
					this.$message({
						message: '请完成签字！',
						type: 'warning'
					})
					return;
				}
				let obj = {
					cno:this.$htgl_user.cno,
          signImg:this.$refs.canvasF.toDataURL()
        }
				this.$emit('writeSignature',obj)
				// this.imgUrl = this.$refs.canvasF.toDataURL();
			}
		}
	}
</script>

<style scoped>
  .signature {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    z-index: 1;
    border-bottom: 1px solid #f5f5f5;
    /*background-color: #ffffff;*/
  }
  .signatureBox {

    width: 100%;
    /*height: calc(100% - 50px);*/
    height: auto;
    box-sizing: border-box;
    overflow: hidden;
    background: #fff;
    z-index: 100;
    display: flex;
    flex-direction: column;
  }
  .canvasBox {
    box-sizing: border-box;
    flex: 1;
  }
  canvas {
    border: none;
    /*border-radius: 4px;*/
    box-sizing: border-box;
  }
  .btnBox{
    padding:  0 20px;
    text-align: right;
  }
</style>
