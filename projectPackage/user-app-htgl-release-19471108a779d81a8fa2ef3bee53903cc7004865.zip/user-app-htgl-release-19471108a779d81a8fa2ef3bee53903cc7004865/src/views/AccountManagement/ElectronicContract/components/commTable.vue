<template>
  <div class="table">
    <el-table
            :data="tableData.tableData"
            border
            :header-cell-style="$TableCell.setHeaderCellStyle"
            :cell-style="$TableCell.setCellStyle"
            style="width: 100%;"
    >
      <el-table-column :resizable="false" label="编号" align="left"  type="index" width="55"></el-table-column>
      <el-table-column :resizable="false" label="商品名称" align="left">
        <template slot-scope="scope">{{scope.row.title}}</template>
      </el-table-column>
      <el-table-column :resizable="false" label="规格型号" align="left">
        <template slot-scope="scope">
          <span v-for="(item, index) in scope.row.attrs" :key="index">{{item.k}}{{item.v}}</span>
        </template>
      </el-table-column>
      <!--<el-table-column show-overflow-tooltip :resizable="false" label="品牌" align="left">-->
        <!--<template slot-scope="scope">-->
          <!--<span v-if="scope.row.brandName">{{scope.row.brandName}}</span>-->
          <!--<span v-else>/</span>-->
        <!--</template>-->
      <!--</el-table-column>-->
      <el-table-column :resizable="false" label="单位" align="left">
        <template slot-scope="scope">{{scope.row.unit}}</template>
      </el-table-column>
      <el-table-column :resizable="false" label="数量" align="left">
        <template slot-scope="scope">{{scope.row.num.toFixed(3)}}</template>
      </el-table-column>
      <!--<el-table-column show-overflow-tooltip :resizable="false" label="税率" align="left">-->
        <!--<template slot-scope="scope">-->
          <!--<span v-if="scope.row.tax">{{scope.row.tax}}%</span>-->
          <!--<span v-else>/</span>-->
        <!--</template>-->
      <!--</el-table-column>-->
      <el-table-column :resizable="false" label="单价含税" align="left">
        <template slot-scope="scope">{{scope.row.price.toFixed(2)}}元</template>
      </el-table-column>
      <el-table-column  :resizable="false" label="总计含税" align="left">
        <template slot-scope="scope">
                <span
                        v-if="scope.row.subtotal"
                        style="color: #FF6600"
                >{{scope.row.subtotal.toFixed(2)}}元</span>
          <span v-else>/</span>
        </template>
      </el-table-column>
      <el-table-column prop="address" label="商品备注" width="260">
        <template slot-scope="scope">
          <el-input maxlength="32" type="textarea" v-if="saveState && (contractStatu == 0 || contractStatu == 10)" class="inputRemark" v-model="scope.row.remark" placeholder="请填写备注"></el-input>
          <span v-else>{{scope.row.remark}}</span>
        </template>
      </el-table-column>
    </el-table>
    <div class="tableDiv">
      <p>
        合计：（大写）<span v-if="OrderDetail.totalPrice">{{NumberToChinese(OrderDetail.totalPrice)}}</span>
        &nbsp;&nbsp;&nbsp;&nbsp;（小写）
        <span v-if="OrderDetail.totalPrice">{{number_format(OrderDetail.totalPrice,2, ".", ",")}}（元）</span>
      </p>
    </div>
    <div class="tableArea">
      <el-input :autosize="autosize" row='10' maxlength="200" type="textarea" v-if="saveState && (contractStatu == 0 || contractStatu == 10)" class="inputRemark" v-model="tableData.totalRemark" placeholder="请填写商品清单备注"></el-input>
      <span v-else>{{tableData.totalRemark}}</span>
    </div>
  </div>
</template>
<script>
import { setColumnDataColor, setCellStyle } from './style'

export default {
  name: 'commTable',
  props: {
	    tableData: {
		    type: Object
	    },
	    contractStatu: {
	    	type: String
    },
	  // totalRemark:{
	  //   	type:Object
    // },
	    OrderDetail: {
	    	type: Object
    },
	    saveState: {
	    	type: Boolean
    }
  },
  data () {
    return {
	    autosize: true,
      aa: '',
      setColumnDataColor,
      setCellStyle,
      unit: new Array('仟', '佰', '拾', '', '仟', '佰', '拾', '', '角', '分')
    }
  },
  mounted () {
  	console.log(this.tableData)
  },
  methods: {
	    number_format (number, decimals, dec_point, thousands_sep) {
		    /*
        * 参数说明：
        * number：要格式化的数字
        * decimals：保留几位小数
        * dec_point：小数点符号
        * thousands_sep：千分位符号
        * */
		    number = (number + '').replace(/[^0-9+-Ee.]/g, '')
		    var n = !isFinite(+number) ? 0 : +number

      var prec = !isFinite(+decimals) ? 0 : Math.abs(decimals)

      var sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep

      var dec = (typeof dec_point === 'undefined') ? '.' : dec_point

      var s = ''

      var toFixedFix = function (n, prec) {
				    var k = Math.pow(10, prec)
				    return '' + Math.ceil(n * k) / k
			    }
		    s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.')
		    var re = /(-?\d+)(\d{3})/
		    while (re.test(s[0])) {
			    s[0] = s[0].replace(re, '$1' + sep + '$2')
		    }
		    if ((s[1] || '').length < prec) {
			    s[1] = s[1] || ''
			    s[1] += new Array(prec - s[1].length + 1).join('0')
		    }
		    return s.join(dec)
	    },
	    toDx (n) { // 阿拉伯数字转换函数
		    switch (n) {
			    case '0':
				    return '零'
			    case '1':
				    return '壹'
			    case '2':
				    return '贰'
			    case '3':
				    return '叁'
			    case '4':
				    return '肆'
			    case '5':
				    return '伍'
			    case '6':
				    return '陆'
			    case '7':
				    return '柒'
			    case '8':
				    return '捌'
			    case '9':
				    return '玖'
		    }
	    }, // 转换算法主函数
	    NumberToChinese (m) {
		    m *= 100
		    m += ''
		    var length = m.length

		    var result = ''
		    for (var i = 0; i < length; i++) {
			    if (i == 2) {
				    result = '元' + result
			    } else if (i == 6) {
				    result = '万' + result
			    }
			    if (m.charAt(length - i - 1) == 0) {
				    if (i != 0 && i != 1) {
					    if (result.charAt(0) != '零' && result.charAt(0) != '元' && result.charAt(0) != '万') {
						    result = '零' + result
					    }
				    }
				    continue
			    }
			    result = this.toDx(m.charAt(length - i - 1)) + this.unit[this.unit.length - i - 1] + result
		    }
		    result += result.charAt(result.length - 1) == '元' ? '整' : ''
		    return result
	    }
  }
}
</script>

<style scoped>
  p{
    margin: 0;
    padding: 0;
  }
>>> .inputRemark .el-input__inner{
  border: none;
  padding: 0;
  min-height: 45px;
}
  .tableArea .el-textarea{
    width: 100% !important;
  }
</style>
<style scoped lang="scss" rel="stylesheet/scss">
  .table{
    position: relative;
    .tableDiv{
      font-size: 14px;
      color: #666666;
      width: calc(100% - 42px);
      height: 47px;
      line-height: 47px;
      border: 1px solid #ebeef5;
      border-top: none;
      padding: 0 20px;
      span{
        color: #FF6600;
      }
    }
    .tableArea{
      border: 1px solid #ebeef5;
      border-top: none;
      padding: 5px 20px;
      min-height: 100px;
      span{
        font-size: 14px;
        color: #666666;
      }
    }
  }
</style>
