<template>
  <div></div>
</template>

<script>
	import domtoimage from 'dom-to-image';
	export default {
		name: 'App',
		data() {
			return {
				a4h:1200,
				imgarr:[]
			}
		},
		methods:{
			tosvg(domid, val){
				this.imgarr = []
        let el=document.getElementById(domid)
        let scale=0.8
				if(true){
					el.style.transform=`scale(${scale})`
					el.style.transformOrigin='0 0'
				}
				domtoimage.toSvg(el).then(dataUrl=>{
					let img = new Image();
					img.src = dataUrl;
					img.onload=()=>{
						if(true){
							img.width = el.clientWidth*scale+5//右边框线不对
              img.height =el.clientHeight*scale
              this.a4h =1200*scale
						}
						this.imagepage(img,this.a4h,val)
					}
				})
			},
			/* （图像，分页高） */
			imagepage(image,a4h,val){
				let can = document.createElement('canvas');
				can.width = image.width;
				can.height = a4h;
				let ctx=can.getContext('2d');

				let pagetop=0;
				while(pagetop<image.height){
          can.width = image.width;
					can.height = a4h;
          ctx.fillStyle="#fff";
          ctx.fillRect(0,0,can.width,can.height);
					ctx.drawImage(image,0, pagetop ,image.width,a4h,0,0,image.width,a4h)


					let deviation = this.coumputDevoation(can,can.height);
          let canHeight = a4h - deviation;
					if(deviation){
            ctx.fillStyle="#fff";
            ctx.fillRect(0,0,image.width,a4h);
						ctx.drawImage(image, 0, pagetop ,image.width,canHeight,0,0,image.width,canHeight)
					}
          this.imgarr.push(can.toDataURL('image/jpeg', 1))
					pagetop+=canHeight;
				}
        if(this.imgarr.length>120){
	        this.$message({
		        message: '当前仅支持120页以内的合同，请重新编辑！\n',
		        type: 'warning'
	        })
	        this.$emit('setLoading', false) //setLoading
          return
        }
				this.$emit('publicPdf',val,this.imgarr)
			},
			//计算底部最近白线位置
			coumputDevoation(canvas,sumheight){
				let deviation=0;
				let next=0;
				while(next<sumheight){
					//获取一行数据
					let data=canvas.getContext('2d').getImageData(0, sumheight - deviation, canvas.width, 1).data;
					let back=false;
					for(let i in data){
						if(data[i]!=255){
							back=true;
							break;
						}
					}

					if(back){
						next++
						deviation=next;//上一行
					}else{
						next=sumheight
						break;
					}
				}
				if(deviation==sumheight)deviation=0
				return deviation
			},
		}
	}
</script>

<style>
  #app{}
  #win {
    position: fixed;
    top: 0;
    right: 0;
    height: 780px;
    width: 500px;
    text-align: left;
    border: solid 1px !important;
    overflow: hidden;
    overflow-y: auto;
  }
  #pdf{
    position: fixed;
    top:0;
    left: 300px;
    width: 300px;
    overflow: hidden;
  }
  .can{
    min-height: 740px;
    line-height: 22px;
    background-color: #fff;
    color: red;
  }
  canvas{
    border-bottom: 1px solid #000000;
  }
</style>
