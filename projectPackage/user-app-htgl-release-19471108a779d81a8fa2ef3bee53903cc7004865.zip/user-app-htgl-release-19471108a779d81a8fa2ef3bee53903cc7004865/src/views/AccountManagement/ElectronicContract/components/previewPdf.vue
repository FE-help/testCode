<template>
  <div>
    <!-- 填充文本 -->
    <el-row id="pdfDom" ref="pdfDomsss" class="pdfDom" >
      <el-col :span="20">
        <div class="templateBox1" >
          <el-col :span="24" style="width: 841.89px">
            <el-form :model="data" :label-position="labelPosition" label-width="124px" >
              <el-col :span="24"><p class="title target-node-item">{{data.title}}</p></el-col>
              <el-col :span="24"><p class="contractNo">合同编号：<span>{{data.no}}</span></p></el-col>
              <el-col :span="24"><div class="mt20"></div></el-col>
              <el-col :span="24" v-for="(item, index) in contractCompany" :key="`${item}${index}`">
                <el-form-item :label="`${item.name}方：`" class="fontColor target-node-item" label-width="60px">
                  <span class="fontColor">{{item.companyDetail.companyName}}</span>
                </el-form-item>
              </el-col>
              <el-col :span="24"><div v-html="data.rule1" class="rule1 target-node-item"></div></el-col>
              <el-col :span="24">
                <component :is="currentComponent" :detail="data.orderDetail" :border="false"></component>
                <component :is="currentComponent" :detail="data.orderDetail" :border="false"></component>
                <component :is="currentComponent" :detail="data.orderDetail" :border="false"></component>
                <component :is="currentComponent" :detail="data.orderDetail"></component>
                <component :is="currentComponent" :detail="data.orderDetail"></component>
                <component :is="currentComponent" :detail="data.orderDetail"></component>
                <component :is="currentComponent" :detail="data.orderDetail"></component>
                <component :is="currentComponent" :detail="data.orderDetail"></component>
                <component :is="currentComponent" :detail="data.orderDetail"></component>
                <component :is="currentComponent" :detail="data.orderDetail"></component>
                <component :is="currentComponent" :detail="data.orderDetail"></component>
                <component :is="currentComponent" :detail="data.orderDetail"></component>
                <component :is="currentComponent" :detail="data.orderDetail"></component>
                <component :is="currentComponent" :detail="data.orderDetail"></component>
                <component :is="currentComponent" :detail="data.orderDetail"></component>
                <component :is="currentComponent" :detail="data.orderDetail"></component>
                <component :is="currentComponent" :detail="data.orderDetail"></component>
              </el-col>
              <el-col :span="24"><div class="mt20"></div></el-col>
              <el-col :span="24" v-for="(item,index) in customFiled" :key="index">
                <p style="font-size: 16px;font-weight: bold;color: #333333;line-height: 30px">{{item.title}}</p>
                <div class="rule1 target-node-item" style="font-weight: 400;color: #333333;line-height: 30px">{{item.span}}</div>
                <div class="mt20"></div>
              </el-col>
              <el-col :span="24" v-for="(item,index) in TinymceData" :key="index">
                <p style="font-size: 16px;font-weight: bold;color: #333333;line-height: 30px">{{item.title}}</p>
                <div v-html="item.rule" class="rule1 target-node-item" style="font-weight: 400;color: #333333;line-height: 30px"></div>
                <div class="mt20"></div>
              </el-col>

              <el-col :span="24"><div class="mt30"></div></el-col>
              <el-col :span="12" v-for="(item, index) in contractCompany" :key="`${item}${index}111`">
                <el-form-item :label="`${item.name}方（盖章）：`" class="fontColor target-node-item">
                  <span class="fontColor">{{item.companyDetail.companyName}}</span>
                </el-form-item>
                <el-form-item label="法定代表人：" class="fontColor target-node-item">
                  <span class="fontColor">{{item.companyDetail.legalRepresentative}}</span>
                </el-form-item>
                <el-form-item label="授权委托人：" class="fontColor target-node-item">
                  <span class="fontColor">{{item.companyDetail.consignor}}</span>
                </el-form-item>
                <el-form-item label="地址：" class="fontColor target-node-item">
                  <span class="fontColor">{{item.companyDetail.address}}</span>
                </el-form-item>
                <el-form-item label="电话：" class="fontColor target-node-item">
                  <span class="fontColor">{{item.companyDetail.phone}}</span>
                </el-form-item>
              </el-col>
            </el-form>

          </el-col>
        </div>
      </el-col>
    </el-row>
    <!-- 分节器 -->
    <div id="pdf" :style="{height:a4h*page+'px'}">
      <div id="pdfDomBody"></div>
    </div>
  </div>
</template>

<script>
	import html2canvas from "html2canvas";
	import JsPDF from 'jspdf'
	import { APPLY_MODES, Material, Zulin } from '../OtherComponents/main.js';

	export default {
		name: 'previewPdf',
    props:{
			data:{
				type:Object
      },
	    contractCompany:{
				type:Array
      },
	    customFiled:{
				type:Array
      },
	    TinymceData:{
				type:Array
      }
    },
		data() {
			return {
				type: 'Material',
				labelPosition: 'right',
				height:0,
				a4h:841,
				page:10,
				pdf:new JsPDF('x', 'pt', 'a4'),
				imgarr:[],
				margin:0,
				progress:null,
			}
		},
    computed:{
	    currentComponent() {
		    return APPLY_MODES[this.type]
	    }
    },
		mounted() {},
		methods:{
			sendContract(val){
				//复制填充转换内容
				this.height=document.getElementById('pdfDom').offsetHeight;
				this.progress = Math.floor(this.height/this.a4h)
				document.getElementById('pdfDomBody').appendChild(document.getElementById('pdfDom').cloneNode('true'))
				this.part(val);
      },
			part(val){
				html2canvas(document.getElementById('pdf')).then(canvas=>{
					this.canvaspage(canvas,val)
					document.getElementById('pdfDomBody').style.marginTop = `${this.margin}px`;
					if(-this.margin<this.height){
						this.part(val)
					}
				});
			},
			//计算底部最近白线位置
			coumputDevoation(canvas,sumheight){
				let deviation= 0;
				let next= 0;
				while(next < sumheight){
					//获取一行数据
					let data= canvas.getContext('2d').getImageData(0, sumheight - deviation, canvas.width, 1).data;
					let back=false;
					for(let i in data){
						if(data[i]!=255){
							back= true;
							break;
						}
					}
					//一行有颜色
					if(back){
						deviation= next;//上一行
						next++
					}else{
						break;
					}
				}
				return deviation
			},
			//截取分页图片
			canvaspage(canvas,val){
				let can = document.createElement('canvas');
				can.width = canvas.width;
				can.height = this.a4h;
				let ctx = can.getContext('2d');

				let pagetop = 0;
				let deviation = 0;//页偏移
				let conut = 0
				while(pagetop<canvas.height-10){
					can.height = this.a4h - deviation;
					ctx.clearRect(0,0,can.width,can.height);
					let image = canvas.getContext('2d').getImageData(0,pagetop,can.width,can.height);
					ctx.putImageData(image,0,0);
					deviation = this.coumputDevoation(can,can.height);
					if(deviation){
						ctx.clearRect(0,0,can.width,can.height);
						can.height = this.a4h - deviation;
						let image = canvas.getContext('2d').getImageData(0,pagetop,can.width,can.height);
						ctx.putImageData(image,0,0);
					}
					conut++
					this.imgarr.push(can.toDataURL('image/jpeg', 1))
					this.margin-=can.height;
					pagetop+=can.height;
					deviation = 0;
					if(-this.margin >= this.height || conut<= this.page){
						if(this.imgarr.length == this.progress){
              this.$emit('publicPdf',val , this.imgarr)
						}
						break;
					}

				}
			}
		},
    components:{
	    Material,
	    Zulin,
    }
	}
</script>

<style scoped lang="scss">
  .pdfDom{
    width: 841.89px;
    position: fixed;
    z-index: -1;
    background-color: #ffffff;
    .templateBox1{
      /*width: 522px;*/
      /*margin: 0 auto;*/
      width: 841.89px;
      /*padding: 0 50px;*/
      padding-top: 80px;
      position: relative;
      .title{
        text-align: center;
        padding: 0 0 40px 0;
        font-size: 24px;
        color: #000000;
        width: 100%;
        margin: 0 auto;
        font-weight: bold;
        span{
          display: block;
          width: 100%;
        }
      }
      .contractNo {
        text-align: right;
        font-size: 14px;
        color: #333333;
        span{
          color: #000000;
        }
      }
      .fontColor{
        font-size: 16px;
        color: #000000;
        font-weight: bold;
      }
    }
  }
  #win {
    position: fixed;
    top: 0;
    left: 0;
    z-index: -1;
    height: 780px;
    width: 841.89px;
    text-align: left;
    border: solid 1px !important;
    overflow: hidden;
    overflow-y: auto;
    background-color: #ffffff;
  }
  #pdf{
    position: fixed;
    top:0;
    z-index: -1;
    left: 300px;
    width: 841.89px;
    overflow: hidden;
  }
  .can{
    min-height: 740px;
    line-height: 22px;
  }
  img,canvas{
    border-bottom: 1px solid #000000;
  }
</style>
