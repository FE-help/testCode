<template>
  <div>
    <div class="modelList">
      <ul class="clearfix">
        <li class="fl" @click="pitchOn()" :class="{pitchli: pitchIndex == null}">
          <div><img :src="img"></div>
          <p class="p2">空白模板</p>
        </li>
        <li v-for="(item, index) in modelList.records" :key="index" class="fl" :class="{pitchli: pitchIndex == index}" @click="pitchOn(item, index)">
          <p class="p1 clearfix"><span class="fl" @click="createModelBtn('view')">预览</span><span class="fr" @click="delTemplateBtn(item)">删除</span></p>
          <div><img :src="item.img"></div>
          <p class="p2">{{item.templateName}}</p>
        </li>
      </ul>
      <div class="pagination">
        <el-pagination
                @current-change="operationPageChange"
                :current-page.sync="modelList.current"
                :page-size="modelList.size"
                layout="prev, pager, next, jumper"
                :total="modelList.total"
        ></el-pagination>
      </div>
      <div style="text-align: center;padding: 20px 0">
        <el-button type="primary" @click="createModelBtn(createdType)">立即创建</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import apiContractTemplate from '@/api/apiContract/apiContract'
import img from '@/static/img/zhaocai.png'
export default {

  name: 'modelList',
  props: {
	    modelList: {
	    	type: Object
    },
	  createdType: {
	    	type: String
    }
  },
  data () {
    return {
      img: img,
      model: {
        page: 1,
        limit: 1
      },
      total: 0,
      pitchIndex: null
    }
  },
  mounted () {},
  methods: {
	    async delTemplateBtn (item) {
	    	let data = {
	    		id: item.id
      }
		    let res = await apiContractTemplate.postDelTemplate(data)
      if (res.data.code == 200) {
	        this.$message({
		        message: res.data.msg,
		        type: res.data.code == 200 ? 'success' : res.data.code !== 200 ? 'error' : ''
	        })
	        let model = {
		        page: 1,
		        limit: 10
	        }
	        // 获取模板数据
	        let res1 = await apiContractTemplate.gettemplateList(model)
	        res1.data.data.records.forEach(item => {
		        item.img = img
	        })
	        this.$emit('setmodelList', true, res1.data.data)
      }
    },
	    operationPageChange (val) {
		    // 分页点击事件
		    this.page = Number(val)
	    },
	    pitchOn (item, index) {
	    	this.pitchIndex = index
      this.modelInfo = item
    },
	    createModelBtn (type) {
		    this.$emit('createBtn', true, this.modelInfo, type)
    }
  }
}
</script>
<style scoped>

</style>
<style scoped lang="scss" rel="stylesheet/scss">
  .pagination{
    text-align: center;
    margin-top: 20px;
  }
  p{
    padding: 0;
    margin: 0;
  }
.modelList{
  ul{
    padding: 0;
    margin: 0;
    list-style: none;
    .pitchli{
      border: 1px solid #fa4f16;
    }
    li{
      overflow: hidden;
      width: 18.98%;
      margin-left: 1%;
      text-align: center;
      border: 1px solid #E4E7ED;
      position: relative;
      margin-top: 20px;
      &:nth-child(1){
        margin: 0;
        margin-top: 20px;
      }
      &:nth-child(6){
        margin: 0;
        margin-top: 20px;
      }
      &:hover{
        .p1{
          top: 0;
        }
      }
      div{
        img{
          width: 100%;
        }
      }
      .p1{
        padding: 0 20px;
        position: absolute;
        left: 0;
        right: 0;
        top: -31px;
        height: 30px;
        line-height: 30px;
        background: rgba(0,0,0,.5);
        color: #ffffff;
        font-size: 12px;
        span{
          cursor: pointer;
          &:nth-child(2){
            color: #FF6600;
          }
        }
      }
      .p2{
        position: absolute;
        left: 0;
        right: 0;
        bottom: 0;
        height: 30px;
        line-height: 30px;
        background: rgba(0,0,0,.5);
        color: #ffffff;
        font-size: 12px;
      }
    }
  }
}
</style>
