<template>
  <div class="Cashier">
    <div class="information">
      <p class="title">基本信息</p>
    </div>
    <!--<p style="line-height: 40px;background-color: #f5f5f5;border-bottom: 1px solid #e4e7ed;text-align: center">基本信息</p>-->
    <div style="padding: 0 10px" class="info">
      <p>合同分类：<span>{{info.typeName}}</span></p>
      <p>创建时间：
        <span v-if="info.createTime">{{time(info.createTime)}}</span>
        <span v-else></span>
      </p>
      <p>合同编号：<span>{{info.no}}</span></p>
      <p>关联订单编号：
        <span style="color: #0286DF" v-for="(item,index) in info.orderDetail" :key="index" class="cursor" @click="goOrderDetail(item.orderNo)">
            {{item.orderNo}}
          <!--去除最后一个逗号-->
          <span v-if="index < info.orderDetail.length -1">,</span>
        </span>
      </p>
      <p>合同发起方：<span>{{info.companyName}}</span></p>
      <div v-if="info.status == 2 || info.status == 3 || info.status == 4 || info.status == 5">
        <p v-for="(item,index) in info.involves" :key="index">
          <span v-if="item.contractPosition">{{item.contractPosition}}方签署时间：</span>
          <span v-if="item.signTime">{{time(item.signTime)}}</span>
          <span v-else>/</span>
        </p>
        <p>签署截止时间：
          <span v-if="info.deadline">{{time(info.deadline)}}</span>
          <span v-else>/</span>
        </p>
      </div>


      <!--合同状态 1:拟定中，2：签署中，3：已完成，4：已过期，5，已作废-->

    </div>
    <div style="height: 15px"></div>
    <div v-if="showTabPane">
      <div class="information">
        <p class="title">操作日志</p>
      </div>
      <div style="padding: 0 10px" class="log">
        <ul>
          <li v-for="(item,index) in logHistory" :key="index">
            <span class="time" v-if="item.createTime">{{time(item.createTime)}}</span>
            <p style="color:#666666;">{{item.companyName}}</p>
            <span class="operation">{{item.operation}}</span>
            <div class="remark" v-if="item.remark">理由：{{item.remark}}</div>
          </li>
        </ul>
      </div>
    </div>
    <div v-if="!showTabPane">
      <el-tabs v-model="activeName" @tab-click="handleClick" :stretch="true">
        <el-tab-pane label="操作日志" name="second">
          <div style="padding: 0 10px" class="log">
            <ul>
              <li v-for="(item, index) in logHistory" :key="index">
                <span class="time" v-if="item.createTime">{{time(item.createTime)}}</span>
                <p style="color:#666666;">{{item.companyName}}</p>
                <span class="operation">{{item.operation}}</span>
                <div class="remark" v-if="item.remark">理由：{{item.remark}}</div>
              </li>
            </ul>
          </div>
        </el-tab-pane>
        <el-tab-pane label="审批日志" name="first" v-if="processList.length > 0">
          <div style="padding: 0 10px" class="log">
            <process :approve="processList"/>
          </div>
          <div style="height: 30px"></div>
        </el-tab-pane>
        <el-tab-pane label="修改记录" name="thirdly" v-if="amendList.length > 0">
          <div style="padding: 0 10px" class="log">
            <ul>
              <li v-for="(item, index) in amendList" :key="index" style="padding: 10px 0">
                <p style="color:#333333;font-weight: bold">{{item.companyName}}</p>
                <p style="color: #666666">{{item.userName}}</p>
                <p style="color: #969696">{{time(item.createTime)}}</p>
                <p v-if="item.operation !== '新增字段已变更'">
                  <span style="color: #666666">{{item.operation}}</span>
                  <span style="color: #0286DF" class="cursor"
                        v-if="item.originalContent"
                        @click="putContent(item)">&nbsp;&nbsp;&nbsp;&nbsp;原内容></span>
                </p>
                <p v-else>
                  <span style="color: #666666">{{item.operation}}</span>
                  <span style="color: #0286DF" class="cursor"
                        v-if="JSON.parse(item.originalContent).length != 0"
                        @click="putContent(item)">&nbsp;&nbsp;&nbsp;&nbsp;原内容></span>
                </p>
              </li>
            </ul>
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>
    <el-dialog
            class="showPdf"
            title="该区域修改之前的合同内容"
            :visible.sync="show"
            width="700">
      <div class="templateContent" v-if="content && content.operation !== '新增字段已变更' && content.operation !== '甲乙方已变更'">
        <p>原合同内容</p>
        <span v-if="content" v-html="content.originalContent"></span>
      </div>
      <div class="templateContent" v-if="content && content.operation === '新增字段已变更' ">
        <p>原合同内容</p>
        <div v-for="(item,index) in JSON.parse(content.originalContent)" :key="index">
          <div>{{item.title}}</div>
          <span>{{item.span}}</span>
        </div>
      </div>
      <div class="templateContent" v-if="content && content.operation === '甲乙方已变更' ">
        <p>原合同内容</p>
        <div>
          <p>原甲方：<span>{{JSON.parse(content.originalContent)[0]}}</span></p>
          <p>原乙方：<span>{{JSON.parse(content.originalContent)[1]}}</span></p>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
	import apiContractTemplate from '@/api/apiContract/apiContract'
	import apiApprove from "@/api/apiMyApprove/index";

	export default {
		name: 'contractLog',
		props: {
			procesState: {},
			aprocessInfo: {},
      info: {
				type: Object
			},
			logHistory: {
				type: Array
			},
      logStatus: {
        type: Object,
        default: () => ({})
      },
			ApprovalLog: {
				type: Array
			}
		},
    components:{
	    Process: ()=> import("@/views/Upcoming/components/base/Process")
    },
		data () {
			return {
				show:false,
				content:null,
				//流程
				processList: [],
				amendList: [],
				// logHistory:[],
				activeName: 'second'
			}
		},
		computed:{
			showTabPane(){
				 return this.processList.length === 0 && this.amendList.length === 0
			}
    },
    watch:{
	    info(n){
	    	this.initData()
      },
	    content(n){
	    	this.content = n
      },
	    aprocessInfo(n) {
		    this.initData()
	    }
    },
		created () {
      this.initData()
    },
		methods: {
			putContent(item){
				this.content = item
        this.show = true
      },
			async initData() {
				let params = { id: this.info.auditId}
				let res = await apiApprove.ApprovalLog(params)
        console.log(res)
        if(res.data.data){
	        this.processList = res.data.data;
        }
        let res1 = await apiContractTemplate.findByContractNo(this.$route.query.no)

        if(res1.data.data){
	        this.amendList = res1.data.data;
	        console.log(this.processList.length === 0 && this.amendList.length === 0)
        }
			},
			formateItemType(){
				let obj ={
					//商品-采购合同
					1:`orderDetailSku`,
          //商品-销售合同
					2:`salesOrderDetailSku`,
        }
        console.log(obj[this.info.type])
				return obj[this.info.type]
      },
      // 招采跳转
      zhaocaiPush() {
        let url = '';
        const { isAdmin, isFabiaoren, isWintender, isZhaobiao, orderNo, type } = this.logStatus
        console.log('是否是管理员--->isAdmin'+':'+isAdmin)
        console.log('是否是发标人--->isFabiaoren'+':'+isFabiaoren)
        console.log('是否是中标人--->isWintender'+':'+isWintender)
        console.log('是否是招标--->isZhaobiao'+':'+isZhaobiao)
        if(isWintender) {
          // 中标方身份，点击跳转至 投标查询/竞价查询 列表
          url = isZhaobiao ? 'mybiddings' : 'CompeteBiddingTenderLists'
        } else {
          if(isFabiaoren || isAdmin) {
            // 当前用户是发标人或企业管理员，跳转到 用户中心-招标详情（竞价详情)
            url = isZhaobiao ? `tenderingdetailZBGL/${orderNo}` : `CompeteBiddingDetail?id=${orderNo}&type=${type}`

          } else {
            url = isZhaobiao ? 'tenderingmanagement' : 'CompeteBiddingList'
            // 当前用户不是发标人或企业管理员，点击后跳转至 用户中心-招采经营-招标管理（竞价管理）
          }
        };
        window.open(url, "_blank");
      },
			goOrderDetail(id){
        let url = "";
        if (this.info.type == 7 || this.info.type == 8) {
          this.zhaocaiPush();
          return;
        } else {
          url = this.formateItemType()
        };
				window.open(`${url}/${id}`, "_blank");
      },
			time (val) {
				var date = new Date(val)
				var year = date.getFullYear()
				var month = date.getMonth() + 1 // js从0开始取
				var date1 = date.getDate()
				var hour = date.getHours()
				var minutes = date.getMinutes()
				var second = date.getSeconds()

				if ((month + '').length === 1) {
					month = '0' + month
				}
				if ((date1 + '').length === 1) {
					date1 = '0' + date1
				}
				if ((hour + '').length === 1) {
					hour = '0' + hour
				}
				if ((minutes + '').length === 1) {
					minutes = '0' + minutes
				}
				if ((second + '').length === 1) {
					second = '0' + second
				}
				return (
					year +
					'-' +
					month +
					'-' +
					date1 +
					' ' +
					hour +
					':' +
					minutes +
					':' +
					second +
					''
				)
				//  return year + '年' + month + '月' + date1 + '日' + hour + '时' + minutes + '分' + second + '秒'
			},
			handleClick (tab, event) {
				console.log(tab, event)
			}
		}
	}
</script>
<style scoped lang="scss">
.templateContent {
  max-height: 300px;
  padding: 20px 0;
  overflow: auto;
  overflow-x: hidden;
  p{
    font-size: 16px;
    color: #333333;
    font-weight: bold;
    line-height: 30px;
  }
  span{
    font-size: 14px;
    color: #666666;
  }
}
</style>
<style scoped lang="scss" rel="stylesheet/scss">
  .Cashier {
    /*/deep/ .el-tabs__nav{*/
      /*background-color: #ffffff;*/
      /*border-bottom: 1px solid #e4e7ed;*/
    /*}*/
    /*/deep/ .el-tabs__active-bar{*/
      /*height: 1px;*/
      /*width: 60px !important;*/
      /*margin: 0 auto;*/
      /*left: 38px !important;*/
      /*background-color: #0286DF;*/
    /*}*/
    /*/deep/ .el-tabs__item{*/
      /*font-weight: bold;*/
    /*}*/
  }
  ul,p{
    list-style: none;
    padding: 0;
    margin: 0;
  }
  .info{
    font-size: 14px;
    p{
      color: #666666;
      padding: 5px 0;
      span{
        color: #333333;
      }
    }
  }
  .log{
    ul{
      li{
        line-height: 25px;
        font-size: 14px;
        min-height: 80px;
        .time{
          font-size: 14px;
          color: #969696;
        }
        p{
          color: #666666;
        }
        .operation{
          color: #0286DF;
        }
        .remark{
          width: 100%;
          white-space:nowrap;
          overflow:hidden;
          text-overflow:ellipsis;
          color: #FF6600;
        }
      }
    }
  }
  .information {
    padding: 15px 10px;
    width: 100%;
    .title {
      height: 16px;
      padding-left: 5px;
      color: #0286df;
      font-size: 16px;
      line-height: 16px;
      font-weight: bold;
      border-left: 4px solid #409ee9;
      padding-bottom: 1px;
    }
  }
</style>
