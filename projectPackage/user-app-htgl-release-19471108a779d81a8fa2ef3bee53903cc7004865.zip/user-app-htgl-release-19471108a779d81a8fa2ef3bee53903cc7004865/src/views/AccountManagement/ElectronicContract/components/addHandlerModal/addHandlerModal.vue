<template>
  <div class="addHandlerModal">
    <el-dialog
            :title="$htgl_user.type == 1 ? '修改经办人信息':'修改账号信息'"
            :visible.sync="dialogVisible"
            width="30%"
            :before-close="handleClose"
            :close-on-click-modal="false"
    >
      <el-form
              :model="ruleForm"
              :rules="rules"
              ref="ruleForm"
              label-width="110px"
              class="demo-ruleForm"
      >
        <el-form-item :label="$htgl_user.type == 1 ? '原经办人：':'姓名：'">
          <span>{{ userMsg.name }}</span>
        </el-form-item>
        <el-form-item label="身份证号码：">
          <span>{{
          userMsg.identityNum.replace(
		        userMsg.identityNum.substring(4, 14),
		        "**********"
	        )}}</span>
        </el-form-item>
        <el-form-item :label="$htgl_user.type == 1 ? '手机号：':'原手机号码：'">
          <span>{{ userMsg.tel }}</span>
        </el-form-item>

        <el-form-item label="经办人姓名：" prop="name" v-if="$htgl_user.type == 1">
          <el-input
                  v-model.trim="ruleForm.name"
                  maxlength="32"
                  placeholder="请输入新的经办人姓名"
          ></el-input>
          <el-tooltip
                  effect="dark"
                  content="企业电子签章的负责人"
                  placement="top"
                  class="tooltip"
          >
            <img src="@/assets/help.png" />
          </el-tooltip>
        </el-form-item>
        <el-form-item label="身份证号码：" prop="identityCard" v-if="$htgl_user.type == 1">
          <el-input
                  v-model.trim="ruleForm.identityCard"
                  maxlength="18"
                  placeholder="请输入新的经办人身份证号码"
          ></el-input>
        </el-form-item>
        <el-form-item label="手机号码：" prop="phone">
          <el-input
                  v-model.trim="ruleForm.phone"
                  maxlength="11"
                  placeholder="请输入新的电子签章手机号"
          ></el-input>
          <el-button
                  plain
                  class="getCode"
                  @click="getCode"
                  :disabled="codeFont != '获取验证码'"
          >{{ codeFont }}</el-button
          >
        </el-form-item>
        <el-form-item label="验证码：" prop="validateCode">
          <el-input
                  v-model="ruleForm.validateCode"
                  maxlength="6"
                  placeholder="请输入验证码"
          ></el-input>
        </el-form-item>

        <el-form-item> </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="resetForm('ruleForm')">取 消</el-button>
        <el-button type="primary" @click="submitForm('ruleForm')"
        >确定修改</el-button
        >
      </span>
    </el-dialog>
  </div>
</template>

<script>
	import apiPact from "@/api/apiContract/apiContract.js";
	export default {
		name: "addHandlerModal",
		props: {
			userMsg: {
				type: Object,
				default: () => {},
			},
		},
		watch: {
			"ruleForm.validateCode": {
				handler() {
					this.codeErr = false;
				},
				deep: true,
			},
		},
		data() {
			return {
				rules: {
					name: [
						{ required: true, message: "请输入经办人姓名", trigger: "blur" },
					],
					identityCard: [
						{ required: true, message: "请输入身份证号码", trigger: "blur" },
						{ validator: this.validID, trigger: "blur" },
					],
					phone: [
						{ required: true, validator: this.validPhone, trigger: "blur" },
					],
					validateCode: [
						{ required: true, validator: this.verificationCode, trigger: "blur" },
					],
				},
				codeFont: "获取验证码",
				codeNum: 60, //验证码60s倒计时
				dialogVisible: false,
				isGetCode: false, //是否点击获取验证码
				codeErr: false,
				//表单数据
				ruleForm: {
					name: "",
					identityCard: "",
					phone: "",
					validateCode: "",
				},
			};
		},
		methods: {
			//关闭模态
			handleClose() {
				this.$refs["ruleForm"].resetFields();
				this.dialogVisible = false;
			},
			//确定修改
			submitForm(formName) {
				this.$refs[formName].validate((valid) => {
					if (valid) {
						this.updateAccount();
					} else {
						console.log("error submit!!");
						return false;
					}
				});
			},
			//确认修改请求
			async updateAccount() {
				let { name, identityCard, phone, validateCode } = this.ruleForm;
				let params = {
					id: this.userMsg.id,
					creditCode: this.userMsg.account,
					identityCard,
					name,
					phone,
					validateCode,
				};
				let res = null
				if(this.$htgl_user.type == 0){
					params.name = this.userMsg.name
					params.identityCard = this.userMsg.identityNum
					res = await apiPact.updatePersonAccount(params)
					console.log(res)
				}else {
					res = await apiPact.updateAccount(params);
				}

				if (res.data.code == 200) {
					this.$_toast({
						msg: "修改成功",
						type: "success",
					});
					this.$refs["ruleForm"].resetFields();
					this.dialogVisible = false;
					this.$emit("getIsOpenAccount");
				} else if (res.data.code == 10000) {
					this.codeErr = true;
					this.$refs.ruleForm.validateField(["validateCode"]);
				} else {
					this.$_toast({
						msg: res.data.msg,
						type: "error",
					});
				}
			},
			//取消按钮
			resetForm(formName) {
				this.$refs[formName].resetFields();
				this.dialogVisible = false;
			},
			//点击之后获取60s计时
			setTime() {
				this.codeFont = --this.codeNum + "s";
				let setInter = setInterval(
					function () {
						this.codeFont = --this.codeNum + "s";
						if (this.codeNum == 0) {
							this.codeFont = "获取验证码";
							this.codeNum = 60;
							clearInterval(setInter);
						}
					}.bind(this),
					1000
				);
			},
			//获取验证码按钮
			async getCode() {
				this.isGetCode = true;
				this.$refs.ruleForm.validateField("phone", async (data) => {
					if (!data) {
						this.setTime();
						let req = {
							tel: this.ruleForm.phone,
							isUpdate: true
						};
						let { data } = await apiPact.getValidateCode(req);
						if (data.code == 200 && data.data === null) {
							this.$message({
								message: "发送成功",
								type: "success",
							});
							return;
						} else {
							this.$_toast({
								msg: "短信验证码发送失败，请稍后重试",
								type: "error",
							});
						}
						this.codeNum = data.data;
					}
				});
			},

			// 验证身份证
			async validID(rule, value, callback) {
				// 身份证号码为15位或者18位，15位时全为数字，18位前17位为数字，最后一位是校验位，可能为数字或字符X
				let reg =
					/^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/;
				if (reg.test(value)) {
					//   验证是否十八岁
					let age = await this.go(value.length);
					if (age < 0) {
						callback(new Error("身份证号码格式错误"));
					}
					if (age < 18 && age > 0) {
						callback(new Error("经办人不支持设置为未成年人"));
					}
					if (age > 18) {
						callback();
					}
				} else {
					callback(new Error("身份证号码格式错误"));
				}
			},
			// 验证身份证是否成年
			go(val) {
				let iden = this.ruleForm.identityCard;
				let myDate = new Date();
				let month = myDate.getMonth() + 1;
				let day = myDate.getDate();
				let age = 0;

				if (val === 18) {
					age = myDate.getFullYear() - iden.substring(6, 10) - 1;
					if (
						iden.substring(10, 12) < month ||
						(iden.substring(10, 12) == month && iden.substring(12, 14) <= day)
					) {
						age++;
					}
				}
				if (val === 15) {
					age = myDate.getFullYear() - iden.substring(6, 8) - 1901;
					if (
						iden.substring(8, 10) < month ||
						(iden.substring(8, 10) == month && iden.substring(10, 12) <= day)
					) {
						age++;
					}
				}
				return age;
			},
			//验证手机
			validPhone(rule, value, callback) {
				let reg = /^1[3456789]\d{9}$/;
				if (!value) {
					callback(new Error("请输入手机号码"));
				} else if (!reg.test(value)) {
					callback(new Error("手机号码格式错误"));
				} else if (value.length < 11) {
					callback(new Error("手机号码格式错误"));
				} else {
					callback();
				}
			},
			//验证码
			verificationCode(rule, value, callback) {
				if (!value) {
					callback(new Error("请输入验证码"));
				} else if (!this.isGetCode) {
					callback(new Error("验证码不存在，请获取验证码"));
				} else if (this.codeErr) {
					callback(new Error("验证码错误"));
				} else {
					callback();
				}
			},
		},
	};
</script>


<style lang="scss" scoped>
  .addHandlerModal {
    /deep/.el-dialog__body {
      padding: 20px;
    }
    /deep/.el-input__inner {
      width: 260px;
    }
    .tooltip {
      position: absolute;
      right: 135px;
      top: 9px;
    }
    .getCode {
      position: absolute;
      right: 0px;
      background: #fff;
      border-color: #409eff;
      color: #409eff;
      width: 112px;
      &:hover {
        background: #fff;
        border-color: #409eff;
        color: #409eff;
      }
    }
  }
</style>
