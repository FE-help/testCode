<!--组织架构搜索选择-->
<template>
  <div class="Organization" v-show="show">
    <!-- 选择 -->
    <div class="el-dialog__header">
      <span class="el-dialog__title">选择</span>
      <button type="button" aria-label="Close" class="el-dialog__headerbtn" @click="close">
        <i class="el-dialog__close el-icon el-icon-close" @click="SetEmpty"></i>
      </button>
    </div>
    <div class="OrganizationBody">
      <div class="content select">
        <p class="title">选择：</p>
        <div class="mainBox">
          <el-input v-model.trim="name" placeholder="输入姓名" class="name" @input="findByName" clearable></el-input>
          <div class="crew">
            <el-tree
              v-loading="load"
              lazy
              :props="defaultProps"
              :data="list"
              :load="loadNode"
              ref="tree"
              default-expand-all
              show-checkbox
              node-key="onlyKey"
              :check-strictly="true"
              @check-change="selectNodes"
              :filter-node-method="filterNode"
            ></el-tree>
          </div>
        </div>
      </div>
      <div class="content">
        <p class="title">已选择：</p>
        <div class="mainBox isSelect" v-show="member.name?true:false">
          <span class="member">成员:</span>
          <span class="memberSelect">{{ member.name }}</span>
          <i class="el-icon-circle-close" @click="SetEmpty"></i>
        </div>
      </div>
    </div>
    <div class="footer">
      <slot/>
    </div>
    <div class='operating'>
      <el-button @click="close">取消</el-button>
      <el-button type="primary" @click="submit">提交</el-button>
    </div>
  </div>
</template>

<script>
//获取组织架构人员信息
import api from "@/api/apiAddollect";

export default {
  name: "Organization",
  model: {
    prop: 'show',
    event: 'change',
  },
  props: {
    show: Boolean,
    principal: {
      type: String,
      default: '',
    },
    principalName: {
      type: String,
      default: '',
    },
    memberNo: {
      type: String,
      default: '',
    },
    //自动关闭
    autoClose: {
      type: Boolean,
      default: true,
    },
    //禁止选中自己
    disabledSelf: {
      type: Boolean,
      default: false,
    }
  },
  data() {
    return {
      //根据名字搜索
      name: '',
      list: [],
      defaultProps: {
        children: "contacts",
        label: "name"
      },
      //当前选中
      member: {},
      load: false,
      flag: 0,
      key: '',
    }
  },
  computed: {
    user() {
      return this.$htgl_user
    }
  },
  watch: {
    show: {
      handler(value) {
        value ? this.OrganizationList() : '';
      },
      immediate: true,
    },
  },
  methods: {
    //回显
    echo() {
      let tree = this.$refs.tree;
      tree.setCheckedKeys([this.key])
      this.member = {name: this.principalName, id: this.principal};
    },
    close(value) {
      this.$emit('change', false);
      this.$emit('close', value)
      this.member = {};
      this.name = '';
      this.key = '';
      this.$refs.tree.setCheckedKeys([])
    },
    //获取组织架构人员列表
    async OrganizationList() {
      this.load = true;
      let {data} = await api.getOrganizationAndContacts();
      this.echo();
      if (data.code === 200) {
        this.list = [data.data];
      }
      this.load = false;
    },
    //加载树
    loadNode({data, level}, resolve) {
      if (data.hasOwnProperty('contacts')) {
        data.disabled = true;
        let list = data.children.concat(data.contacts);
        list.map(item => {
          if (this.disabledSelf && item.memberNo == this.user.no) item.disabled = true;
          this.flag += 1;
          item.onlyKey = item.id + '_' + this.flag;
          // if (item.id === this.principal) {
          if (item.memberNo === this.principal) {
            this.key = item.onlyKey;
          }
        })
        this.echo();
        return resolve(list);
      }
      resolve([])
    },
    //选择
    selectNodes(data, checked) {
      let tree = this.$refs.tree;
      if (checked) {
        tree.setCheckedKeys([data.onlyKey]);
        return this.member = data;
      }
      this.member = tree.getCheckedNodes()[0] || {};
    },
    //提交选择
    submit() {
      if (!this.member.name) return this.$message.warning('请选择负责人');
      // this.$emit('update:principal', this.member.id.split('_')[0]);
      this.$emit('update:principal',this.member.memberNo);
      this.$emit('update:principalName', this.member.name);
      this.$emit('update:memberNo', this.member.memberNo);
      this.$emit('onComplete')
      if (this.autoClose) this.close();
    },
    //清空选择
    SetEmpty() {
      this.$refs.tree.setCheckedKeys([]);
    },
    //搜索
    filterNode(value, data) {
      if (!value) return true;
      return data.name.indexOf(value) !== -1;
    },
    //根据名字搜索
    findByName() {
      this.$refs['tree'].filter(this.name)
    }
  }
}
</script>

<style scoped lang="scss">
  .Organization {
    width: 600px;
    height: 600px;
    background: white;

    .el-icon-circle-close {
      cursor: pointer;
    }

    .OrganizationBody {
      padding-top: 30px;
      display: flex;
    }

    .content {
      margin-left: 15px;
      width: 275px;
      height: 420px;
      border: 1px solid #DCDFE6;
      border-radius: 5px;

      .title {
        height: 40px;
        border-bottom: 1px solid #DCDFE6;
        line-height: 40px;
        padding-left: 10px;
      }

      .mainBox {
        padding: 10px;
      }

      .isSelect {
        display: flex;
        justify-content: space-between;
        align-items: center;

        .memberSelect {
          margin-right: 120px;
        }
      }
    }

    .crew {
      height: 310px;
      overflow: scroll;
      margin-top: 10px;
    }

    .operating {
      display: flex;
      margin: 20px;
      justify-content: flex-end;
    }
  }
</style>
