// Here is a list of the toolbar
// Detail list see https://www.tinymce.com/docs/advanced/editor-control-identifiers/#toolbarcontrols
const toolbar = ['forecolor backcolor bold italic underline strikethrough alignleft aligncenter alignright alignjustify outdent indent bullist numlist blockquote | styleselect formatselect fontselect fontsizeselect ']
//
export default toolbar
