<template>
  <div class="tender-list">
    <div class="tender-title">中标清单</div>
    <div class="tender-table">
      <OperTable
        :columns="columns"
        :data="tableData"
        :isShowIndex="true"
        :showPagenation="false"
        :isLineRow="isLineRow"
        @choice="choice"
        @findPage="findPage"
      />
    </div>
    <div class="tender-amount">
      <div class="amount-item">
        <span class="label">合计：</span>
        <span class="price">{{totalPrice | moneyToCurrency}}元</span>
      </div>
      <div class="amount-item">
        <span class="label">（大写）</span>
        <span class="price">{{totalPrice | digitUppercase}}</span>
      </div>
    </div>
  </div>
</template>

<script>
import { offerPri } from '@/views/AccountManagement/ElectronicContract/contractTemplate/components/colunmInit'
export default {
  components: {
    OperTable: () => import('@/views/AccountManagement/ElectronicContract/contractTemplate/components/OperTable'),
  },
  props: {
    columns: { // 表头配置
      type: Array,
      default: () => ([])
    },
    tableData: { // 列表数据
      type: Array,
      default: () => ([])
    },
    isLineRow: { // 是否自适应内容撑开列
      type: Boolean,
      default: true,
    },
  },
  computed: {
    totalPrice() {
      let total = 0
      this.tableData.forEach(item => {
        if(item.totalPrice) {
          // if(offerPri.includes(this.goodsType)) {
          //   // 报价-直接合计
          //   total += Number(item.applyPrice)
          // } else {
          //   // 单价-乘以数量再合计
          //   const price = Number(item.applyPrice) * (item.num || item.amount  || 0)
          //  total += price
          // }
          total += Number(item.totalPrice)
        }
      })
      return total.toFixed(2)
    }
  },
  data() {
    return {};
  },
  created() {},
  mounted() {},
  methods: {
    choice(item, row, col) {
      console.log(item, row, col)
    },
    findPage(data) {
      console.log(data,'findPage---11123123123123');
    }
  }
};
</script>

<style scoped lang="scss">
  .tender-list {
		margin-top: 20px;
		border: 1px solid #E4E7ED;
		.tender-title {
			display: flex;
			align-items: center;
			padding: 12px 20px;
			color: #333;
			font-size: 16px;
			font-weight: bold;
			background: #FAFAFA;
			border-bottom: 1px solid #E4E7ED;
		}
		.tender-table {
			padding: 20px;
		}
		.tender-amount {
			display: flex;
			padding:0 20px 20px 20px;
			.amount-item {
				&:first-of-type {
					margin-right: 90px;
				}
				font-size: 14px;
				.label {
					color: #666666;
				}
				.price {
					color: #FF6600;
				}
			}
		}
	}
</style>
