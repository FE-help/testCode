/**
* @Descripttion: 未描述
* @Author: Chenbangquan
* @version: 1.0.0
* @CreateDate 2021-09-14 10:54
* @LastEditors: cbq
* @LastEditTime: 2021-09-14
*/
<template>
  <div class="saveContractTemplate">
    <el-form
            :model="contractTemplate"
            :rules="rules"
            ref="form"
            label-width="110px"
            class="demo-detail">
      <el-form-item label="模板名称：" prop="name">
        <el-input class="wd300" v-model="contractTemplate.name" maxlength="20" placeholder="请输入合同模板名称"></el-input>
      </el-form-item>
      <el-form-item label="合同类型：" prop="category">
        <el-select
                class="wd300"
                v-model="contractTemplate.category"
                placeholder="请选择"
                clearable>
          <el-option
                  v-for="item in statuses"
                  :key="item.key"
                  :label="item.value"
                  :value="item.key"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="合同分类：" prop="type">
        <el-select
                class="wd300"
                v-model="contractTemplate.type"
                placeholder="请选择"
                clearable>
          <el-option
                  v-for="item in types"
                  :key="item.key"
                  :label="item.value"
                  :value="item.key"></el-option>
        </el-select>
      </el-form-item>
    </el-form>
    <div style="text-align: center">
      <button7 class="mr10" @click="$emit('closeDialog')">取消</button7>
      <el-button type="primary" @click="saveTemplate('form')" :loading="loading">保存</el-button>
    </div>
  </div>
</template>

<script>
	import apiContract from '@/api/apiContract/apiContract'

	export default {
		props:{
			contractDetail:{
				type: Object
			},
			TinymceData:{
				type: Array
			},
    },
		name: "saveContractTemplate",
    data(){
			return{
				types:[],
				loading:false,
				statuses:[],
				contractTemplate:{
					category: '', //合同类型
					id: '',
					images: '',
					name: '',
					rule1: '',
					rule2: '',
					type: '', //合同分类
        },
        rules: {
	        name: [{ required: true, message: "请输入合同模板名称", trigger: "blur" }],
	        category: [{ required: true, message: "请选择合同类型", trigger: "blur" }],
	        type: [{ required: true, message: "请选择合同分类", trigger: "blur" }],
        }
      }
    },
    created(){
			this.getStatus()
    },
    methods:{
	    //保存合同模板
	    async saveTemplate(formName){
			    this.$refs[formName].validate(async (valid) => {
				    if (valid) {
				    	this.loading = true
					    this.contractTemplate.images = this.contractDetail.localUrl
					    let obj = {title:'合同模板文本内容编辑区域一',rule:this.contractDetail.rule1}
					    this.contractTemplate.rule1 = JSON.stringify(obj)
					    this.contractTemplate.rule2 = JSON.stringify(this.TinymceData)
					    let res = await  apiContract.saveContractTemplate(this.contractTemplate)
					    if(res.data.code == 200){
						    this.loading = false
						    this.$alert("模板保存成功，创建合同可使用该模板", "模板保存成功", {
							    confirmButtonText: "知道了",
							    type: "success",
						    })
						    this.$emit('closeDialog')
						    // this.$removeTag('/contractModule')
					    }else {
						    this.loading = false
              }
            }
          })
	    },
	    async getStatus() {
		    let { data } = await apiContract.postContractCategory({});
		    this.statuses = data.data;
		    let res= await apiContract.getContractType();
		    this.types = res.data.data
	    }
    }
	}
</script>

<style scoped lang="scss">
  .saveContractTemplate{
    padding: 20px 0;
    .demo-detail{
     >>>.el-form-item .el-form-item__label{
        font-size: 14px;
      }
    }

  }
</style>
