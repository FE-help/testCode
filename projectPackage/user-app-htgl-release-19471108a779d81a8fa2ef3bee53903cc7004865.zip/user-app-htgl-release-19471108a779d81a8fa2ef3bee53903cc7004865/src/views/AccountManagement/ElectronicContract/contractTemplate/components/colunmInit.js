// 有清单状态type
export const showTenderBill = [1, 2, 3, 4, 5, 11, 12, 14, 15, 16, 17, 18, 19]