/**
* @Descripttion: 合同
* @Author: Chenbangquan
* @version: 1.0.0
* @CreateDate 2021-06-29 17:09
* @LastEditors: cbq
* @LastEditTime: 2021-06-29
*/
<template>
  <div style="width: 1400px;background-color: #f5f5f5">
    <div style="width: 1240px;background-color: #ffffff">
      <!--style="position: fixed;top:-1000px;left: -1000px"-->
      <!--<previewPdf :data="data"-->
      <!--ref="previewPdf"-->
      <!--:contractCompany="contractCompany"-->
      <!--:TinymceData="TinymceData"-->
      <!--:customFiled="customFiled"-->
      <!--@publicPdf="publicPdf"></previewPdf>-->
      <previewSvgPdf ref="previewSvgPdf" @publicPdf="publicPdf" @setLoading="setLoading"></previewSvgPdf>
      <!--签署弹框-->
      <contractSigna v-if="contractSigna" :constractUserInfo="constractUserInfo" :chapter="chapter"
                     :contracDetail="data"
                     :procesState="procesState"
                     @close="setContractSigna"
                     :aprocessInfo="aprocessInfo"
                     @getContactDetail="getContactDetail"
                     @writeSignature="writeSignature"
                     @delChapter="delChapter"></contractSigna>
      <el-row id="pdfDom" ref="pdfDomsss" class="pdfDom" >
        <el-col :span="24">
          <div class="templateBox1">
            <el-col :span="24">
              <el-form :model="data" :label-position="labelPosition" label-width="124px" >
                <el-col :span="24"><p class="title target-node-item">{{data.title}}</p></el-col>
                <el-col :span="24"><p class="contractNo">合同编号：<span>{{data.no}}</span></p></el-col>
                <el-col :span="24"><div class="mt20"></div></el-col>
                <el-col :span="24" v-for="(item, index) in contractCompany" :key="`${item}${index}`">
                  <el-form-item :label="`${item.name}方：`" class="fontColor target-node-item" label-width="60px">
                    <span class="fontColor">{{item.companyDetail.companyName}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span="24"><div v-html="data.rule1" class="rule1 target-node-item"></div></el-col>
                <el-col :span="24" v-if="tenderTypeList.includes(goodsType) && zcStatus">
                  <TenderBillList
                          :columns="columns"
                          :tableData="tableData"
                          :isLineRow="false"
                  />
                </el-col>
                <el-col :span="24" v-if="!zcStatus">
                  <component :is="currentComponent" :detail="data.orderDetail"></component>
                </el-col>
                <el-col :span="24"><div class="mt20"></div></el-col>
                <el-col :span="24" v-for="(item,index) in customFiled" :key="index">
                  <p style="font-size: 16px;font-weight: bold;color: #333333;line-height: 30px">{{item.title}}</p>
                  <div class="rule1 target-node-item" style="font-weight: 400;color: #333333;line-height: 30px">{{item.span}}</div>
                  <div class="mt20"></div>
                </el-col>
                <el-col :span="24" v-for="(item,index) in TinymceData" :key="index">
                  <p style="font-size: 16px;font-weight: bold;color: #333333;line-height: 30px">{{item.title}}</p>
                  <div v-html="item.rule" class="rule1 target-node-item" style="font-weight: 400;color: #333333;line-height: 30px"></div>
                  <div class="mt20"></div>
                </el-col>

                <el-col :span="24"><div class="mt30"></div></el-col>
                <el-col :span="12" v-for="(item, index) in contractCompany" :key="`${item}${index}111`">
                  <el-form-item :label="`${item.name}方（盖章）：`" class="fontColor target-node-item">
                    <span class="fontColor">{{item.companyDetail.companyName}}</span>
                  </el-form-item>
                  <el-form-item label="法定代表人：" class="fontColor target-node-item" v-if="item.companyDetail.role == 1">
                    <div class="SignatureImg">
                      <span class="fontColor">{{item.companyDetail.legalRepresentative}}</span>
                      <!--<img :src="img"/>-->
                      <img v-if="item.companyDetail.signatureUrl" :src="item.companyDetail.signatureUrl"/>
                      <img v-if="item.companyDetail.companyNo == writeSignatureImg.cno" :src="writeSignatureImg.signImg"/>
                    </div>
                  </el-form-item>
                  <el-form-item label="授权委托人：" class="fontColor target-node-item">
                    <span class="fontColor">{{item.companyDetail.consignor}}</span>
                  </el-form-item>
                  <el-form-item label="地址：" class="fontColor target-node-item">
                    <span class="fontColor">{{item.companyDetail.address}}</span>
                  </el-form-item>
                  <el-form-item label="电话：" class="fontColor target-node-item">
                    <span class="fontColor">{{item.companyDetail.phone}}</span>
                  </el-form-item>
                </el-col>
              </el-form>

            </el-col>
          </div>
        </el-col>
      </el-row>
      <el-dialog
              class="showPdf"
              :title="contractTitle"
              :visible.sync="showPdf"
              top="5vh"
              @close="closeDialog"
              width="50%">
        <div class="templateContent" :loading="loading">
          <p v-for="(item, index) in urllist" class="contractImg" :key="index">
            <img :src="item">
          </p>
        </div>
      </el-dialog>
      <el-dialog
              class="showPdf"
              :title="'保存为模板'"
              :visible.sync="showSaveTemplate"
              top="5vh"
              @close="closeDialog"
              :close-on-click-modal="false"
              width="600px">
        <saveTemplate :key="showSaveTemplate" :contractDetail="data" :TinymceData="TinymceData" @closeDialog="closeDialog"></saveTemplate>
      </el-dialog>
      <el-dialog
              class="showPdf"
              :title="'合同模板'"
              :visible.sync="showSaveTemplateList"
              top="5vh"
              @close="closeDialog"
              :close-on-click-modal="false"
              width="600px">
        <!--<templateList></templateList>-->
        <contractTemplateList :key="showSaveTemplateList" :contractDetail="data" :TinymceData="TinymceData"
                              @getContactDetail="getContactDetail"
                              @useTemplate="useTemplate"
                              @closeDialog="closeDialog"></contractTemplateList>
      </el-dialog>
      <div class="templateHead">
        <el-progress v-if="loading" :percentage="progressNum" :show-text="false" :color="['#0286DF']"></el-progress>
        <div v-loading="loading">
          <!--:showApproveBox="showApproveBox"-->
          <contractHead
                  @setStatus="setStatus"
                  @setLoading="setLoading"
                  :loading="loading"
                  :modelShow1="modelShow1"
                  :watchStatus="watchStatus"
                  :procesState="procesState"
                  :aprocessInfo="aprocessInfo"
                  :constractOpenInfo="constractOpenInfo"
                  @clearContract="clearContract"
                  @signCode="signCode"
                  @setprocesState="setprocesState"
                  @DiscardContract="sendContract"
                  @getContactDetail="getContactDetail"
                  @setAmendStatus="setAmendStatus"
                  @sendContract="sendContract" :contracDetail="data"></contractHead>
          <el-row type='flex'>
            <el-col :span="18" v-if="data.status == 1">
              <div class="templateContent">
                <div class="contentHead" v-if="amendStatus">
                  <el-col :span="12">
                    <div v-if="divCoverBtns">
                      <span style="margin-right: 20px;color: #666666">使用模板</span>
                      <span style="color: #666666">另存为模板</span>
                    </div>
                    <div v-else>
                      <span class="cursor" style="margin-right: 20px" @click="showSaveTemplateList = true">使用模板</span>
                      <span class="cursor" @click="sendContract('4')">另存为模板</span>
                    </div>
                  </el-col>
                  <el-col class="save" :span="12" >
                    <span style="margin-right: 20px" @click="sendContract('1')">预览</span>
                    <span v-if="divCoverBtns" style="margin-right: 20px;color: #666666">存草稿</span>
                    <span v-else @click="saveDraft('1')">存草稿</span>
                  </el-col>
                </div>
                <!--开启审批并且审批状态为审批中，合同状态为拟定中的时候，新增cover-->
                <!--@click="editorConTract()"-->
                <div :class="{'divCover': divCoverBtns}" >
                  <div class="templateBox" :class="{'banClick': divCoverBtns}">
                    <p class="title">
                      <el-input maxlength="50" v-model="data.title" placeholder="请输入合同名称"></el-input>
                    </p>
                    <el-col :span="24"><p class="contractNo">合同编号：<span>{{data.no}}</span></p></el-col>
                    <el-col :span="24"><div class="mt20"></div></el-col>
                    <!--<p>合同签订时间:-->
                    <!--<span v-if="data.status == 3">{{dateFormatType(data.createTime,2)}}</span>-->
                    <!--<span v-else>/</span>-->
                    <!--</p>-->
                    <el-form :model="data" :label-position="labelPosition" label-width="124px" >
                      <el-row>
                        <el-col :span="24"><div class="tc-10"></div></el-col>
                        <el-col :span="24" v-for="(item,index) in contractCompany" :key="item.name">
                          <el-form-item :label="`${item.name}方：`" label-width="72px"  class="fontColor">
                            <el-select v-model="item.val"
                                       :placeholder="`请选择合同${item.name}方（必选）`"
                                       class="wd100"
                                       clearable
                                       @change='changeHandler(item.val, index)'
                                       @clear='clearHandler(index)'
                            >
                              <el-option
                                      v-for="(items,indexs) in comOptions"
                                      :key="indexs"
                                      :label="items.companyName"
                                      :value="items.companyNo"
                                      :disabled="items.disabled"
                              >
                              </el-option>
                            </el-select>
                          </el-form-item>
                        </el-col>
                        <el-col :span="24"><div class="tc-10"></div></el-col>

                        <el-col :span="24">
                          <tinymce v-model="data.rule1" :height="218" :width="816" :toolbar="toolbar"/>
                        </el-col>
                        <el-col :span="24" v-if="tenderTypeList.includes(goodsType) && zcStatus">
                          <TenderBillList
                                  :columns="columns"
                                  :tableData="tableData"
                          />
                        </el-col>
                        <el-col :span="24" v-if="!zcStatus">
                          <component :is="currentComponent" :detail="data.orderDetail"></component>
                        </el-col>
                        <el-col :span="24"><div class="tc-20"></div></el-col>
                        <el-col :span="24" v-for="(item,index) in customFiled" :key="`key3${index}`">
                          <el-col :span="24"><div class="tc-10"></div></el-col>
                          <el-col :span="24">
                            <el-input style="width: 100%" v-model="item.title" maxlength="20" placeholder="请输入字段名称">
                              <template slot="append">
                                <i @click="delCustomFiled(item,index)" class="el-icon-remove-outline cursor" style="font-size: 22px;color: #FF6600"></i>
                              </template>
                            </el-input>
                          </el-col>
                          <el-col :span="24"><div class="tc-5"></div></el-col>
                          <el-col :span="24">
                            <el-input style="width: 100%;"
                                      type="textarea"
                                      :rows="2" v-model="item.span" maxlength="50" placeholder="请输入字段内容"></el-input>
                          </el-col>
                        </el-col>
                        <el-col :span="24"><div class="tc-10"></div></el-col>
                        <div class="contractRule-btn">
                          <el-button type="default" @click="addCustomFiled"  icon="el-icon-plus" plain>新增字段</el-button>
                        </div>
                        <!--<el-col :span="24"><div class="tc-30"></div></el-col>-->
                        <el-col :span="24" v-for="(item,index) in TinymceData" :key="`key2${key2}${index}`">
                          <el-col :span="24"><div class="tc-20"></div></el-col>
                          <el-col :span="20" class="contractRule" style="border-right: none">
                            <el-input maxlength="20"
                                      class="wd400"
                                      v-model="item.title"
                                      placeholder="请输入合同段落标题（必填）"
                                      :key="`key2${key2}${index}`">
                            </el-input>
                          </el-col>
                          <el-col :span="4" style="border-left: none;text-align: right" class="contractRule" >
                            <div><i @click="deleteLine(item,index)" class="el-icon-remove-outline cursor" style="font-size: 22px"></i></div>
                          </el-col>
                          <el-col :span="24">
                            <tinymce v-model="item.rule"
                                     :height="218"
                                     :width="816"
                                     :toolbar="toolbar"/>
                          </el-col>
                        </el-col>
                        <el-col :span="24"><div class="tc-20"></div></el-col>
                        <div class="contractRule-btn">
                          <el-button type="default" @click="addRule"  icon="el-icon-plus" plain>新增合同段落</el-button>
                        </div>
                        <el-col :span="24"><div class="tc-15"></div></el-col>
                        <el-col :span="12" v-for="(item, index) in contractCompany" :key="index">
                          <el-form-item :label="`${item.name}方（盖章）：`" class="fontColor">
                            <span class="fontColor">{{item.companyDetail.companyName}}</span>
                          </el-form-item>
                          <el-form-item label="法定代表人：" class="fontColor" v-if="item.companyDetail.role == 1">
                            <el-input class="wd220" v-model="item.companyDetail.legalRepresentative" maxlength="32" placeholder="请填写法定代表人"></el-input>
                          </el-form-item>
                          <el-form-item label="授权委托人：" class="fontColor">
                            <el-input class="wd220" v-model="item.companyDetail.consignor"  maxlength="32" placeholder="请填写授权委托人"></el-input>
                          </el-form-item>
                          <el-form-item label="地址：" class="fontColor"
                                        :rules="[{ required: true}]">
                            <el-input class="wd220" v-model="item.companyDetail.address" maxlength="60" placeholder="请填写地址（必填）"></el-input>
                          </el-form-item>
                          <el-form-item label="电话：" class="fontColor"
                                        :rules="[{ required: true}]">
                            <el-input class="wd220" v-model="item.companyDetail.phone" maxlength="11" placeholder="请填写电话（必填）"></el-input>
                          </el-form-item>
                        </el-col>
                      </el-row>
                    </el-form>
                  </div>
                </div>
              </div>
            </el-col>
            <el-col :span="18" v-else>
              <!--<el-col :span="18">-->
              <div class="templateContent">
                <p v-for="(item, index) in urllist" class="contractImg" :key="index">
                  <img :src="item">
                </p>
              </div>
            </el-col>
            <el-col :span="6">
              <log v-if="data"
                   :info="data"
                   :logHistory="logHistory"
                   :ApprovalLog="ApprovalLog"
                   :procesState="procesState"
                   :aprocessInfo="aprocessInfo"
                   :logStatus="logStatus"
                   ref="logHistory"></log>
            </el-col>
          </el-row>
          <CommonModalTips :isVisible="modelShow"
                           :title="toast.title"
                           :tipsText="toast.tips"
                           :mStatus="toast.mStatus"
                           :appendtTobody="toast.appendtTobody"
                           @close="closeTips">
            <div slot="footer" class="toast">
              <!--删除新增段落-->
              <button7 v-if="Draft == 'delCustom'" class="mr10" @click="modelShow = false">取消</button7>
              <el-button v-if="Draft == 'delCustom'" type="primary" @click="delCustom">确定</el-button>
              <!--删除合同条款-->
              <button7 v-if="Draft == 'delRule'" class="mr10" @click="modelShow = false">取消</button7>
              <el-button v-if="Draft == 'delRule'" type="primary" @click="delRule">确定</el-button>
              <button7 v-if="Draft == 'Draft'" class="mr10" @click="modelShow = false">取消</button7>
              <el-button v-if="Draft == 'Draft'" type="primary" @click="saveStatu('1')">确定</el-button>
              <el-button v-if="Draft == 'signCode'" type="primary" @click="getContactDetail()">知道了</el-button>
              <el-button v-if="Draft == 'checkStatus'" type="primary" @click="getContactDetail()">知道了</el-button>
              <button7 v-if="Draft == 'updateContract'" class="mr10" @click="closeTips()">取消</button7>
              <el-button v-if="Draft == 'updateContract'" type="primary" @click="updatePage()">确定</el-button>
            </div>
          </CommonModalTips>
        </div>
      </div>
    </div>
  </div>

</template>

<script>
	import toolbar from './toolbar'
	import apiContractTemplate from '@/api/apiContract/apiContract'
	import * as api from "@/api/apiProcess";
	import html2Canvas from 'html2canvas'
	import JsPDF from 'jspdf'
	import { APPLY_MODES, Material, Zulin } from '../OtherComponents/main.js';
	import _ from 'lodash';
	import { showTenderBill } from '@/views/AccountManagement/ElectronicContract/contractTemplate/components/colunmInit.js'
	export default {
		// inject:['reload'],
		name: 'contractTemplate',
		data() {
			return {
				writeSignatureImg:{},//签名图片
				progressNum:0,//进度条
				amendStatus:true,//修改状态
				divCoverBtns:false,
				watchStatus:false,
				// showApproveBox:false, //设置审批弹框
				aprocessInfo:'',//审批详情
				procesState:'',//合同是否开启审批
				showList:'false',//合同模板列表
				showSaveTemplate:false,//保存为合同模板
				showSaveTemplateList:false,//选择合同模板
				TinymceData:[],
				customFiled:[],
				urllist: [],
				Draft: false,
				key1:1,
				key2:2,
				key3:3,
				deadline: "",
				// htStatus: "",
				choosedCom: [],
				loading: false,
				toolbar: toolbar,
				toast: {
					tips: '',
					mStatus: 'warning',
					title: '',
					appendtTobody:true
				},
				contractSigna: false,
				contractTitle: '',
				contractCompany: [],//甲乙丙丁
				propsCompany: {
					value: "companyNo",
					label: "companyName"
				},
				type: 'Material',
				labelPosition: 'right',
				showPdf: false,
				baseImg1: [], // 预览
				chapter: [], // 预览
				data: {},
				// 模板弹出框
				modelShow: false,
				modelShow1: false,
				logHistory: [],
				ApprovalLog: [],//审批日志
				constractUserInfo: '',
				constractOpenInfo: '', // 开户信息
				comOptions: [],
				htstatus: "",
				delRuleVal: "",
				columns: [], // 表头初始化数据
				tableData: [],
				goodsType: 0,
				tenderTypeList: showTenderBill,
				logStatus: {},
				zcStatus: false
			}
		},
		inject: ["reload"],
		components: {
			saveTemplate: () => import('./saveContractTemplate'),//保存模板
			previewPdf: () => import('./../components/previewPdf'),//预览pdf
			previewSvgPdf: () => import('./../components/previewSvgPdf'),//预览pdf
			contractTemplateList: () => import('./contractTemplateList'),//选择合同模板
			CommonModalTips: () => import("@/components/public/CommonModalTips.vue"),
			log: () => import('./../components/contractLog'),
			contractHead: () => import('./contractHead'),
			contractSigna: () => import('./contractSigna'),
			modelList: () => import('./../components/modelList'),
			TenderBillList: () => import('./tenderBillList.vue'),
			Material,
			Zulin,
			Tinymce: () => import("@/components/Tinymce")
		},
		computed: {
			// divCover(){
			// 	this.divCoverBtns = this.procesState == 1 && (this.aprocessInfo.auditStatus == 1 || this.aprocessInfo.auditStatus == 2) && this.data.status == 1
			// },
			currentComponent() {
				return APPLY_MODES[this.type]
			}
		},
		watch: {
			divCover(){},
			choosedCom: {
				handler(val) {
					this.contractCompany.forEach(item => {
						item['companyDetail'] = {}
					})
					let arr = val.map(item => {
						return item.val
					})
					// 所剩选项
					this.comOptions = this.allcomOptions.map(item => {
						return {
							...item,
							disabled: arr.includes(item.companyNo)
						}
					})
					arr.forEach(item => {
						let idx = this.contractCompany.findIndex(item2 => item === item2.val);
						this.contractCompany[idx].companyDetail = this.allcomOptions.find(item2 => item2.companyNo === item)
						this.contractCompany[idx].companyDetail.contractPosition = this.contractCompany[idx].name
					})
				},
				deep: true
			}
		},
		created() {},
		mounted() {
			// this.initColumns()
			this.getContactDetail()
			this.getIsOpenAccount()
		},
		methods: {
			async getIsOpenAccount() {
				let res = await apiContractTemplate.getOpenAccountMsg(this.$htgl_user.no)
				this.constractOpenInfo = res.data.data
			},
			editorConTract(){
				if(this.aprocessInfo.auditStatus == 2){
					this.toast.title = '修改合同'
					this.toast.mStatus = 'warning'
					this.toast.tips = '修改合同后将导致审批状态失效，再次发生合同需重新发起审批，确定要修改合同吗？'
					this.modelShow = true
					this.Draft = 'updateContract'
					return
				}
			},
			//蒙层修改合同
			async updatePage(){
				let res = await apiContractTemplate.delAuditByContractNo(this.$route.query.no)
				if(res.data.code == 200){
					this.divCoverBtns = false
					this.modelShow = false
					this.getContactDetail()
				}
			},
			setContractSigna(){
				this.reload()
				// // this.$set(this.contracDetail,'signatureFlag',true)
				// this.contracDetail = true
				this.contractSigna = false
				this.getContactDetail()
			},
			/*
      * 获取签名
      * 1.0.6
      * */
			async	writeSignature(val){
				this.loading = true
				this.contractSigna = false
				// this.$set(this.writeSignatureImg, val)
				this.writeSignatureImg = val
				setTimeout(() => {
					this.$refs.previewSvgPdf.tosvg('pdfDom', 99)
					console.log(this.writeSignatureImg)
				}, 1000)

			},
			delChapter(data){
				this.chapter = JSON.parse(JSON.stringify(data))
			},
			//使用模板
			useTemplate(val){
				let str = JSON.parse(val.rule1)
				this.$set(this.data,'rule1',str.rule)
				this.TinymceData = JSON.parse(val.rule2)
				this.key2++
			},
			addRule(){
				let obj = {title:'其他内容',rule:''}
				this.TinymceData.push(obj)
				this.$nextTick(() => {
					this.key2++
				})
			},
			addCustomFiled(){
				let  obj = {
					title :'',
					span:''
				}
				this.customFiled.push(obj)
				this.$nextTick(() => {
					this.key3++
				})
			},
			delCustomFiled(val,index){
				this.toast.title = '删除提示'
				this.toast.mStatus = 'warning'
				this.toast.tips = '是否确定删除新增字段？'
				this.modelShow = true
				this.Draft = 'delCustom'
				this.delRuleVal = val
				this.$nextTick(() => {
					this.key3++
				})
			},
			delCustom(){
				this.customFiled.forEach((item,index)=>{
					if(this.delRuleVal == item){
						this.customFiled.splice(index, 1)
					}
				})
				this.modelShow = false
			},
			deleteLine(val, index){ //删除合同其他条款弹框
				if(val.rule){
					this.toast.title = '删除提示'
					this.toast.mStatus = 'warning'
					this.toast.tips = '当前合同段落存在内容，是否确定删除？'
					this.modelShow = true
					this.Draft = 'delRule'
					this.delRuleVal = val
					return
				}
				this.TinymceData.splice(index, 1)
				this.$nextTick(() => {
					this.key2++
				})
			},
			//删除合同其他条款
			delRule(){
				this.TinymceData.forEach((item,index)=>{
					if(this.delRuleVal == item){
						this.TinymceData.splice(index, 1)
					}
				})
				this.$nextTick(() => {
					this.key2++
				})
				this.modelShow = false
			},
			closeTips(){
				if(this.Draft == 'updateContract'){
					this.divCoverBtns = true
				}
				if(this.Draft == 'checkStatus'){
					this.getContactDetail()
				}
				this.modelShow = false
			},
			async contractLog(){
				let res = await apiContractTemplate.getContractLog(this.$route.query.no)
				this.logHistory = res.data.data
			},
			async processLog(val){
				let obj = {
					id: this.data.approvalSendId
				}
				let res = await apiContractTemplate.ApprovalLog(obj)
				this.ApprovalLog = res.data.data
				console.log(res)
			},
			saveDraft(val){
				this.toast.title = '提示'
				this.toast.mStatus = 'warning'
				this.toast.tips = '是否将合同文本内容保存为草稿，并关闭当前页面！'
				this.modelShow = true
				this.Draft = 'Draft'
			},
			getIndex(pos) {
				if (pos === "甲") {
					return 1
				} else if (pos === "乙") {
					return 2
				} else if (pos === "丙") {
					return 3
				} else if (pos === "丁") {
					return 4
				} else if (pos === "戊") {
					return 5
				} else if (pos === "己") {
					return 6
				} else {
					return ""
				}
			},
			showYz() {
				let domArr = []
				let domCArr = []
				console.log(this.baseImg1)
				this.baseImg1.forEach((item, index) => {
					domArr.push(document.getElementById(`pdfDom${index}`))
					item.img.forEach((items, indexs) => {
						domCArr.push(document.getElementById(`dragDiv${index}${indexs}`))
						domArr.forEach((F, Findex) => {
							domCArr.forEach(C => {
								let FrBy = F.getBoundingClientRect().top + F.getBoundingClientRect().height
								let FrBx = F.getBoundingClientRect().left

								let rBy = C.getBoundingClientRect().top
								let rBx = C.getBoundingClientRect().left

								let x1 = Math.ceil(rBx - FrBx) // x轴 ok
								let y1 = Math.ceil(FrBy - rBy)
								C.style.left = x1 + 'px'
								C.style.top = y1 + 'px'
							})
						})
					})
				})
			},
			/*清空合同*/
			clearContract(val) {
				this.modelShow1 = val
				this.data.rule1 = ''
				this.data.rule2 = ''
				this.TinymceData.forEach((item, index)=>{
					item.rule = ''
				})
				this.$nextTick(() => {
					this.key1++
					this.key2++
				})
			},
			//设置弹框显示
			setStatus(val) {
				this.modelShow1 = val
			},
			//设置loading
			setLoading(val) {
				this.loading = val
			},
			//设置修改状态
			setAmendStatus(val) {
				console.log(val)
				this.data.status = 1
				this.amendStatus = val
			},
			//作废合同
			async DiscardContract() {
				this.loading = true
				let data = {
					companyNo: this.$htgl_user.companyNo,
					contractId: this.$route.query.id,
					localUrl: this.data.localUrl,
					title: this.data.title
				}
				// return
				let res = await apiContractTemplate.putDiscardContrac(data)
				if (res.data.code == 200) {
					this.$message({
						message: '退回成功！',
						type: 'success'
					})
					this.modelShow1 = false
					this.loading = false
					this.getContactDetail()
				} else {
					// this.$message({
					// 	message: res.data.msg,
					// 	type: 'error'
					// })
					this.getContactDetail()
					this.loading = false
					this.modelShow1 = false
				}
			},
			async getCode(code,val){
				let res = await apiContractTemplate.getBase64ToPdfCode(code)
				if(res.data.code == 200){
					this.progressNum = 100
					this.baseImg1 = res.data.data.imageUrls
					this.urllist = res.data.data.imageUrls
					this.data.localUrl = res.data.data.imageUrls.join(',')
					this.data.url = res.data.data.pdfUrl
					if(val == 99){
						let obj = {
							contractNo: this.$route.query.no,
							images: res.data.data.imageUrls.join(','),
							signatureBase64:this.writeSignatureImg.signImg
						}
						let  res1 = await apiContractTemplate.postWriteSignature(obj)
						if(res1.data.code == 200){
							this.$message({
								// message: `合同签字成功，请耐心等待对方签字！`,
								message: `合同签字成功，请等待对方签署！`,
								type: 'success'
							})
						}else {
							this.$message({
								message: `${res1.data.msg}`,
								type: 'warning'
							})
						}
						console.log(res1)
						this.reload()
						// this.signCode()
						this.getContactDetail()
					}
					if (val == 1) {
						this.contractTitle = '合同预览'
						this.showPdf = true
					}if (val == 2) {
						this.saveStatu('2')
					}if (val == 'affirm') {
						this.saveStatu('affirm')
					}
					//废除合同
					if (val == 3) {
						this.DiscardContract()
					}
					if(val == 4){
						this.showSaveTemplate = true
						// this.saveTemplate(res)
					}
					this.loading = false
				}else {
					return this.awitTime(2000).then(()=>{
						if(this.progressNum >= 90){
							this.progressNum = 90
						}else {
							this.progressNum += 10
						}
						return this.getCode(code,val)
					})
				}
			},
			async publicPdf(val,obj){
				let res = await apiContractTemplate.postImgBase64ToPdf(obj)
				this.getCode(res.data.data,val)
			},
			awitTime(ms){
				return new Promise((res,rej)=>{
					setTimeout(res,ms)
				})
			},
			async sendContract(val, type) {
				if(val == 3){
					this.progressNum  = 10
					this.loading = true
					this.$refs.previewSvgPdf.tosvg('pdfDom', val)
					return
				}
				if(!this.data.title){
					this.$message({
						message: `请填写合同标题`,
						type: 'warning'
					})
					return
				}
				this.data.involves = []
				let flag = false
				const reg = /^1[3|4|5|6|7|8|9][0-9]\d{8}$/
				this.contractCompany.some((item,index)=>{
					if (!item.val) {
						this.$message({
							message: `请选择${item.name}方`,
							type: 'warning'
						})
						return  flag = true
					}
				})
				if(!flag){
					this.contractCompany.some((item,index)=>{
						for(var key in item.companyDetail){
							// if(key == 'legalRepresentative'){
							// 	if(item.companyDetail[key] != 'null' && !item.companyDetail[key]){
							// 		this.$message({
							// 			message: `请填写${item.name}方法定代表人`,
							// 			type: 'warning'
							// 		})
							// 		return  flag = true
							// 	}
							// }
							// if(key == 'consignor'){
							// 	if(item.companyDetail[key] != 'null' && !item.companyDetail[key]){
							// 		this.$message({
							// 			message: `请填写${item.name}方授权委托人`,
							// 			type: 'warning'
							// 		})
							// 		return  flag = true
							// 	}
							// }
							if(key == 'address'){
								if(item.companyDetail[key] != 'null' && !item.companyDetail[key]){
									this.$message({
										message: `请填写${item.name}方地址`,
										type: 'warning'
									})
									return  flag = true
								}
							}
							if(key == 'phone'){
								if(item.companyDetail[key] != 'null' && !item.companyDetail[key]){
									this.$message({
										message: `请填写${item.name}方电话`,
										type: 'warning'
									})
									return  flag = true
								}
							}
							if(key == 'phone' && !reg.test(item.companyDetail[key])){
								this.$message({
									message: `请填写正确的${item.name}方电话`,
									type: 'warning'
								})
								return flag = true
							}
						}
					})
				}
				if(!flag) {
					this.progressNum  = 10
					this.loading = true
					this.$refs.previewSvgPdf.tosvg('pdfDom', val)
				}

			},
			// 合同签章判断是否开通
			async signCode (val) {
				this.loading = true
				let isOpen = await apiContractTemplate.getOpenAccount(this.$route.query.no)
				if (!isOpen.data.data.data) {
					this.constractUserInfo = isOpen.data.data.data
					this.toast.tips = isOpen.data.data.msg
					// this.toast.title = '签署合同安全验证'
					this.modelShow = true // 是否显示弹框
					this.Draft = 'signCode'
					this.loading = false
				} else {
					this.contractTitle = '签署合同'
					this.baseImg1 = this.data.localUrl.split(',')
					this.chapter = this.baseImg1.map((item)=>{
						return {
							img:item,
							chapter: [],
							left:'',
							right:''
						}
					})
					this.contractSigna = true
					this.loading = false
				}
			},
			// 保存val 2：发送合同。1：存草稿
			async saveStatu (val) {
				this.contractCompany.forEach(item => {
					item.companyDetail.sort = this.getIndex(item.companyDetail.contractPosition);
					this.data.involves.push(item.companyDetail)
				});
				this.data.rule2 = JSON.stringify(this.TinymceData)
				this.data.status = val
				if(val == 'affirm'){ //修改合同的时候 == 2
					this.data.status = 2
				}
				this.data.customFiled = JSON.stringify(this.customFiled)
				if(val == 'affirm'){
					let res = await apiContractTemplate.postAmendContrac(this.data)
					console.log(res)
					if (res.data.code == 200) {
						this.loading = false
						this.reload()
						this.getContactDetail()
						this.$refs.logHistory.initData()
					}else {
						this.$message({
							message: res.data.msg,
							type: 'error'
						})
						this.loading = false
					}
					return
				}
				if(val ==1) { // 存草稿
					let res = await apiContractTemplate.postSendContrac(this.data)
					if (res.data.code == 200) {
						this.$message({
							message: '保存成功',
							type: 'success'
						})
						this.modelShow = false
						this.$removeTag('/contractList')
					}
					return
				}
				// if(this.procesState == 1 && (this.aprocessInfo.auditStatus !== 2 || this.aprocessInfo.auditStatus == null)){
				//   this.data.status = 1
				// }
				// //合同是否开启审批1：开启 0：未开启
				// //合同审批状态 审批状态 1 审核中 2 通过 3 不通过
				let res = await apiContractTemplate.postSendContrac(this.data)
				if (res.data.code == 200) {
					// if(this.procesState == 1 && this.aprocessInfo.auditStatus !== 2){
					//   this.watchStatus = true
					// }
					// this.$message({
					// 	message: '保存成功',
					// 	type: 'success'
					// })
					if(val == 1){
						this.removeTag('/contractList')
					} if(val == 2){
						this.getContactDetail()
					}
				} else {
					this.$message({
						message: res.data.msg,
						type: 'error'
					})
					this.loading = false
				}
			},
			// 初始化table表格列配置选项
			initColumns: function (arr) {
				const defaultOpts = {
					minWidth: 100
				}
				const list = arr.map(item => {
					return {
						prop: item.name,
						label: item.translate,
						...defaultOpts
					}
				})
				this.columns = list
			},
			// 招标清单列表数据初始化
			initTenderBill(data) {
				const {roleName, companyName, no} = this.$htgl_user
				const { orderNo, orderInfo} = data.orderDetail[0]
				const {type, creator, winningName, tenderType, goodsHeader=[], goodsList=[]} = orderInfo
				this.goodsType = type
				const isAdmin = roleName === '管理员' // 管理员
				const isFabiaoren = creator === no // 发标人
				const isWintender = winningName === companyName // 中标方
				const isZhaobiao = tenderType === 'tendering' // 招标，竞价
				const isZhaocai = tenderType === 'tendering' || tenderType === 'bidding'
				this.zcStatus = isZhaocai
				this.logStatus = {
					isAdmin,
					isFabiaoren,
					isWintender,
					isZhaobiao,
					orderNo,
					type
				}
				goodsHeader && goodsHeader.length &&this.initColumns(goodsHeader)
				goodsList && goodsList.length && this.initTableList(goodsList)
			},
			// 初始化表格列表
			initTableList(arr) {
				const newArr = []
				arr.forEach(item => {
					const obj = Object.create({})
					item.forEach(x => {

						obj[x.name] = x.value
						// if(x.name === 'num' || x.name === 'unit') {
						// 	console.log(x.name);
						// 	console.log(x.value);
						// 	obj[x.name] = `${x.value}${x.unit}`
						// }
					})
					newArr.push(obj)
				})
				console.log(newArr)
				this.tableData = newArr
			},
			//实时设置审批状态
			setprocesState(val){
				this.procesState = val
			},
			//获取合同是否开启审批
			async postProcessByType(data){
				let obj = {
					companyId: this.$htgl_user.cno + "",
					type: 'signContract'
				}
				if(data.isTaker == true && data.signTag == 6){
					obj.type = 'signContract'
				}
				let res = await api.queryProcessByType(obj)
				//设置了审批并且开启了审批才会请求审批日志和详情
				if(res.data.data && res.data.data != null && res.data.data.rootNode.switchOn == 1){
					//1：开启 0：未开启
					this.procesState = res.data.data.rootNode.switchOn
					this.processLog(res.data.data) //审批日志
					//获取审批详情
					this.checkApproveStatus(data)
				}else {
					this.procesState = 0
				}
				console.log(res.data.data && res.data.data != null)

			},
			// 获取合同详情
			async getContactDetail (orderNo) {
				this.loading = true
				this.modelShow = false
				this.modelShow1 = false
				let res = await apiContractTemplate.getContract(this.$route.query.id,this.$htgl_user.companyNo)
				console.log(res,'res---');
				// 初始化报价清单
				if(res.data.code == 200) {
					this.initTenderBill(res.data.data)
					this.data = _.cloneDeep(res.data.data)
					//获取审批状态
					this.postProcessByType(res.data.data)
					// this.data.type 3 租赁-出租， 4  租赁-租入
					if (this.data.type == 3 || this.data.type == 4) {
						this.type = "Zulin"
					}
					if (this.data.localUrl) {
						this.urllist = this.data.localUrl.indexOf(',') === -1 ?  [this.data.localUrl] : this.data.localUrl.split(',')
					} else {
						this.urllist = []
					}
					//日志
					this.contractLog()
					this.htstatus = this.data.status;
					this.loading = false
					// this.$refs.logHistory.contractLog()
					// 已驳回状态
					this.deadline = this.data.deadline;
					await this.getContractCompanyList()
					if(this.data.customFiled){
						//合同新增段落
						this.customFiled = JSON.parse(this.data.customFiled)
					}
					//合同其他条款
					if(this.data.rule2){
						this.TinymceData = JSON.parse(this.data.rule2)
					}else {
						let TinymceArr = [
							// {title:'付款及结算方法',rule:''},
							{title:'违约责任',rule:''},
							{title:'争议解决方式',rule:''},
							{title:'双方权利',rule:''},
						]
						this.TinymceData = TinymceArr
					}
				}else {
					this.loading = false
				}
			},
			async checkApproveStatus(data){
				let obj = {
					id: data.id,
					type: 'signContract'
				}
				// if(data.isTaker == true && data.signTag == 6){
				// 	obj.type = 'sendContract'
				// }
				let res = await apiContractTemplate.getfindAuditStatus(obj)
				if(res.data.code == 200){
					this.aprocessInfo = res.data.data
				}
				console.log(this.aprocessInfo)
			},
			changeHandler(val, index) {
				if (val) {
					let com = this.choosedCom.findIndex(item => item.index === index);
					if (com === -1) {
						this.choosedCom.push({
							val,
							index
						})
					} else {
						this.choosedCom[com].val = val;
					}
				}
			},
			clearHandler(index) {
				this.choosedCom = this.choosedCom.filter(item => {
					return item.index !== index;
				})
			},
			// 获取合同所涉及公司
			async getContractCompanyList (orderNo) {
				let res = await apiContractTemplate.getContractCompany(this.$route.query.no)
				console.log(res)
				if(res.data.code == 200) {
          res.data.data=res.data.data.map(v=>{
            return {
              ...v,
              address:'',
              phone:'',
            }
          })
					this.comOptions = res.data.data;
					this.allcomOptions = res.data.data;
					let obj = {}
					this.contractCompany = []
					let contractPositionArr = this.data.involves.map(item => {
						return item.contractPosition
					})
					let finaArr = this.data.positionName.filter(item => {
						return !contractPositionArr.includes(item)
					})
					this.data.involves.forEach((item2,index) => {
						if(res.data.data[index].contractPosition == item2.contractPosition) {
						// if (this.data.positionName.includes(item2.contractPosition)) {
							obj = {
								name:res.data.data[index].contractPosition,
								val:res.data.data[index].companyNo,
								// val:item2.id,
								companyDetail: res.data.data[index],
							}
							console.log(obj)
						} else {
							obj = {
								name: finaArr.shift(),
								val: "",
								companyDetail: {},
							}
						}
						this.contractCompany.push(obj)
					})
					setTimeout(() => {
						res.data.data.forEach((item, index) => {
							if (item.contractPosition) {
								this.choosedCom.push({
									val:item.companyNo,
									// val:item.id,
									index
								});
							}
						})
					}, 500)
					console.log(this.contractCompany)
				}
			},
			// 关闭（）
			closeDialog () {
				this.loading = false
				this.showPdf = false
				this.showSaveTemplate = false
				this.showSaveTemplateList = false
			},
		}
	}
</script>
<style scoped>
  >>> .contractCity .el-form-item__content .el-cascader{
    width: 500px !important;
  }
  >>> .myTextEditor{
    position: relative;
  }
  .textLength{
    position: absolute;
    right: 5px;
    bottom: 5px;
  }
  >>>.editor_shop .ql-container{
    min-height: 200px;
  }
  >>> .templateHead .el-dialog__body{
    /*padding: 0px;*/
    border-top: none !important;
  }
  >>> .codeInput .el-form-item__label{
    font-weight: 400;
    color: #606266;
  }
  >>> .title .el-input .el-input__inner{
    font-size: 24px;
    color: #000000;
    border: none;
    text-align: center;
    font-weight: bold;
  }
  >>> .contractRule .el-input__inner{
    height: 30px;
    line-height: 30px;
  }
  >>>.el-dialog__body{
    padding: 0 20px;
    /*border-top: 1px solid #e4e7ed;*/
  }
  /*>>>.el-textarea .el-textarea__inner{*/
  /*border: none;*/
  /*padding: 0;*/
  /*}*/
  >>> .borderclass .el-textarea .el-input__inner{
    border: 1px solid #DCDFE6 !important;
  }
  >>>.el-form-item__label{
    /*font-size: 16px;*/
    color: #000000;
    /*font-weight: bold;*/
  }
  .el-form-item{
    margin-bottom: 10px;
  }
  .signBox .el-textarea{
    width: 60%;
  }
  .signBox div.fontColor{
    /*width: 80%;*/
    font-size: 16px;
    color: #000000;
    font-weight: bold;
  }
  >>>.signBox .el-textarea.is-disabled .el-textarea__inner{
    background-color: #ffffff;
  }
  >>>.signBox .el-textarea.is-disabled .el-textarea__inner{
    background-color: #ffffff;
  }
  >>> .signBox .el-textarea .el-textarea__inner{
    border: none;
    padding: 0;
    font-size: 16px;
    color: #000000;
    font-weight: bold;
    padding-top: 10px;
  }

  .signBox .el-input{
    width: 60%;
  }
  >>>.signBox .el-input.is-disabled .el-input__inner{
    background-color: #ffffff;
  }
  >>>.el-input.is-disabled .el-input__inner{
    background-color: #ffffff;
  }
  >>> .signBox .el-input .el-input__inner{
    border: none;
    padding: 0;
    font-size: 16px;
    color: #000000;
    font-weight: bold;
  }
  >>>.cascaderBox .el-input__inner{
    border: none;
    padding: 0;
    font-size: 16px;
    color: #000000;
    font-weight: bold;
  }
  >>>.cascaderBox .el-input__suffix{
    display: none;
  }
</style>
<style scoped lang="scss" rel="stylesheet/scss">
  .wd100 {
    width: 100%;
  }
  .previewBox{
    height:700px;
    margin: 0 auto;
    overflow: scroll;
    padding: 0 20px;
    .previewImg{
      /*width: 794px;*/
      /*height: 1128px;*/
      position: relative;
      margin-top: 10px;
      &:nth-child(1){
        padding-top: 0;
      }
      img{
        display: block;
        margin: 0 auto;
      }
    }
    .pitchImg{
      border: 1px solid #0286DF !important;
    }
  }
  .dragDiv{
    position: absolute;
    left: 0;
    top: 0;
    width: 100px;
    height: 100px;
    //border: 1px solid #fa4f16;
    div{
      position: relative;
      img{
        width: 100%;
        pointer-events: none;
      }
      i{
        position: absolute;
        right: -15px;
        top: -15px;
      }
    }
  }
  .previewBtn{
    text-align: center;
    padding: 20px 0;
    border-top: 1px solid #e4e7ed;
  }
  p{
    margin: 0;
    padding: 0;
  }
  .edit{
    color: #666666;
    cursor: pointer;
  }
  .signCode{
    cursor: pointer;
    color: #0286DF;
  }
  .signBox{}
  .fontColor{
    font-size: 16px;
    color: #000000;
    font-weight: bold;
  }
  .templateContent{
    position: relative;
    border-right: 10px solid #fafafa;
    .contractImg{
      text-align: center;
      border-top: 1px solid #e4e7ed;
      &:nth-child(1){
        border-top:  none;
      }
    }
    .contractPdf{
      width: 842px;
      margin: 0 auto;
      border-top: 1px solid #e4e7ed;
      &:nth-child(1){
        border-top:  none;
      }
    }
    .contentHead{
      background-color: #0286DF;
      height: 40px;
      line-height: 40px;
      color: #ffffff;
      font-size: 14px;
      padding: 0 20px;
      .reset{
        text-align: left;
        span{
          display: inline-block;
          cursor: pointer;
        }
      }
      .save{
        text-align: right;
        span{
          cursor: pointer;
          display: inline-block;
          margin-right: 20px;
        }
      }
    }
  }
  .bgImg {
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
  }
  .templateBox{
    // width: 751.89px;
    padding: 40px 50px;
    position: relative;
    .title{
      text-align: center;
      padding: 0 0 40px 0;
      font-size: 24px;
      color: #000000;
      width: 100%;
      margin: 0 auto;
      font-weight: bold;
      span{
        display: block;
        width: 100%;
      }
    }
  }

  .toast {
    text-align: center;
    button {
      padding: 0 21px;
      height: 40px;
    }
  }
  .contractNo {
    text-align: right;
    font-size: 14px;
    color: #333333;
    span{
      color: #000000;
    }
  }
  .contractRule{
    padding: 6px 10px;
    background-color: #FAFAFA;
    border:  1px solid #E4E7ED;
    border-bottom: none;
    i{
      padding: 4px 0;
      color: #FF6600;
    }
  }
  .contractRule-btn {
    text-align: left;
    .el-button {
      &.is-plain {
        border: 1px solid #0286df;
        border-radius: 4px;
        color: #0286df;
      }
    }
  }
  .divCover {
    margin:0;
    padding:0;
    position:absolute;
    left:0;
    top:40px;
    z-index: 99;
    /*width:100%;*/
    /*height:100%;*/
    background:#ffffff;
    filter:alpha(opacity=90);
    opacity:0.9;
  }
  .banClick{
    pointer-events: none;
  }
  .pdfDom{
    width: 841.89px;
    position: fixed;
    z-index: -1;
    background-color: #ffffff;
    left: 0;
    top: 0;
    .templateBox1{
      /*width: 522px;*/
      /*margin: 0 auto;*/
      width: 841.89px;
      /*padding: 0 50px;*/
      padding-top: 80px;
      position: relative;
      .title{
        text-align: center;
        padding: 0 0 40px 0;
        font-size: 24px;
        color: #000000;
        width: 100%;
        margin: 0 auto;
        font-weight: bold;
        span{
          display: block;
          width: 100%;
        }
      }
      .contractNo {
        text-align: right;
        font-size: 14px;
        color: #333333;
        span{
          color: #000000;
        }
      }
      .fontColor{
        font-size: 16px;
        color: #000000;
        font-weight: bold;
      }
    }
  }
  .SignatureImg{
    position: relative;
    img{
      position: absolute;
      right: 0px;
      top: 5px;
    }
  }
</style>
