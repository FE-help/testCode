/**
* @Descripttion: 未描述
* @Author: Chenbangquan
* @version: 1.0.0
* @CreateDate 2021-07-05 11:16
* @LastEditors: cbq
* @LastEditTime: 2021-07-05
*/
<template>
  <div class="contractSigna">
    <div class="contractSignaBox">
      <el-row>
        <el-col :span="24">
          <div style="border-left: 1px solid #E4E7ED">
            <el-row class="contractStatus">
              <el-col :span="15">
                <span>合同签署</span>
                <!--<p>请耐心等待对方查阅并签署合同。</p>-->
                <p>签字完成后，请等待对方签署盖章</p>
              </el-col>
              <el-col :span="9">
                <div class="previewBtn">
                  <el-button class="mr10" @click="$emit('close',false)">取 消</el-button>
                  <el-button class="sendBtn mr10" type="primary" v-if="contracDetail.signatureFlag" @click="showsignatureFlag = true">签字</el-button>
                  <el-button class="sendBtn mr10" v-if="!contracDetail.signatureFlag" type="primary" @click="signature">加盖公章（{{index}}）</el-button>
                  <el-button class="sendBtn" v-if="!contracDetail.signatureFlag" type="primary" @click="codeShowSigna()" :loading="loading">提交签署</el-button>
                </div>
              </el-col>
              <!--<div class="contractStatus">-->
              <!---->
              <!--</div>-->
            </el-row>
            <div class="previewBox">
              <canvasQM ref="canvasQM" v-bind="$attrs"
                        v-on="$listeners"
                        v-if="showsignatureFlag"
                        @setShowsignatureFlag="setShowsignatureFlag">
              </canvasQM>
              <div style="border: 1px solid #e4e7ed" v-for="(item,index) in chapter" class="previewImg"
                   @click="pIndex = index"
                   :key="item.img"
                   :id="'pdfDom' + index"
                   :class="{pitchImg : pIndex == index}">
                <img class="bgImg" style="width: 100%" :src="item.img"/>
                <!--@mousedown="down($event,indexs,items)"-->
                <!--draggable="true"-->
                <div class="dragDiv"
                     ref="dragDiv"
                     v-drag
                     v-for="(items,indexs) in item.chapter"
                     :key="items.key"
                     :id="items.id">
                  <div>
                    <img :src="items.img" class="bgImg">
                    <i @click="delChapter(index,indexs)" class="el-icon-delete"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </el-col>
      </el-row>
    </div>
    <div class="codeInput">
      <el-dialog
              title="签署合同安全验证"
              :visible.sync="codeShow"
              :close-on-click-modal="false"
              :close-on-press-escape="false"
              :modal="false"
              width="600px">
        <div class="tips">
          <img src="@/assets/gantanhao.png" alt />
          <span>签署代表您的真实意愿，签署后将产生相应的法律效应。</span>
        </div>
        <p class="mb20 clearfix" v-if="processList.length >2 && procesState == 1">
          <span class="fl">上级审批意见</span>
          <span class="fr cursor" @click="showMoreFn">{{showMoreSpan}}</span>
        </p>
        <div v-if="procesState == 1" class="procesList">
          <!--节点审批状态 (-1, '待审批'), (0, '审批中'),(1, '通过'),(2, '拒绝'); (4, '拒绝之后的节点')-->
          <el-timeline>
            <el-timeline-item
                    v-for="(item, index) in processList"
                    v-show="index <= showIndex"
                    :key="index">
            <span v-for="(items,indexs) in item.nodeDetail" :key="indexs">
              <span v-if="item.nodeStatus == -1">待审批</span>
              <span v-if="item.nodeStatus == 0">审批中</span>
              <span v-if="item.nodeStatus == 1">审批通过</span>
              <span v-if="item.nodeStatus == 2">已拒绝</span>
              <span class="ml40">{{items.name}}</span>
              <span class="ml40">{{items.reason || '暂无'}}</span>
            </span>
            </el-timeline-item>
          </el-timeline>
        </div>
        <el-form :model="ceodeModel">
          <!--`：`-->
          <el-form-item :label="`请输入${constractUserInfo.name}手机（${constractUserInfo.phone}）获取的验证码：`">
            <el-input class="wd300" v-model="ceodeModel.code"></el-input>
            <button8 style="margin-left: 10px" @click="signa" v-if="show">获取验证码</button8>
            <!--<button4 style="margin-left: 10px" @click="signa" v-if="!show && !timer">重新发送</button4>-->
          </el-form-item>

        </el-form>
        <p>
          <span v-if="!show">[已发送验证码（{{count}}s)]</span>
        </p>
        <div style="text-align: center;padding: 40px 0">
          <button7 @click="codeShow = false">取 消</button7>
          <el-button style="margin-left: 20px" type="primary" @click="checkStatusByNowStatus" :loading="loading">确认签署</el-button>
        </div>
      </el-dialog>
    </div>
    <CommonModalTips :isVisible="modelShow"
                     :title="toast.title"
                     :tipsText="toast.tips"
                     :mStatus="toast.mStatus"
                     :appendtTobody="toast.appendtTobody"
                     @close="$emit('getContactDetail')">
      <div slot="footer" class="toast">
        <el-button type="primary" @click="closeModel()">知道了</el-button>
      </div>
    </CommonModalTips>
  </div>
</template>

<script>
	import img from '../components/images/chapter.png'
	import apiContractTemplate from '@/api/apiContract/apiContract'
	import apiPact from "@/api/apiContract/apiContract.js";
	import _ from 'lodash';
	import apiApprove from "@/api/apiMyApprove/index";

	import cgs from '../components/images/cgs.png'
	import gys from '../components/images/gys.png'
	export default {
		inject:['reload'],
		name: "contractSigna",
		props:{
			contractvisible: {
				type: Boolean
			},
			aprocessInfo: {},
			procesState: {},
			chapter:{
				type: Array
			},
			contracDetail:{
				type: Object
			},

		},
		data(){
			return{
				showMoreSpan:'查看更多',
				showMore: false,
				showsignatureFlag: false,//签字canvas
				showIndex: 2, //查看更多
				processList:[],//流程
				loading:false,
				ByNowStatus:false,
				img:img,
				ChapterNum: 3,
				pIndex: null,
				flags: false,
				position1: [],
				index: 3,
				chapterIndex: 0,
				// 验证码
				ceodeModel: {
					code: ''
				},
				codeShow: false,
				modelShow: false,
				show: true,
				count: '',
				timer: null,
				imgId: 0,
				constractUserInfo:{},
				toast: {
					tips: '',
					mStatus: 'warning',
					title: '',
					appendtTobody:true
				},
			}
		},
		components:{
			CommonModalTips: () => import("@/components/public/CommonModalTips.vue"),
			canvasQM: ()=>import("@/views/AccountManagement/ElectronicContract/components/canvasQM"),
		},
		created(){
			this.getIsOpenAccount()
		},
		watch:{
			processList(n){
				return n
			},
			aprocessInfo(n) {
				this.initData()
			}
		},
		directives: {
			drag: {
				// 指令的定义
				bind: function (el, binding, node) {
					let odiv = el;   //获取当前元素
					let vm = node.context
					console.log(vm)
					let fa = document.getElementById(`pdfDom${vm.pIndex}`)
					el.onmousedown = (e) => {
						//算出鼠标相对元素的位置
						let disX = e.clientX - odiv.offsetLeft;
						let disY = e.clientY - odiv.offsetTop;
						let left = '';
						let top = '';
						document.onmousemove = (e)=>{
							//用鼠标的位置减去鼠标相对元素的位置，得到元素的位置
							left = e.clientX - disX;
							top = e.clientY - disY;
							if (left <= 0) {
								left = 1
							} else if (left >= fa.clientWidth - odiv.offsetWidth) {
								// document.documentElement.clientWidth 屏幕的可视宽度
								left = fa.clientWidth - odiv.offsetWidth
							}

							if (top <= 0) {
								top = 1
							} else if (top >= fa.clientHeight - odiv.offsetHeight) {
								// document.documentElement.clientHeight 屏幕的可视高度
								top = fa.clientHeight - odiv.offsetHeight
							}
							//绑定元素位置到positionX和positionY上面
							//移动当前元素
							odiv.style.left = left + 'px';
							odiv.style.top = top + 'px';
							let key = node.elm.id == 0 ? node.elm.id : node.elm.id - 1
							console.log(odiv.style.left)
							console.log(odiv.style.top)
							// console.log(vm.chapterIndex)
							// vm.position1[vm.chapterIndex - 1].x = left
							// vm.position1[vm.chapterIndex - 1].y = fa.getBoundingClientRect().height  - top
						};
						document.onmouseup = (e) => {
							document.onmousemove = null;
							document.onmouseup = null;
						};
					};
				}
			}
		},
		methods:{
			setShowsignatureFlag(val){
				this.showsignatureFlag = val
			},
			closeModel(){
				this.$emit('getContactDetail')
				this.modelShow = false
			},
			showMoreFn(){
				if(this.showMore){
					this.showMore = false
					this.showMoreSpan = '收起'
					this.showIndex = 2
				}else {
					this.showIndex = this.processList.length
					this.showMore = true
					this.showMoreSpan = '查看更多'
				}
			},
			//审批流程
			initData() {
				let params = { id: this.aprocessInfo.auditId}
				apiApprove.ApprovalLog(params).then(({ data: result }) => {
					this.processList = result.data;
				})
				console.log(this.processList)
			},
			//判断合同状态
			async checkStatusByNowStatus(){
				let obj = {
					No: this.$route.query.no,
					status: this.contracDetail.status
				}
				let  res = await apiContractTemplate.getContracStatusStatus(obj)
				if(!res.data.data){
					this.ByNowStatus = res.data.data
					this.toast.title = '提示'
					this.toast.mStatus = 'warning'
					this.toast.tips = res.data.msg
					this.modelShow = true
				}else {
					//未开启签署
					if(this.procesState == 0){
						this.submitCode()
						return
					}
					this.checkApproveStatus()
				}
			},
			async checkApproveStatus(){
				let obj = {
					id: this.contracDetail.id,
					type: 'signContract'
				}
				let res = await apiContractTemplate.getfindAuditStatus(obj)
				if(res.data.code == 200){
					if(this.aprocessInfo.auditStatus !== res.data.data.auditStatus){
						this.toast.tipsText = '当前合同审核状态已发生变更，请重新加载页面！'
						this.toast.title = '提示'
						this.toast.mStatus = 'warning'
						this.modelShow = true
					}else {
						this.submitCode()
					}
				}
			},
			async getIsOpenAccount() {
				let res = await apiPact.getOpenAccountMsg(this.$htgl_user.no)
				console.log(res)
				if(res.data.code == 200 && this.aprocessInfo.auditId) {
					this.initData()
				}
				this.constractUserInfo = res.data.data
			},
			delChapter(index,indexs){
				let data = _.cloneDeep(this.chapter)
				this.position1.splice(indexs, 1)
				data[index].chapter.splice(indexs, 1)
				this.index++
				this.chapterIndex--
				// this.imgId--
				this.$emit('delChapter',data)
				// this.chapter = JSON.parse(JSON.stringify(data))
			},
			codeShowSigna(){
				if (this.index == 3) {
					this.$message({
						message: '请先添加印章',
						type: 'warning'
					})
					return
				}
				this.position1 = []
				let arr = this.$refs.dragDiv
				arr.forEach((item,index)=>{
					let id = item.id
					let fa = document.getElementById(`pdfDom${id}`).getBoundingClientRect().height
					let reg = new RegExp("px","g");
					let data = {
						x: Number(item.style.left.replace(reg,'')),
						y: Number(fa)  - Number(item.style.top.replace(reg,'')),
						// y: document.getElementById(`pdfDom${this.pIndex}`).getBoundingClientRect().height -100,
						index: Number(item.id) + 1,
					}
					this.position1.push(data)
				})
				this.codeShow = true
			},
			async signa(){
				let data = {contractNo: this.$route.query.no}
				// 获取验证码
				let res = await apiContractTemplate.getSendCode(data)
				if (res.data.code == 200) {
					this.show = false
					this.$message({
						message: '验证码发送成功',
						type: 'success'
					})
					this.getCode()
				} else {
					this.$message.error(res.data.msg)
				}
			},
			// 获取验证码
			getCode () {
				const TIME_COUNT = 60
				if (!this.timer) {
					this.count = TIME_COUNT
					this.show = false
					this.timer = setInterval(() => {
						if (this.count > 0 && this.count <= TIME_COUNT) {
							this.count--
						} else {
							this.show = true
							clearInterval(this.timer)
							this.timer = null
						}
					}, 1000)
				}
			},
			// 提交签署
			async submitCode () {
				if (!this.ceodeModel.code) {
					this.$message({
						type: 'error',
						message: '验证码不能为空'
					})
					return
				}
				let arr = []
				this.position1.forEach(item => {
					let axisz = {
						// 1磅 = 1.333 像素
						signLocationLBX: Math.ceil(item.x /1.338), // 左下角x
						signLocationLBY: Math.ceil((item.y - 100)/1.338 <= 0 ? 1 : (item.y - 100)/1.338 ), // 左下角y
						signLocationRUX: Math.ceil((item.x + 100)/1.338), // 右上角x
						signLocationRUY: Math.ceil(item.y / 1.338 +1), // 右上角y
						signOnPage: item.index
					}
					arr.push(axisz)
				})
				let data1 = {
					images: this.contracDetail.localUrl,
					code: this.ceodeModel.code,
					contractNo: this.$route.query.no,
					signLocations: arr,
				}
				this.loading = true
				console.log(data1)
				// return
				let res1 = await apiContractTemplate.postverifyCode(data1)
				if (res1.data.code == 200) {
					this.$message({
						type: 'success',
						message: '签署成功'
					})
					this.loading = false
					this.$emit('close')
					this.reload()
					// this.$emit('getContactDetail')
					this.codeShow = false
				}else {
					this.$message.error(res1.data.msg)
					this.loading = false
				}
			},
			// 添加盖章
			signature() {
				if (this.pIndex == null) {
					this.$message({
						message: '请选择您要签章的页',
						type: 'warning'
					})
					return
				}
				if (this.index == 0) {
					this.$message({
						message: '只能添加三个印章',
						type: 'warning'
					})
					return
				}
				let img1 = {
					img: img,
					key:this.imgId ++ ,
					id: this.pIndex
				}

				this.chapter[this.pIndex].chapter.push(img1)
				this.index--
				this.chapterIndex++
			},
		}
	}
</script>
<style scoped>
  >>> .codeInput .el-form-item__label{
    font-weight: 400;
    color: #606266;
  }
  >>> .codeInput .el-dialog__body{
    padding: 0 20px;
    /*border-top: 1px solid #e4e7ed;*/
  }
  >>> .codeInput .el-form-item{
    margin-bottom: 10px;
  }
  >>> .codeInput .el-form-item__label{
    color: #000000;
    font-size: 14px;
  }
</style>
<style lang="scss" scoped>
  .Chapter{
    padding: 20px;
    width: 200px;
    height: 200px;
  }
  .contractSigna{
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 100;
    background: rgba(0,0,0,.3);
  }
  .contractSignaBox{
    background-color: #ffffff;
    width: 1240px;
    /*height: 100%;*/
    margin: 0 auto;
    overflow: auto;
    overflow-x: hidden;
  }
  .previewBox{
    height:calc(100vh - 94px);
    overflow: scroll;
    padding: 0 20px;
    position: relative;
    .previewImg{
      width: 794px;
      /*width: 841.89px;*/
      /*height: 842px;*/
      position: relative;
      margin-top: 10px;
      margin: 0 auto;
      &:nth-child(1){
        padding-top: 0;
      }
      img{
        width: 100%;
        height: 100%;
        display: block;
        margin: 0 auto;
      }
    }
    .pitchImg{
      border: 1px solid #0286DF !important;
    }
  }
  .dragDiv{
    position: absolute;
    left: 0;
    top: 0;
    width: 95px;
    height: 95px;
    //border: 1px solid #fa4f16;
    div{
      position: relative;
      img{
        width: 100%;
        pointer-events: none;
      }
      i{
        position: absolute;
        bottom: -1px;
        right: -11px;
        color: red;
      }
    }
  }
  .previewBtn{
    text-align: right;
    /*padding: 20px 0;*/
    /*border-top: 1px solid #e4e7ed;*/
  }
  .bgImg {
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
  }
  .contractStatus{
    padding: 20px;
    text-align: left;
    border-bottom: 1px solid #e4e7ed;
    span{
      color: #000000;
      font-size: 18px;
      font-weight: bold;
    }
    p{
      margin-top: 12px;
      font-size: 12px;
      color: #969696;
    }
  }
  .tips{
    height: 40px;
    line-height: 40px;
    background-color: #FDF6EC;
    padding:  0 20px 0 40px;
    margin: 30px 0  10px 0;
    position: relative;
    img {
      position: absolute;
      left: 20px;
      top: 13px;
      width: 14px;
      height: 14px;
      margin-right: 10px;
    }
    span{
      color: #E6A23C;
      font-size: 14px;
    }
  }
  .toast {
    text-align: center;
    button {
      padding: 0 21px;
      height: 40px;
    }
  }
  .procesList{
    height: 100px;
    overflow: scroll;
    overflow-x: hidden;
  }
</style>
