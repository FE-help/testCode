/**
* @Descripttion: 未描述
* @Author: Chenbangquan
* @version: 合同1.0.3
* @CreateDate 2021-09-14 12:19
* @LastEditors: cbq
* @LastEditTime: 2021-09-14
*/
<template>
  <div style="padding: 20px 0 40px 0">
    <el-row>
      <el-form
              :model="contractTemplate"
              label-width="82px"
              class="demo-detail">
        <el-col :span="12">
          <el-form-item label="合同类型：" prop="category" class="mr20">
            <el-select
                    class="wd180"
                    v-model="contractTemplate.category"
                    placeholder="请选择"
                    @change="contractTemplateList"
                    clearable>
              <el-option
                      v-for="item in statuses"
                      :key="item.key"
                      :label="item.value"
                      :value="item.key"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="合同分类：" prop="type">
            <el-select
                    class="wd180"
                    v-model="contractTemplate.type"
                    placeholder="请选择"
                    @change="contractTemplateList"
                    clearable>
              <el-option
                      v-for="item in types"
                      :key="item.key"
                      :label="item.value"
                      :value="item.key"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-form>
    </el-row>
    <div class="add-type-inner clearfix">
      <div v-for="(item,index) in menuList"
           @click="active = index"
           @mouseenter="active = index"
           @mouseleave="active = index"
           :key="index" :class="{ 'activeOn': active == index}">
        <div class="butn" v-if="active == index && !show">
          <el-row>
            <el-col :span="12"><span @click="preview(item)">预览</span></el-col>
            <el-col :span="12">
              <span class="clFF6600" @click="show = true">删除</span>
            </el-col>
          </el-row>
        </div>
        <div class="butn" v-if="active == index && show">
          <el-row>
            <el-col :span="12"><span @click="show = false">取消</span></el-col>
            <el-col :span="12"><span class="clFF6600" @click="delTemplate(item)">删除</span></el-col>
          </el-row>
        </div>
        <img :src="item.images" alt="">
        <div class="name" :title="item.name">{{item.name}}</div>
      </div>
    </div>
    <div class="noData" v-if="menuList.length == 0">
      <img src="@/assets/zanwushuju.png">
      <p>暂无数据</p>
    </div>
    <div class="block" style="text-align: center;padding: 10px 0 20px 0" v-if="menuList.length > 0" >
      <el-pagination
              class="page"
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="contractTemplate.pages"
              :page-size="contractTemplate.limit"
              layout="prev, pager, next, jumper"
              :total="total">
      </el-pagination>
    </div>
    <div class="warnTip">温馨提示：使用模板会替换现有合同的内容，请谨慎操作！</div>
    <div style="text-align: center">
      <button7 class="mr10" @click="$emit('closeDialog')">取消</button7>
      <el-button type="primary" @click="useTemplate">使用模板</el-button>
    </div>
    <CommonModalTips1
            :isVisible="modelShow"
            :title="toast.title"
            :tipsText="toast.tips"
            :mStatus="toast.mStatus"
            :appendtTobody="toast.appendtTobody"
            @close="closeTips">
      <div slot="footer" class="toast">
        <el-button type="primary" @click="closeTips">知道了</el-button>
      </div>
    </CommonModalTips1>
  </div>
</template>

<script>
	import apiContract from '@/api/apiContract/apiContract'
	import img from '@/assets/2.png'
	export default {
		name: "contractTemplateList",
		data(){
			return{
				toast: {
					tips: '',
					mStatus: 'warning',
					title: '',
					appendtTobody:true
				},
				modelShow:false,
				show:false,
				menuList: [],
				types:[],
				active:-1,
				statuses:[],
				contractTemplate:{
					category:'',
					type:'',
					companyName: "",
					limit: 10,
					page: 1,
				},
				total:1,
			}
		},
		components:{
			CommonModalTips1: () => import("@/components/public/CommonModalTips.vue"),
		},
		created(){
			this.getStatus()
			this.contractTemplateList()
		},
		methods:{
			//预览
			async preview(row) {
				let id = row.id
				let res = await  apiContract.getModuleDetail(id)
				if(res.data.code == 200 && !res.data.data){
					this.modelShow = true
					this.toast.title = '提示'
					this.toast.tips = '当前合同模板状态已发生变更请重新选择合同模板'
					return
				}
				window.open(`${process.env.VUE_APP_PERSONURL}/previewModule?id=${row.id}`);
			},
			handleSizeChange(val) {
				this.contractTemplate.limit = val
				this.contractTemplateList()
			},
			handleCurrentChange(val) {
				this.contractTemplate.page = val
				this.contractTemplateList()
			},
			async contractTemplateList(){
				let res = await apiContract.getModuleList(this.contractTemplate)
				this.menuList = res.data.data.records
				this.menuList.forEach((item, index)=>{
					// if(!item.images){
					item.images = img
					// return
					// }
					// item.images = item.images.indexOf(',') === -1 ?  [item.images] : item.images.split(',')[0]
				})
				this.total = res.data.data.total
			},
			//删除模板
			async delTemplate(val){
				let res = await apiContract.deleteModule(val.id)
				if(res.data.code == 200){
					this.$message({
						message: '合同模块删除成功！',
						type: 'warning'
					})
				}
				this.contractTemplate.page = 1
				this.contractTemplateList()
			},
			//使用合同模板
			async useTemplate(){
				console.log(this.active)
				if(this.active < 0 ){
					this.$message({
						message: '请选择模板！',
						type: 'error'
					})
					return
				}
				let id = this.menuList[this.active].id
				let res = await  apiContract.getModuleDetail(id)
				if(res.data.code == 200 && !res.data.data){
					this.modelShow = true
					this.toast.title = '提示'
					this.toast.tips = '当前合同模板状态已发生变更请重新选择合同模板'
					return
				}
				this.$emit('useTemplate',res.data.data)
				this.$emit('closeDialog')
			},
			closeTips(){
				this.$emit('closeDialog')
				this.$emit('getContactDetail')
				this.modelShow = false
			},
			async getStatus() {
				let { data } = await apiContract.postContractCategory({});
				this.statuses = data.data;
				let res= await apiContract.getContractType();
				this.types = res.data.data
			}
		}
	}
</script>

<style scoped lang="scss">
  .warnTip {
    padding-bottom: 20px;
    font-size:14px;
    font-family:Microsoft YaHei;
    font-weight:400;
    color:#FFC000;
    line-height:20px;
  }
  .activeOn{
    border:1px solid #0286DF !important;
  }
  .add-type-inner{
    width: 559px;
    >div{
      width: 96px;
      height: 120px;
      border:1px solid #E4E7ED;
      cursor: pointer;
      margin-left: 17px;
      float: left;
      margin-bottom: 20px;
      position: relative;
      &:nth-child(1){
        margin-left: 0;
      }
      &:nth-child(6){
        margin-left: 0;
      }
      >img{
        width: 100%;
        height: 100%;
      }
      >.name{
        position: absolute;
        text-align: center;
        bottom: 0;
        font-size:12px;
        font-family:Microsoft YaHei;
        font-weight:400;
        color:rgba(255,255,255,1);
        background:rgba(0,0,0,0.5);
        width: 100%;
        height: 20px;
        line-height: 20px;
        overflow:hidden;
        text-overflow:ellipsis;
        -o-text-overflow:ellipsis;
        white-space:nowrap;
      }
      >.butn{
        position: absolute;
        text-align: center;
        top: 0;
        font-size:12px;
        font-family:Microsoft YaHei;
        font-weight:400;
        color:rgba(255,255,255,1);
        background:rgba(0,0,0,0.5);
        width: 100%;
        height: 20px;
        line-height: 20px;
      }
    }
  }
  .noData {
    border: none;
    margin-top: 50px;
    text-align: center;
    font-size: 16px;
    color: #666666;
  }
  .toast {
    text-align: center;
    button {
      padding: 0 21px;
      height: 40px;
    }
  }
</style>
