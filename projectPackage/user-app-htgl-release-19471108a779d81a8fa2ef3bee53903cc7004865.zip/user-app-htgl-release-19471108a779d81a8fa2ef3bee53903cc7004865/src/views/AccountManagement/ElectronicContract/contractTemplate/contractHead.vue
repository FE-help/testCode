/**
* @Descripttion: 未描述
* @Author: Chenbangquan
* @version: 1.0.0
* @CreateDate 2021-06-29 17:09
* @LastEditors: cbq
* @LastEditTime: 2021-06-29
*/
<template>
  <div class="templateHead" :class="scrollTop > topTabsHeight ? 'btns-fixed' : 'tab-no'">
    <el-row v-if="amendStatus">
      <el-col :span="10">
        <div class="contractStatus">
          <span>合同状态：
            <span :class="statusStyle">{{contracDetail.statusName}}</span>
            <!--开启审批并且有审批状态-->
            <!--<span class="smallSpan" v-if="aprocessInfo.auditStatus == 1 && (qsf || fqf)">-->
            <span class="smallSpan" v-if="qsf">
              <span v-if="aprocessInfo.auditStatus == 1">(签署审批状态：<span class="statusTypeSkinA">审批中</span>)</span>
              <span v-if="aprocessInfo.auditStatus == 2">(签署审批状态：<span class="statusTypeSkinB">已通过</span>)</span>
              <span v-if="aprocessInfo.auditStatus == 3">(签署审批状态：<span class="statusTypeSkinD">已拒绝</span>)</span>
            </span>
            <span class="smallSpan" v-if="fqf">
              <span v-if="contracDetail.status == 1">
                <span v-if="aprocessInfo.auditStatus == 1">(发送审批状态：<span class="statusTypeSkinA">审批中</span>)</span>
                <span v-if="aprocessInfo.auditStatus == 2">(发送审批状态：<span class="statusTypeSkinB">已通过</span>)</span>
                <span v-if="aprocessInfo.auditStatus == 3">(发送审批状态：<span class="statusTypeSkinD">已拒绝</span>)</span>
              </span>
              <span v-if="contracDetail.status != 1">
                <span v-if="aprocessInfo.auditStatus == 1">(签署审批状态：<span class="statusTypeSkinA">审批中</span>)</span>
                <span v-if="aprocessInfo.auditStatus == 2">(签署审批状态：<span class="statusTypeSkinB">已通过</span>)</span>
                <span v-if="aprocessInfo.auditStatus == 3">(签署审批状态：<span class="statusTypeSkinD">已拒绝</span>)</span>
              </span>
            </span>
          </span>
          <p v-if="contracDetail.isTaker && contracDetail.signTag == 6 && contracDetail.signStatus == 0">请耐心等待对方查阅并签署合同。</p>
          <p v-if="!contracDetail.isTaker && contracDetail.signTag == 7 && contracDetail.signStatus == 0">合同已拟定，请查阅签署。</p>
          <p v-if="contracDetail.status == 3">合同已签署完成，可以下载合同文档了。</p>
          <p v-if="contracDetail.status == 5">合同已作废失效，如需签署合同，请重新创建新合同。</p>
          <p v-if="contracDetail.status == 4">合同已过期失效，如需签署合同，请重新创建新合同。</p>
          <p v-if="contracDetail.status == 2 && contracDetail.isTaker &&contracDetail.signTag ==7">对方已签署合同，请及时签署合同。</p>
          <p v-if="contracDetail.status == 2 && !contracDetail.isTaker &&contracDetail.signTag ==6">请耐心等待对方查阅并签署合同。</p>
          <p v-if="contracDetail.status == 1">
            最后保存：{{dateFormatType(contracDetail.createTime,2)}}
          </p>
          <p v-if="contracDetail.remark" class="remark">修改意见：{{contracDetail.remark}}</p>
        </div>
      </el-col>
      <!--合同状态 1:拟定中，2：签署中，3：已完成，4：已过期，5，已作废-->
      <!--已作废不显示-->
      <el-col :span="14" style="text-align: right" v-if="status5">
        <div v-if="contracDetail.status == 1 && (aprocessInfo.auditStatus != 1 || aprocessInfo.auditStatus == null)">
          <Button5 style="margin-right: 20px" @click="modelShow('dis')" :loading="loading">退回</Button5>
          <Button5 style="margin-right: 10px" @click="modelShow('clear')" :loading="loading">清空合同</Button5>
          <button4 class="sendBtn ml10" @click="modelShow('sendStatus')" :loading="loading">发送合同</button4>
        </div>
        <!--auditStatus 开启审批，并且审批状态为审核中--><!--procesState 1：开启 0：未开启-->
        <button4 v-if="aprocessInfo.auditStatus == 1" class="sendBtn ml10" @click="goAprocessDetail()" :loading="loading">审批详情</button4>
        <!--待我方签署 -->
        <div v-if="contracDetail.isTaker && contracDetail.signTag == 7">
          <button4 class="sendBtn mr20" v-if="contracDetail.status == 1" @click="modelShow('sendStatus')" :loading="loading">发送合同</button4>
          <!--<el-button class="sendBtn" type="danger" @click="againContract">驳回合同</el-button>-->
          <Button5 class="mr20" plain v-if="(contracDetail.status == 1 || contracDetail.status == 2) && aprocessInfo.auditStatus != 1" @click="modelShow('dis')" :loading="loading">退回</Button5>
          <!--1.0.5-->
          <el-button v-if="xght" class="sendBtn mr10" type="danger" @click="amendContract" :loading="loading">修改合同</el-button>
          <!--1.0.5-->
          <el-button v-if="myAprocess" class="sendBtn" type="primary" @click="modelShow('signCode')" :loading="loading">提交审批</el-button>
          <el-button v-if="qsBtn" class="sendBtn" type="primary" @click="modelShow('signCode')" :loading="loading">签署合同</el-button>
        </div>
        <!--待对方签署 -->
        <div v-if="!contracDetail.isTaker && contracDetail.signTag == 7 && aprocessInfo.auditStatus!=5">
          <!--已开启审批-->
          <!--合同审批状态 审批状态 1 审核中 2 通过 3 不通过-->
          <Button5 v-if="aprocessInfo.auditStatus !== 1" style="margin-right: 20px" @click="modelShow('dis')" :loading="loading">退回</Button5>
          <el-button v-if="xght" class="sendBtn mr10" type="danger" @click="amendContract" :loading="loading">修改合同</el-button>
          <el-button v-if="(aprocessInfo.auditStatus == 2 && aprocessInfo.auditStatus !== null) && procesState == 1"  class="sendBtn" type="primary" @click="modelShow('signCode')" :loading="loading">签署合同</el-button>
          <el-button v-if="myAprocess" class="sendBtn" type="primary" @click="modelShow('signCode')" :loading="loading">提交审批</el-button>
          <!--未开启审批-->
          <!--<el-button v-if="aprocessInfo.auditStatus !== 1 && procesState == 0 && !contracDetail.signed" class="sendBtn mr10" type="danger" @click="amendContract" :loading="loading">修改合同</el-button>-->
          <el-button v-if="(aprocessInfo.auditStatus !== 1 && aprocessInfo.auditStatus !== null) && procesState == 0"  class="sendBtn" type="primary" @click="modelShow('signCode')" :loading="loading">签署合同</el-button>
        </div>
        <div v-if="contracDetail.status == 3">
          <el-button class="sendBtn" type="primary" @click="donwloadHandler">下载</el-button>
        </div>
      </el-col>
    </el-row>
    <el-row v-if="!amendStatus"> <!--开启修改-->
      <el-col :span="10" style="text-align: left"><P>合同修改后，将发送至对方进行确认！</P></el-col>
      <el-col :span="12" style="text-align: right">
        <button7 class="mr20" @click="cancelAmend()">取消</button7>
        <el-button class="sendBtn mr20" type="primary" @click="sendContract('1')" :loading="loading">预览</el-button>
        <el-button class="sendBtn" type="primary" @click="affirmAmend()" :loading="loading">确认修改</el-button>
      </el-col>
    </el-row>
    <el-dialog
            title="修改合同"
            :visible.sync="isVisible"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            width="600px"
            @close="cancelRemark"
            class="codeInput">
      <div style="display: flex;justify-content: left;">
        <div style="width:83px">修改意见：</div>
        <el-input
                type="textarea"
                :autosize="{ minRows: 4, maxRows: 4}"
                placeholder="请输入您对合同修改的意见，以便于合同创建方修改"
                maxlength="100"
                v-model="toast.remark"></el-input>
      </div>
      <span slot="footer" class="dialog-footer" style="text-align: center">
        <button7 @click="cancelRemark"><span style="color: #969696">取 消</span></button7>
        <el-button type="primary" class="ml20" @click="checkStatusByNowStatus" :loading="loading">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog
            :title="`${boxName}合同-审批申请`"
            :visible.sync="showApproveBox"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            width="600px"
            :append-to-body="true"
            @close="cancelRemark"
            class="codeInput">
      <el-form :model="approveForm" label-width="124px" >
        <el-form-item label="申请单位：">
          <span>{{$htgl_user.companyName}}</span>
        </el-form-item>
        <el-form-item label="申请部门：" class="fontColor">
          <el-select v-model="deptmentUser" value-key="name"  class="wd100" @change="changeSelectVal">
            <el-option
                    v-for="(items,indexs) in departmentList"
                    :key="indexs"
                    :label="items.name"
                    :value="items">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="申请人：">
          <span>{{$htgl_user.realName}}</span>
        </el-form-item>
        <el-form-item label="备注：">
          <el-input
                  type="textarea"
                  :autosize="{ minRows: 4, maxRows: 4}"
                  maxlength="100"
                  v-model="approveForm.remark"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer" style="text-align: center">
        <button7 @click="cancelRemark">取 消</button7>
        <el-button type="primary" class="ml20" @click="taskApplyBefor" :loading="loading">立即申请</el-button>
      </span>
    </el-dialog>
    <el-dialog
            title="签署合同安全验证"
            :visible.sync="msgUrlShow"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            :modal="false"
            width="600px">
      <div class="tips">
        <img src="@/assets/gantanhao.png" alt />
        <span>验证通过后将无法修改合同内容。</span>
      </div>
      <el-form :model="ceodeModel">
        <!--`：`-->
        <el-form-item :label="`请输入本人手机（${constractOpenInfo.phone}）获取的验证码：`">
          <el-input class="wd300" v-model="ceodeModel.code"></el-input>
          <button8 style="margin-left: 10px" @click="signa" v-if="show">获取验证码</button8>
        </el-form-item>
      </el-form>
      <p>
        <span v-if="!show">[已发送验证码（{{count}}s)]</span>
      </p>
      <div style="text-align: center;padding: 40px 0">
        <button7 @click="msgUrlShow = false">取 消</button7>
        <el-button style="margin-left: 20px" type="primary" @click="sendShortUrl(ceodeModel.code)" :loading="loading">确认签署</el-button>
      </div>
    </el-dialog>
    <CommonModalTips :isVisible="modelShow1"
                     :title="toast.title"
                     :tipsText="toast.tipsText"
                     :mStatus="toast.mStatus"
                     :appendtTobody="toast.appendtTobody"
                     @close="closeTips">
      <div slot="footer" v-if="type == 'signCode'" style="text-align: center">
        <div><el-button style="width: 200px" type="primary" @click="checkStatusByNowStatus()">签字并盖章</el-button></div>
        <div class="mt20"><el-button style="width: 200px" type="primary" @click="onlySeal()">仅盖章</el-button></div>
      </div>
      <div slot="footer" class="toast" v-if="type !== 'signCode'">
        <button7 v-if="type != 'checkStatus'" class="mr20" :loading="loading" @click="$emit('setStatus', false)">取消</button7>
        <el-button v-if="type == 'dis'" type="primary" @click="checkStatusByNowStatus" :loading="loading">退回</el-button>
        <el-button v-if="type == 'clear'" type="primary" @click="checkStatusByNowStatus" :loading="loading">清空</el-button>
        <!--//退回判断合同状态-->
        <el-button v-if="type == 'checkStatus'" type="primary" @click="$emit('getContactDetail')" :loading="loading">知道了</el-button>
      </div>
    </CommonModalTips>
  </div>
</template>

<script>
	import apiContractTemplate from '@/api/apiContract/apiContract'
	import apiSystem from "@/api/apiSystem/index";
	import * as api from "@/api/apiProcess";

	export default {
		name: "contractHead",
		data(){
			return{
				msgUrlShow:false,
				ceodeModel:{
					code:''
        },
        show:true,
				count: '',
				timer: null,
				boxName:"",//审批弹窗名字
				approveType:"",//审批类型
				deptmentUser:{},//选择部门的数据
				departmentList:null,
				//审批弹窗数据
				approveForm:{
					applyName: this.$htgl_user.realName,
					companyName: this.$htgl_user.companyName,
					companyNo: this.$htgl_user.cno,
					deptName: "",
					deptNo: "",
					id: this.contracDetail.id,
					remark: "",
					type:''
				},
				// loading:false,
				showApproveBox:false, //设置审批弹框
				amendStatus:true, //修改状态
				isVisible:false,
				ByNowStatus:false,
				type:'',
				toast:{
					tipsText:'',
					companyName: this.$htgl_user.companyName,
					companyNo: this.$htgl_user.companyNo,
					id: this.contracDetail.id,
					remark: "",
					appendtTobody:true
				},
				isInit: true,
				btnsIsFixed: true,
				scrollTop: 0,
				topTabsHeight: 0
			}
		},
		props:{
			procesState: {},
			contracDetail:{
				type: Object
			},
      constractOpenInfo:{ //开户信息
				type: Object
			},
			aprocessInfo:{},
			loading:{
				type: Boolean
			},
			watchStatus:{
				type: Boolean
			},
			modelShow1:{
				type: Boolean
			},
		},
		components:{
			CommonModalTips: () => import("@/components/public/CommonModalTips.vue"),
		},
		mounted(){
			window.addEventListener('scroll',this.scrollChange, true)
		},
		computed: {
			// auditStatus 合同审批状态 审批状态 1 审核中 2 通过 3 不通过-->
			// auditStatus 审批状态 1：开启 0：未开启
			xght(){
				//查看公司信息里面是否包含已签字的成员
				let flag = this.contracDetail.involves.some((item)=>{
					return item.signature == '1'
				})
				return this.aprocessInfo.auditStatus != 1 && !this.contracDetail.signed && !flag
			},
			//发起方
			fqf () {
				return this.contracDetail.isTaker && (this.contracDetail.signTag == 6 ||this.contracDetail.signTag == 7 ||this.contracDetail.signTag ==  null)
			},
			//签署方
			qsf () {
				return !this.contracDetail.isTaker && (this.contracDetail.signTag == 6 ||this.contracDetail.signTag == 7 ||this.contracDetail.signTag ==  null)
			},
			//待我方签署显示提交审批
			myAprocess(){
				return this.procesState == 1 && (this.aprocessInfo.auditStatus == 3 || this.aprocessInfo.auditStatus == null)
			},
			qsBtn(){
			  let status=false;
			  if(this.aprocessInfo){
          status=this.aprocessInfo.auditStatus!=5
        }else{
          status=this.contracDetail.status!=5
        }
				return (this.aprocessInfo.auditStatus == 2 || this.procesState == 0) && status
			},
      //作废
      status5(){
        let status=this.aprocessInfo.auditStatus==5||this.contracDetail.status==5;
        return !status;
      },
			// status () {
			// 	switch (this.contracDetail.status) {
			// 		case 1:
			// 			return '拟定中'
			// 		case 2:
			// 			return '签署中'
			// 		case 3:
			// 			return '已完成'
			// 		case 4:
			// 			return '已过期'
			// 		case 5:
			// 			return '已作废'
			// 	}
			// },
			statusStyle () {
				switch (this.contracDetail.status) {
					case 1:
						return 'statusTypeSkinA'
					case 2:
						return 'statusTypeSkinB'
					case 3:
						return 'statusTypeSkinC'
					case 4:
						return 'statusTypeSkinD'
					case 5:
						return 'statusTypeSkinE'
					case 6:
						return 'statusTypeSkinF'
					default:
						return '未知'
				}
			},
		},
		watch:{
			aprocessInfo(n){
				return n
			},
			qsBtn(n){
				return n
			},
			watchStatus(n){
				if(n == 1){
					this.taskApplyAfter()
				}
			}
		},
		created(){
			this.getDepartmentList()
		},
		methods:{
			scrollChange() {
				try {
					this.scrollTop = document.getElementById('app').scrollTop
					this.tagChange(this.isInit);
				} catch (error) {
					console.log("error", error);
				}
			},
			// tag选中改变
			tagChange(isInit) {
				try {
					if (isInit) {
						this.scrollTop = 0;
						window.scrollTo({
							top: 0,
							behavior: "instant"
						});
						this.isInit = false;
						return;
					}
					// 滚动条滚到底的情况
					let clientHeight =
						document.documentElement.clientHeight || document.body.clientHeight;
					let scrollHeight = document.getElementById('app').scrollHeight
					// 滚动条到底部的条件
					if (
						scrollHeight > clientHeight &&
						this.scrollTop + clientHeight >= scrollHeight -100
					) {
						this.btnsIsFixed = false // 按钮取消固定定位
					} else {
						this.btnsIsFixed = true
					}
				} catch (error) {
					console.log("error", error);
				}
			},
			//审批详情
			goAprocessDetail(){
				let obj = {
					id: this.contracDetail.id, //合同id
					auditId: this.aprocessInfo.auditId,//审批id
					approve: 'signContract', //审批类型
					showType: 1
				}
				if(this.contracDetail.isTaker == true && this.contracDetail.signTag == 6){
					obj.approve = 'signContract'
				}
				let url = `/Upcoming?id=${obj.id}&logId=${obj.auditId}&componentKey=signContract&showType=${obj.showType}`
				// this.$router.push(`/contractApprove?id=${this.contracDetail.approvalSendId}`)
				// this.$router.push({path: '/contractApprove', query: obj})
				window.open(url,'_blank')
			},
			/**@name 部门选择的事件 */
			changeSelectVal(e) {
				console.log(e)
				this.approveForm.deptName = e.name;
				this.approveForm.deptNo = e.id;
			},
			//立即申请前
			taskApplyBefor(){
				this.type = 'procesState'
				this.checkStatusByNowStatus()
			},
			//审批状态
			async checkApproveStatus(){
				let obj = {
					id: this.contracDetail.id,
					type: 'signContract'
					// type: this.approveType
				}
				let res = await apiContractTemplate.getfindAuditStatus(obj)
				if(res.data.code == 200){
					if(this.procesState == 1 && (this.aprocessInfo.auditStatus !== res.data.data.auditStatus)){
						this.toast.tipsText = '当前合同审核状态已发生变更，请重新加载页面！'
						this.toast.title = '提示'
						this.toast.mStatus = 'warning'
						this.type = 'checkStatus' //按钮知道了 显示状态
						this.$emit('setStatus',true)
						// this.modelShow1 = true
						this.showApproveBox = false
					}else {
						//立即申请之前先调发送合同
						if(this.approveType == 'sendContract'){
							this.sendContract('2')
							return
						}
						if(this.type == 'signCode'){
							this.$emit('signCode')
							return
						}
						if(this.type == 'dis'){
							this.DiscardContract() // 退回
							return
						}
						if(this.type == 'amend' || this.type == 'affirm'){
							this.checkStatusByNowStatus()
							return
						}
						this.taskApplyAfter()
					}
				}
			},
			//立即申请后
			async taskApplyAfter(){
				this.$emit('setLoading', true) //setLoading
				this.approveForm.id = this.contracDetail.id
				this.approveForm.type = this.approveType
				let res = await apiContractTemplate.postSendContractApproval(this.approveForm)
				if(res.data.code == 200) {
					this.$message({
						message: '已提交，请等待上级审批！',
						type: 'success'
					})
					this.$emit('getContactDetail')
					this.showApproveBox = false
					this.$emit('setLoading', false) //setLoading
					this.$emit('setStatus', false)
				}else {
					this.$message({
						message: res.data.msg,
						type: 'warning'
					})
				}
				this.$emit('setStatus', false)
				this.$emit('setLoading', false) //setLoading
				console.log(res)
			},
			// 获取部门数据
			getDepartmentList() {
				let params = {
					parentId: 1,
					companyNo: this.$htgl_user.companyNo,
					userNo: this.$htgl_user.no
				};
				apiSystem.getOrganizationDepByUserAndParentId(params).then(res => {
					if (res.data.code === 200) {
						this.departmentList = res.data.data;
					}
				});
			},
			closeTips(){
				if(this.type == 'checkStatus'){
					this.modelShow1 = false
					return
				}
				if(this.type == 'signCode'){
					this.modelShow1 = false
					return
				}
				if(!this.contracDetail.isTaker){ //如果是参与方 返回列表
					this.$removeTag('/contractList')
					return
				}
				this.$emit('setStatus', false)
			},
			/*仅盖章*/
			onlySeal(){
				this.$set(this.contracDetail,'signatureFlag',false)
				this.checkStatusByNowStatus()
				// this.$emit('signCode')
			},
			/*校验是否可签字*/
			async checkSignature(){
				let res = await apiContractTemplate.postCheckSignature(this.$route.query.no)
				this.$set(this.contracDetail,'signatureFlag',res.data.data)
				if(res.data.code == 200 && res.data.data){
					// this.type = 'signatureFlag'
					this.toast.title = '请选择合同签署方式'
					this.toast.mStatus = '1'
					this.modelShow1 = true
					return
				}
				this.$emit('signCode')
			},
			//判断合同状态
			async checkStatusByNowStatus(){
				let obj = {
					No: this.$route.query.no,
					status: this.contracDetail.status
				}
				let res = await apiContractTemplate.getContracStatusStatus(obj)
				console.log(res)
				console.log(this.type)
				if(res.data.data){
					if(this.type == 'dis'){ //退回
						this.checkApproveStatus()
					}if(this.type == 'clear'){ //清空
						this.clearContract()
					}if(this.type == 'sendStatus'){
						this.sendContract('2')
					}if(this.type == 'agin'){ //驳回
						this.refuseRs()
					}if(this.type == 'signCode'){ // 签署合同
						this.checkApproveStatus()
					}if(this.type == 'procesState'){ // 立即审批 发起申请检查审批状态
						this.checkApproveStatus()
					}if(this.type == 'amend'){ //修改合同
						this.amendStatus = false
						this.$emit('setAmendStatus',this.amendStatus)
					}if(this.type == 'affirm'){ //确认修改合同
						this.amendStatus = true
						this.sendContract('affirm')
					}
				}else {
					this.toast.tipsText = res.data.msg
					// if(this.type == 'signCode'){ // 签署合同
					//   this.toast.tipsText = '当前合同已被驳回将返回合同列表！'
					// }
					this.ByNowStatus = res.data.data
					this.toast.title = '提示'
					this.toast.mStatus = 'warning'
					this.type = 'checkStatus' //按钮知道了 显示状态
					this.modelShow1 = true
				}
			},
			cancelRemark(){
				this.isVisible = false
				this.toast.remark = ''
				//重置审批弹窗
				this.deptmentUser = {}
				this.showApproveBox = false
				this.loading = false
				this.approveForm.remark = ''
			},
			async signa(){
				let data = {contractNo: this.$route.query.no}
				// 获取验证码
				let res = await apiContractTemplate.getSendCode(data)
				if (res.data.code == 200) {
					this.show = false
					this.$message({
						message: '验证码发送成功',
						type: 'success'
					})
					this.getCode()
				} else {
					this.$message.error(res.data.msg)
				}
			},
			// 获取验证码
			getCode () {
				const TIME_COUNT = 60
				if (!this.timer) {
					this.count = TIME_COUNT
					this.show = false
					this.timer = setInterval(() => {
						if (this.count > 0 && this.count <= TIME_COUNT) {
							this.count--
						} else {
							this.show = true
							clearInterval(this.timer)
							this.timer = null
						}
					}, 1000)
				}
			},
      async sendMsg(){ //个人发送签署短链接
	      if(this.contracDetail.contractNum){ // 安心签编号
          this.sendShortUrl()
          return
	      }
	      // this.signa()
        this.msgUrlShow = true
      },
      async sendShortUrl(code){
	      if (!this.contracDetail.contractNum && !this.ceodeModel.code) {
		      this.$message({
			      type: 'error',
			      message: '验证码不能为空'
		      })
		      return
	      }
	      let data = {
		      contractNo: this.$route.query.no,
		      code: code
	      }
	      let res = await apiContractTemplate.postpersonalSubmitSign(data)
        console.log(res)
	      this.$confirm(res.data.msg, '提示信息 ', {
		      confirmButtonText: '知道了',
		      showCancelButton: false,
		      type: res.data.code == 200 ? 'success': 'warning',
	      }).then((res)=>{
	        this.msgUrlShow = false
          this.$emit('getContactDetail')
	      }).catch(() => {
          this.msgUrlShow = false
          this.$emit('getContactDetail')
	      });
      },
			donwloadHandler(row) {
				window.open(`${this.contracDetail.url}`, "_blank");
			},
			async modelShow(val){
				this.type = val
				//获取合同是否开启审批
				let obj = {
					companyId: this.$htgl_user.cno + "",
					type: 'signContract'
				}
				let res = await api.queryProcessByType(obj)
				//实时监测审批开启状态
				if(res.data.data && res.data.data != null && res.data.data.rootNode.switchOn == 1){
					this.$emit('setprocesState',res.data.data.rootNode.switchOn)
				}else {
					this.$emit('setprocesState','0')
				}
				// this.procesState = res.data.data
				//合同是否开启审批1：开启 0：未开启
				//合同审批状态 审批状态 1 审核中 2 通过 3 不通过
				if(val== 'signCode'){ // 签署合同
					this.boxName = '签署'
					this.approveType = 'signContract'
						//<!--type：1企业   0个人 v-if="$htgl_user.type == 1"-->
					if(res.data.data && res.data.data != null && res.data.data.rootNode.switchOn == 1 && this.aprocessInfo.auditStatus !=2 && this.$htgl_user.type == 1 ){
						this.showApproveBox = true
						return
					}
					if(this.$htgl_user.type == 0){ // 个人直接发送短信
						this.sendMsg()
						return
          }
					this.checkSignature()
				}
				if(val == 'dis'){
					this.toast.title = '退回提示'
					this.toast.mStatus = 'warning'
					this.toast.tipsText = '退回合同后不可恢复，还要继续吗？'
					this.$emit('setStatus', true) //modelShow1
				}
				if(val == 'clear'){
					this.toast.title = '清空提示'
					this.toast.mStatus = 'warning'
					this.toast.tipsText = '清空合同后不可恢复，还要继续吗？'
					this.$emit('setStatus', true) //modelShow1
				}
				if(val == 'sendStatus'){
					// this.boxName = '发送'
					// this.approveType = 'sendContract'
					// if(res.data.data && res.data.data != null && res.data.data.rootNode.switchOn == 1 && this.contracDetail.auditStatus !=2 ){
					//   this.showApproveBox = true
					//   return
					// }
					this.checkStatusByNowStatus()
				}
			},
			// 驳回
			async againContract () {
				this.type = 'agin'
				this.isVisible = true
			},
			/*修改合同*/
			amendContract(){
				this.type = 'amend'
				this.checkApproveStatus()
			},
			/*取消修改合同*/
			cancelAmend(){
				this.amendStatus = true
				this.$emit('getContactDetail')
			},
			/*确认修改合同*/
			affirmAmend(){
				this.type = 'affirm'
				this.contracDetail.status = 2
				this.checkApproveStatus()
			},
			// 驳回
			async refuseRs (){
				this.$emit('setLoading', true) //setLoading
				this.toast.id = this.contracDetail.id
				let res = await  apiContractTemplate.postRejectContrac(this.toast)
				if(res.data.code == 200){
					this.$message({
						message: '操作成功！',
						type: 'success'
					})
					this.$removeTag('/contractList')
					this.$emit('setLoading', false) //setLoading
				}else {
					this.$emit('setLoading', false) //setLoading
				}
			},
			// 废除合同
			async DiscardContract(){
				this.$emit('sendContract','3')
			},
			//清空合同
			clearContract(){
				// this.$emit('setStatus', false) //modelShow1
				this.$emit('clearContract',false)
			},
			// //签署合同
			async sendContract(val){
				// if(!this.contracDetail.isTaker){ //如果是参与方 返回列表
				//   this.$removeTag('/contractList')
				//   return
				// }
				this.$emit('sendContract',val)
			}
		},
		beforeDestroy() {
			window.removeEventListener("scroll", this.scrollChange, true);
		},
	}
</script>
<style scoped>
  >>> .templateHead .el-dialog__body{
    /*padding: 0px;*/
    border-top: none !important;
  }
  >>> .codeInput .el-form-item__content{
    /*padding: 0px;*/
    text-align: left;
  }
  >>> .codeInput .el-form-item__label{
    font-weight: 400;
    color: #606266;
  }
  >>> .codeInput .el-dialog__body{
    padding: 20px;
    border-top: none !important;
  }
  >>> .codeInput .el-dialog__footer{
    text-align: center;
    padding: 20px 0 40px 0;
    border-top: none !important;
  }
  >>> .codeInput .el-dialog__header{
    text-align: left;
  }
  >>> .codeInput .el-dialog__body .el-textarea .el-textarea__inner{
    border: 1px solid #e4e7ed;
    padding: 0 10px;
  }
  >>> .codeInput .el-form-item{
    margin-bottom: 10px;
  }
  >>> .codeInput .el-form-item__label{
    color: #000000;
    font-size: 14px;
  }
</style>
<style scoped lang="scss">
  .statusTypeSkinA{
    color: #F7AB01 !important;
  }
  .statusTypeSkinB{
    color: #0286DF !important;
  }
  .statusTypeSkinC{
    color: #78C06E !important;
  }
  .statusTypeSkinD{
    color: red !important;
  }
  .statusTypeSkinE{
    color: #FF6600 !important;
  }
  .statusTypeSkinF{
    color: #78C06E !important;
  }
  .contractStatus{
    text-align: left;
    .smallSpan{
      margin-left: 50px;
      font-size: 12px;
      .statusTypeSkinD{
        color: red !important;
      }
      .statusTypeSkinB{
        color: #0286DF !important;
      }
      .statusTypeSkinA{
        color: #F7AB01 !important;
      }
    }
    .remark{
      color: #FF6600;
    }
  }
  .templateHead{
    background-color: #FFFFFF;
    /*text-align: center;*/
    border-bottom: 1px solid #e4e7ed;
    padding: 10px 20px;
    position: relative;
    /*span{*/
    /*color: #000000;*/
    /*font-size: 18px;*/
    /*font-weight: bold;*/
    /*}*/
    p{
      margin-top: 12px;
      font-size: 12px;
      color: #969696;
    }
    .sendBtn{
      /*position: absolute;*/
      /*right: 20px;*/
      /*top: 20px;*/
    }
  }
  .toast {
    text-align: center;
    button {
      width: 76px;
      /*padding: 0 21px;*/
      height: 40px;
    }
  }
  .btns-fixed {
    width: 1200px;
    position: fixed;
    top: 0;
    z-index: 99;
  }
  .tips{
    height: 40px;
    line-height: 40px;
    background-color: #FDF6EC;
    padding:  0 20px 0 40px;
    margin: 30px 0  10px 0;
    position: relative;
    img {
      position: absolute;
      left: 20px;
      top: 13px;
      width: 14px;
      height: 14px;
      margin-right: 10px;
    }
    span{
      color: #E6A23C;
      font-size: 14px;
      text-align: left;
    }
  }
</style>
<style scoped>
  >>> .codeInput .el-form-item__label{
    font-weight: 400;
    color: #606266;
  }
  >>> .codeInput .el-dialog__body{
    padding: 0 20px;
    /*border-top: 1px solid #e4e7ed;*/
  }
  >>> .codeInput .el-form-item{
    margin-bottom: 10px;
  }
  >>> .codeInput .el-form-item__label{
    color: #000000;
    font-size: 14px;
  }
</style>

