<template>
  <div class="container-table">
    <el-table
      ref="multipleTable"
      v-loading="loading"
      :data="data"
      :highlight-current-row="highlightCurrentRow"
      :border="border"
      :stripe="stripe"
      :show-overflow-tooltip="showOverflowTooltip"
      :size="size"
      :empty-text="empty"
      :align="align"
      @selection-change="selectionChange"
      @select="select"
      @row-click="choseRows"
      @current-change="handleCurrentChange"
    >
      <template slot="empty">
        <base-empty-data />
      </template>
      <el-table-column
        v-if="isShowIndex"
        label="序号"
        type="index"
        width="50"
      >
      </el-table-column>
      <el-table-column
        v-for="(column, index) in columns"
        :key="column.prop + index"
        :prop="column.prop"
        :label="column.label"
        :width="column.width"
        :min-width="column.minWidth"
        :fixed="column.fixed"
        :sortable="column.sortable === undefined ? false : true"
        :show-overflow-tooltip="isLineRow"
        cell-style="font-size: 18px"
      >
        <template slot-scope="scope">
          <slot :column="column" :scope="scope" />
          <span class="col-style" v-if="!column.isHandler">{{ scope.row[column.prop] }}</span>
          <template v-else-if="column.isHandler">
            <span
              v-for="(hand, index) in column.handList"
              :key="index"
              @click.stop="choice(hand, scope.row, column)"
            >
              <span
                class="hand-default"
                :class="hand.class"
                v-if="hand.default"
              >
                {{ hand.label }}
              </span>
              <span
                class="hand-default"
                :class="hand.class"
                v-if="!hand.default && hand.value === scope.row[column.statusField]"
              >
                {{ hand.label }}
              </span>
            </span>
          </template>
        </template>
      </el-table-column>
    </el-table>
    <div v-if="showPagenation && pagenationData.total > 0" class="toolbar">
      <el-pagination
        background
        layout="prev, pager, next"
        :current-page="pagenationData.page"
        :page-size="pagenationData.limit"
        :total="pagenationData.total"
        @current-change="refreshPageRequest"
      >
      </el-pagination>
      <!-- <el-pagination
        :current-page="pagenationData.page"
        :page-sizes="[10, 20, 30, 40]"
        :page-size="pagenationData.limit"
        layout="total, sizes, prev, pager, next, jumper"
        :total="pagenationData.total"
        @size-change="sizeChange"
        @next-click="refreshPageRequest"
      /> -->
    </div>
  </div>
</template>

<script>
// import transportOrderVue form '../../../../LogisticsTransportation/goodsManage/transportOrder.vue';
export default {
  name: 'operTable',
  props: {
    columns: { // 表头配置
      type: Array,
      default: () => ([])
    },
    data: { // 列表数据
      type: Array,
      default: () => ([])
    },
    pagenationData: { // 分页初始化数据
      type: Object,
      default: () => ({ page: 1, limit: 10, total: 0 })
    },
    empty: { // 无数据样式
      type: String,
      default: "暂无数据",
    },
    size: { // 尺寸样式
      type: String,
      default: "small",
    },
    fixed: { // 尺寸样式
      type: String,
      default: "",
    },
    align: { // 对齐方式
      type: String,
      default: "left",
    },
    isLineRow: { // 是否自适应内容撑开列
      type: Boolean,
      default: true,
    },
    showOverflowTooltip: {// 是否单行显示
      type: Boolean,
      default: true,
    },
    maxHeight: { // 表格最大高度
      type: [Number, String],
      default: 546,
    },
    border: { // 是否显示边框
      type: Boolean,
      default: true,
    },
    stripe: {// 是否显示斑马线
      type: Boolean,
      default: true,
    },
    loading: { // 加载标识
      type: Boolean,
      default: false,
    },
    isShowIndex: {
      type: Boolean,
      default: false,
    },
    highlightCurrentRow: { // 是否高亮当前行
      type: Boolean,
      default: true,
    },
    showCheckbox: {// 是否显示操作组件
      type: Boolean,
      default: true,
    },
    showPagenation: { // 分页显示隐藏
      type: Boolean,
      default: true,
    },
    showChoseRows: { // 点击当行是否进行选中操作
      type: Boolean,
      default: true,
    }
  },
  data() {
    return {
      pageRequest: {}
    }
  },
  created() {},
  mounted() {
    console.log(this.data, 'data-----');
    console.log(this.columns, 'columns-----');
  },
  methods: {
    // 点击操作按钮相关
    choice(item, row, col) {
      this.$emit("choice", { item, row, col })
    },
    // 选择切换
    handleCurrentChange: function (val) {
      this.$emit("handleCurrentChange", { val: val })
    },
    choseRows(row, val) {
      if (row.isExistLaunchArea && row.isExistLaunchArea) {
        return false;
      }
      if (this.showChoseRows) {
        this.$refs.multipleTable.toggleRowSelection(row)
      }
      this.$emit("choseRow", row)
    },
    // 当用户手动勾选数据行的 Checkbox 时触发的事件
    select(selection, row) {
      this.$emit("select", row)
    },
    // 选择切换
    selectionChange(selections) {
      this.selections = selections;
      this.$emit("selectionChange", { selections: selections })
    },
    // 分页改变触发
    refreshPageRequest(page) {
      console.log(page,'page---');
      let loading = this.$loading({
        target: ".table-loading",
        lock: true,
      });
      this.pageRequest = {...this.pagenationData, page}
      this.findPage()
      loading.close()
    },
    // 分页查询
    findPage() {
      this.$emit("findPage", { pageRequest: this.pageRequest })
    },
  }
};
</script>

<style lang="scss" scoped>
.container-table {
  height: 100%;
  display: flex;
  flex-direction: column;
  flex: 1;
  justify-content: space-between;
  /deep/.el-table th > .cell {
    color: #333;
    font-size: 14px;
  }
  .toolbar {
    display: flex;
    justify-content: center;
  }
  .col-style {
    color: #666;
    font-size: 14px;
  }
  .hand-default {
    cursor: pointer;
    font-size: 14px;
  }
  .active-read {
    color: #0286DF;
  }
}
</style>

