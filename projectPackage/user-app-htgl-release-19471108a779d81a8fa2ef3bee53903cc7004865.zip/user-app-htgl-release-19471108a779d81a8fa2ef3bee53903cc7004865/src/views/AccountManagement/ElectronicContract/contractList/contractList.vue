<template>
  <div class='contract-list'>
    <div class='page-header'>合同列表</div>
    <el-form
            :inline="true"
            :model="form"
            ref="form"
            class='inline-form'
    >
      <el-form-item label="合同编号" prop="no">
        <el-input
                placeholder="请输入合同编号"
                v-model="form.no"
                maxlength="32"
                clearable
        ></el-input>
      </el-form-item>
      <el-form-item label="订单编号" prop="orderNo">
        <el-input
                placeholder="请输入订单编号"
                v-model="form.orderNo"
                maxlength="32"
                clearable
        ></el-input>
      </el-form-item>
      <el-form-item label="合同名称" prop="title">
        <el-input
                placeholder="请输入合同名称"
                v-model="form.title"
                maxlength="32"
                clearable
        ></el-input>
      </el-form-item>
      <el-form-item label="合同分类" prop="type">
        <el-select
                v-model="form.type"
                placeholder="请选择"
                clearable
        >
          <el-option
                  v-for="item in types"
                  :key="item.key"
                  :label="item.value"
                  :value="item.key"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item :label="`${item.contractPosition}方名称`" v-for='(item, index) in involves' :key='index'>
        <el-input
                :placeholder="`请输入${item.contractPosition}方名称`"
                v-model="involves[index].companyName"
                maxlength="32"
                clearable
        ></el-input>
      </el-form-item>
      <el-form-item label="合同状态" prop="status">
        <el-select
                v-model="form.status"
                placeholder="请选择"
                clearable
        >
          <el-option
                  v-for="item in statuses"
                  :key="item.key"
                  :label="item.value"
                  :value="item.key"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="审批状态" prop="auditStatus" v-if="$htgl_user.type == 1">
        <el-select
                v-model="form.auditStatus"
                placeholder="请选择"
                clearable
        >
          <el-option
                  v-for="item in processtatuses"
                  :key="item.key"
                  :label="item.value"
                  :value="item.key"
          ></el-option>
        </el-select>
      </el-form-item>
      <!--<el-form-item label="创建时间" class='cjsj'>-->
      <!--<el-date-picker-->
      <!--v-model="times"-->
      <!--type="daterange"-->
      <!--range-separator="~"-->
      <!--value-format="timestamp"-->
      <!--start-placeholder="开始日期"-->
      <!--end-placeholder="结束日期"-->
      <!--clearable-->
      <!--&gt;-->
      <!--</el-date-picker>-->
      <!--</el-form-item>-->
      <el-form-item class="MyContractList">
        <el-button type="primary" @click="searchTable">查询</el-button>
        <el-button style="margin-left: 10px" @click="reset">重置</el-button>
        <el-button v-if="$htgl_user.type == 1" style="margin-left: 10px" @click="handleCommand('signContract')">审批配置</el-button>
        <!--<el-dropdown @command="handleCommand" class="MyContractList-dropdown">-->
        <!--<span class="el-dropdown-link">-->
        <!--审批配置<i class="el-icon-arrow-down el-icon&#45;&#45;right"></i>-->
        <!--</span>-->
        <!--<el-dropdown-menu slot="dropdown" >-->
        <!--<el-dropdown-item command="sendContract">发送审批</el-dropdown-item>-->
        <!--<el-dropdown-item command="signContract">签署审批</el-dropdown-item>-->
        <!--</el-dropdown-menu>-->
        <!--</el-dropdown>-->
      </el-form-item>
    </el-form>
    <div class='table-wrap'>
      <el-table
              :data="tableData"
              tooltip-effect="dark"
              border
              :header-cell-style="setColumnDataColor"
              :cell-style="setCellStyle"
              empty-text=""
              v-loading="loading"
      >
        <template slot="empty">
          <base-empty-data />
        </template>
        <!--<el-table-column-->
        <!--type="index"-->
        <!--label="序号"-->
        <!--width="60"-->
        <!--&gt;-->
        <!--</el-table-column>-->

        <el-table-column
                prop="title"
                label="合同名称"
                show-overflow-tooltip
                width="182">
          <template slot-scope="scope">
            {{scope.row.title ? scope.row.title : '/'}}
          </template>
        </el-table-column>
        <!-- 多方表头 -->
        <el-table-column
                v-for='(item, index) in partsHeader'
                :key='item.label'
                :label="item.label"
                width="225"
                show-overflow-tooltip
        >
          <template slot-scope="scope">
            {{scope.row.involves[index] ? `${scope.row.involves[index].isTaker ? '【发起方】': "" }` + `${scope.row.involves[index].role == 1 ? scope.row.involves[index].companyName : scope.row.involves[index].name}` : '/'}}
            <!--{{scope.row.involves[index] ? `${scope.row.involves[index].isTaker ? '【发起方】': "" }` + scope.row.involves[index].companyName : '/'}}-->
          </template>
        </el-table-column>
        <el-table-column
                prop="no"
                label="合同编号"
                show-overflow-tooltip
                width="200">
        </el-table-column>
        <el-table-column
                prop="orderNos"
                label="订单编号"
                show-overflow-tooltip
                width="195">
          <template slot-scope="scope">
          <span v-for='(item, val) in scope.row.orderNos' :key='item'>
            {{item}}
            <span v-if="val < scope.row.orderNos.length -1">,</span><!--去除最后一个逗号-->
          </span>
          </template>
        </el-table-column>
        <el-table-column
                prop="type"
                label="合同分类"
                width="130"
        >
          <template slot-scope="scope">
            <!--{{getType(scope.row.type)}}-->
            {{scope.row.typeName}}
          </template>
        </el-table-column>
        <el-table-column
                prop="status"
                label="合同状态"
                width="120">
          <template slot-scope="scope">
            <p :class='`contract-status-${scope.row.status}`'>
              {{scope.row.statusName}}
            </p>
          </template>
        </el-table-column>
        <el-table-column
                v-if="$htgl_user.type == 1"
                prop="status"
                label="审批状态"
                width="120">
          <template slot-scope="scope">
            <span :class='`contract-status-${scope.row.auditStatus}`' v-if="scope.row.auditStatus == 1">审批中</span>
            <span :class='`contract-status-${scope.row.auditStatus}`' v-else-if="scope.row.auditStatus == 2">已通过</span>
            <span :class='`contract-status-${scope.row.auditStatus}`' v-else-if="scope.row.auditStatus == 3">已拒绝</span>
            <span v-else>/</span>
          </template>
        </el-table-column>
        <el-table-column
                prop="deadline"
                label="签署截止时间"
                width="176">
          <template slot-scope="scope">
            {{ scope.row.deadline ? scope.row.deadline : '/' }}
          </template>
        </el-table-column>
        <!--<el-table-column-->
        <!--prop="createTime"-->
        <!--label="创建时间"-->
        <!--width="179">-->
        <!--</el-table-column>-->
        <el-table-column
                fixed="right"
                label="操作"
                width="260">
          <template slot-scope="scope">
            <!--合同状态 1:拟定中，2：签署中，3：已完成，4：已过期，5，已作废-->
            <!--合同审批状态 审批状态 1 审核中 2 通过 3 不通过-->
            <el-button type="text" @click='toDetail(scope.row)' v-if='scope.row.status !== 1'>查看合同</el-button>
            <el-button type="text" @click='toDetail(scope.row)' v-if='scope.row.status === 2 && scope.row.signTag == 7' class='cff6'>退回</el-button>
            <el-button type="text" @click='toDetail(scope.row)' v-if='scope.row.status === 2 && scope.row.signTag == 7 && !scope.row.signed' class='cff6'>修改合同</el-button>
            <el-button type="text" @click='toDetail(scope.row)' v-if='scope.row.status === 2 && scope.row.signTag == 7'>立即签署</el-button>
            <!--<el-button type="text" @click='toDetail(scope.row)' v-if='tjsp(scope.row)'>提交审批</el-button>-->
            <el-button type="text" @click='edit(scope.row)' v-if='scope.row.status === 1 && scope.row.isTaker'>编辑合同</el-button>
            <!--<el-button type="text" @click='toDetail(scope.row)' v-if='scope.row.status === 3'>查看合同</el-button>-->
            <span v-if='scope.row.status === 1 && !scope.row.isTaker'>/</span>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
              class='mt20'
              style="text-align: center"
              v-if='total > 0'
              @current-change="handleCurrentChange"
              :current-page.sync="params.page"
              :page-size="params.limit"
              layout="prev, pager, next, jumper"
              :total="total"
      ></el-pagination>
    </div>
    <CommonModalTips :isVisible="modelShow"
                     :title="toast.title"
                     :tipsText="toast.tips"
                     :mStatus="toast.mStatus"
                     @close="search">
      <div slot="footer" class="toast">
        <el-button type="primary" @click="search">知道了</el-button>
      </div>
    </CommonModalTips>
  </div>
</template>

<script>
import {setColumnDataColor, setCellStyle,} from '@/components/table/style'
import apiContract from '@/api/apiContract/apiContract'
import * as api from "@/api/apiProcess";
import dayjs from 'dayjs';
const contractUrl = process.env.VUE_APP_CONTRACT
export default {
  data() {
    return {
      form: {
        no: '', // 合同编号
        orderNo: '', // 订单编号
        title: '', // 合同名称
        type: '', // 合同分类
        status: '', // 1:拟定中，2：签署中，3：已过期，5，已作废，6：已完成
	      auditStatus: '' // 审批状态 1 审核中 2 通过 3 不通过
      },
      involves: [
        { companyName: '', contractPosition: '甲'},
        { companyName: '', contractPosition: '乙'}
      ],
      times: [],
      statuses: [],
	    OpenAccountStatus:'', // 是否开户,
	    processtatuses:[
        {key: '',value: '请选择'},
        {key: 1,value: '审批中'},
        {key: 2,value: '已通过'},
        {key: 3,value: '已拒绝'},
      ],
      types: [],
      tableData: [],
      loading: false,
	    modelShow: false,//显示弹框
	    toast: { //弹框内容
		    tips: '',
		    mStatus: 'warning',
		    title: ''
	    },
      total: 1, // 总数
      maxPart: 2, // 默认两方 甲乙
      params: {

        limit: 20,
        page: 1,
      },
    }
  },
  watch:{
	  ckContract(n){
	  	return n
    }
  },
  computed: {
	  //合同审批状态 审批状态 1 审核中 2 通过 3 不通过-->
	  auditStatus(){ // 修改合同， 退回
  		return (val)=>{
  			return val.signTag == 7 && val.status == 2 && (val.auditStatus == null || val.auditStatus != 1)
      }
    },
    ljqs(){ // 立即签署
  		return (val)=>{
  			return val.signTag == 7 && val.status == 2 &&  val.auditStatus  == 2
      }
    },
    tjsp(){ // 提交审批
  		return (val)=>{
  			return val.signTag == 7 && val.status == 2 &&  val.auditStatus  == 3
      }
    },
    ckht(){ // 查看合同
  		return (val)=>{
  			return val.status != 1 && (val.auditStatus == null || val.auditStatus  == 1)
      }
    },
    setColumnDataColor() {
      return setColumnDataColor;
    },
    setCellStyle() {
      return setCellStyle;
    },
    comNo() {
      return this.$htgl_user.cno;
    },
    partsHeader() {
      let Header = [];
      switch(this.maxPart) {
        case 2:
          Header = [
            {label: '甲方名称', width: ''},
            {label: '乙方名称', width: ''}
          ]
          return Header
        case 3:
          Header = [
            {label: '甲方名称', width: ''},
            {label: '乙方名称', width: ''},
            {label: '丙方名称', width: ''}
          ]
          return Header
        case 4:
          Header = [
            {label: '甲方名称', width: ''},
            {label: '乙方名称', width: ''},
            {label: '丙方名称', width: ''},
            {label: '丁方名称', width: ''}
          ]
          return Header
        case 5:
          Header = [
            {label: '甲方名称', width: ''},
            {label: '乙方名称', width: ''},
            {label: '丙方名称', width: ''},
            {label: '丁方名称', width: ''},
            {label: '戊方名称', width: ''}
          ]
          return Header
        case 6:
          Header = [
            {label: '甲方名称', width: ''},
            {label: '乙方名称', width: ''},
            {label: '丙方名称', width: ''},
            {label: '丁方名称', width: ''},
            {label: '戊方名称', width: ''},
            {label: '己方名称', width: ''}
          ]
          return Header
        default:
          Header = [
            {label: '甲方名称', width: ''},
            {label: '乙方名称', width: ''}
          ]
          return Header
      }
    }
  },
  mounted() {
    this.search();
    this.getStatus();
    this.getIsOpenAccount();
  },
  methods: {
	  // -------------------是否开户
	  async getIsOpenAccount() {
		  let { data } = await apiContract.getOpenAccountMsg(this.$htgl_user.no);
		  if(data.data.status == 0){
			  this.$confirm('开通在线合同签约账户，即可使用在线合同签约', '提示', {
				  confirmButtonText: '马上开通',
				  cancelButtonText: '取消',
				  type: 'warning',
			  }).then(()=>{
				  this.$router.push('/ElectronicContract')
			  }).catch(() => {
				  this.$router.push('/')
			  });
		  }
		  this.OpenAccountStatus = data.data.status
		  console.log(data)
		  console.log(this.$htgl_user)
	  },
  	//审批
	  async handleCommand (command) {
		  let name = '签署审批'
		  if (command == 'sendContract') {
			  name = '发送审批'
		  }
		  // if (!this.$store.state.loginUserInfo.isAdministrators) {
			//   // 无权限
			//   let isFlg = false
			//   const param = {
			// 	  companyId: this.$htgl_user.cno + "",
			// 	  type: command
			//   };
			//   const { data } = await api.queryProcessByType(param);
			//   if (data.data) {
			// 	  const content = JSON.parse(data.data.content);
			// 	  console.log(content.switchOn, 'content.switchOn');
			// 	  isFlg = content.switchOn != 0
			//   }
			//   if (!isFlg) {
			// 	  this.$_delConfirm({
			// 		  title: "提示", //标题
			// 		  msg: '审批未配置，请联系管理员配置审批流程。',
			// 		  // callback: null, //回调函数
			// 		  confirmBtnText: "知道了",
			// 		  showCancelBtn: false,//是否显示取消按钮
			// 		  // showConfirmBtn: true,//是否显示确认按钮
			// 	  })
			//   } else {
			// 	  this.$_delConfirm({
			// 		  title: "提示", //标题
			// 		  msg: '您没有权限，请联系管理员开通',
			// 		  // callback: null, //回调函数
			// 		  confirmBtnText: "知道了",
			// 		  showCancelBtn: false,//是否显示取消按钮
			// 		  // showConfirmBtn: true,//是否显示确认按钮
			// 	  })
			//   }
			//   return
		  // }
		  this.$router.push({ path: "/processDesign", query: { type: command, name: name } });
	  },
    // 分页
    handleCurrentChange(val) {
      this.params.page = val;
      this.search();
    },
	  searchTable(){
	  	this.params.page = 1
      this.search()
    },
    async search() {
      this.loading = true;
      this.modelShow = false;
      let parts = this.involves.filter(item => {
          if (item.companyName) {
            return item
          }
        })
      let payload = {
        involves: parts.length ? parts : undefined,
        createTimeBegin: this.times[0] ? dayjs(this.times[0]).format("YYYY-MM-DD") : undefined,
        createTimeEnd: this.times[1] ? dayjs(this.times[1]).format("YYYY-MM-DD") : undefined,
        ...this.form,
        companyNo: this.comNo,
        ...this.params
      }
      let data = await apiContract.search(payload);
      this.loading = false;
      this.maxPart = Math.max(data.data.data.list.map(item => {
        return item.involves.length;
      }))
      this.tableData = data.data.data.list;
      this.total = data.data.data.totalRow;
	    console.log(this.tableData)
    },
    reset() {
	    this.params.page = 1
      this.$refs.form.resetFields();
      this.times = [];
      this.involves = [
        { companyName: '', contractPosition: '甲'},
        { companyName: '', contractPosition: '乙'}
      ];
      this.search();
    },
    async toDetail(row) {
	    let obj = {
		    No: row.no,
		    status: row.status
	    }
	    let  res = await apiContract.getContracStatusStatus(obj)
	    if(!res.data.data){
		    this.toast.title = '提示'
		    this.toast.mStatus = 'warning'
		    this.toast.tips = '当前合同状态已发生变更请重新加载页面！'
		    this.modelShow = true
		    return
	    }
      // this.$router.push({
      //   path: `/contractTemplate`,
      //   query: {
      //     id: row.id,
      //     no: row.no,
      //     status: 'detail'
      //   }
      // });
	    let url = `/contractTemplate?id=${row.id}&no=${row.no}&status=detail`
      window.open(url, "_blank");
    },
    async edit(row) {
	    let obj = {
		    No: row.no,
		    status: row.status
	    }
	    let  res = await apiContract.getContracStatusStatus(obj)
	    if(!res.data.data){
		    this.toast.title = '提示'
		    this.toast.mStatus = 'warning'
		    this.toast.tips = '当前合同状态已发生变更请重新加载页面！'
		    this.modelShow = true
		    return
	    }
      // this.$router.push({
      //   path: `/contractTemplate`,
      //   query: {
      //     id: row.id,
      //     no: row.no,
      //     status: 'edit'
      //   }
      // });
	    let url = `/contractTemplate?id=${row.id}&no=${row.no}&status=edit`
	    window.open(url, "_blank");
    },
    donwloadHandler(row) {
      window.open(contractUrl + `/pdf/downLoadFile/${row.contractNum}`, "_self");
    },
    getType(val) {
      if (val === 1) {
        return '销售合同'
      } else if(val === 2){
        return '采购合同'
      }
    },
    async getStatus() {
      let { data } = await apiContract.getStatus();
      this.statuses = data.data;
      let res= await apiContract.getContractType();
      this.types = res.data.data
    }
  },
	components:{
		CommonModalTips: () => import("@/components/public/CommonModalTips.vue"),
	},
}
</script>

<style lang="scss">
.contract-list {
  .el-form-item {
    margin-right: 20px;
  }
  .cjsj .el-form-item__content {
    width: auto;
  }
  .el-form-item__content {
    width: 200px;
  }
  .MyContractList .el-form-item__content {
    width: 270px;
  }
  .page-header {
    color: #000;
    font-size: 18px;
    padding: 20px;
  }
  .el-form {
    padding: 0 20px;
    /*padding-top: 0px;*/
    .el-form-item {
      .el-form-item__label {
        color: #000;
      }
    }
  }
  .table-wrap {
    padding: 20px 20px;
    padding-top: 0;
  }
  .contract-status-1 {
    color: #F7AB01;
  }
  .contract-status-2 {
    color: #0286DF;
  }
  .contract-status-3 {
    color: #78C06E;
  }
  .contract-status-4 {
    color: #C0C4CC;
  }
  .contract-status-5 {
    color: #FF6600;
  }
  .el-button--default {
    color: #0286DF;
    border-color: #0286DF;
    background: rgba($color: #0286DF, $alpha: 0.1);
  }
  .mt20 {
    margin-top: 20px;
  }
  .cff6 {
    color: #FF6600;
  }
}
.toast {
  text-align: center;
  button {
    width: 98px;
    height: 40px;
  }
}
.MyContractList-dropdown {
  float: right;
  cursor: pointer;
  box-sizing: border-box;
  height: 40px;
  line-height: 37px;
  border: 1px solid #0286DF;
  border-radius: 4px;
  // padding: 0 20px;
  width: 111px;
  text-align: center;
  font-size: 14px;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #0286DF;
}
</style>
