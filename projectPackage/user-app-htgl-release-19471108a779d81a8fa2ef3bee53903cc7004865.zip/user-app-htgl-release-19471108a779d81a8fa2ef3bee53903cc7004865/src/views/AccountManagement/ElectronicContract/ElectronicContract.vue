<template>
  <div class="authentication-management-box" v-loading="loading">
    <div class="authentication-title">在线合同开户</div>
    <div class="mt30"></div>
    <!--type：1企业   0个人 v-if="$htgl_user.type == 1"-->
    <div class="information" v-if="$htgl_user.type == 1">
      <p class="title">企业信息</p>
      <div class="line"></div>
      <p class="information-p">
        企业名称：<span>{{ userMsg.enterprise }}</span>
      </p>
      <p class="information-p">
        统一社会信用代码：<span>{{ userMsg.uscCode }}</span>
      </p>
    </div>
    <el-form
            :model="ruleForm"
            :rules="rules"
            ref="ruleForm"
            label-width="122px"
            class="demo-ruleForm"
    >
      <p class="title">账号信息</p>
      <div class="line"></div>
      <template v-if="!isSign">
        <!-- 手机号 -->
        <el-form-item label="手机号码：" prop="username">
          <el-row>
            <el-col :span="10">
              <el-input
                      class="w450"
                      autocomplete="off"
                      v-model="ruleForm.username"
                      placeholder="请输入手机号码"
                      maxlength="11"
                      @input="changeTel"
              ></el-input>
            </el-col>
          </el-row>
          <!--用于接收电子签章验证码的手机号，暂不支持修改（1.0.6.1之前的版本）-->
          <div class="tips">用于接收电子签章验证码的手机号</div>
        </el-form-item>

        <!-- 验证码 -->
        <el-form-item label="验证码：" prop="verificationCode" :error="errorMsg">
          <el-row>
            <el-col :span="7" class="input-box">
              <el-input
                      autocomplete="off"
                      v-model="ruleForm.verificationCode"
                      placeholder="请输入手机验证码"
                      maxlength="6"
                      @blur="errorMsg=''"
              ></el-input>
            </el-col>
            <el-col :span="4">
              <div
                      class="getCode getCodeCked"
                      v-if="verify.ifGetCode && codeFont == '获取验证码'"
                      @click="getSMSLoginCode()"
              >
                获取验证码
              </div>
              <div
                      class="getCode"
                      v-if="!(verify.ifGetCode && codeFont == '获取验证码')"
                      :disabled="true"
              >
                {{ codeFont }}
              </div>
            </el-col>
          </el-row>
        </el-form-item>
      </template>
      <!-- 已开户显示界面 -->
      <div v-else class="account-box">
        <p class="account-title">
          账号：<span>{{ userMsg.account }}</span>
          <el-button v-if="$htgl_user.type == 0" type="text" class="addBtn" @click="showModal">修改账号信息</el-button>
        </p>
        <p class="account-title">
          手机号码：<span>{{ userMsg.tel }}</span>
        </p>
      </div>
      <p class="title titleTop">
        <span v-if="$htgl_user.type == 1">经办人信息</span>
        <span v-if="$htgl_user.type == 0">个人信息</span>
      </p>
      <div class="line" v-if="$htgl_user.type == 0"></div>
      <!-- 经办人姓名 -->
      <template v-if="!isSign && $htgl_user.type == 1">
        <div class="line"></div>
        <el-form-item label="经办人姓名：" prop="name">
          <el-row>
            <el-col :span="10">
              <el-input
                      v-model="ruleForm.name"
                      placeholder="请输入经办人姓名"
                      maxlength="32"
              ></el-input>
            </el-col>
            <el-col :span="2" class="">
              <div class="apply-label">
                <el-tooltip
                        effect="dark"
                        content="企业电子签章的负责人"
                        placement="top"
                >
                  <img src="@/assets/help.png" />
                </el-tooltip>
              </div>
            </el-col>
          </el-row>
        </el-form-item>
        <!-- 身份证号码 -->
        <el-form-item label="身份证号码：" prop="identityCard">
          <el-row>
            <el-col :span="10">
              <el-input
                      v-model="ruleForm.identityCard"
                      placeholder="请输入经办人身份证号码"
                      maxlength="18"
              ></el-input>
            </el-col>
          </el-row>
        </el-form-item>
      </template>
      <div v-else class="account-box">
        <p class="account-title">
          <span v-if="$htgl_user.type == 0">姓名</span>
          <span v-if="$htgl_user.type == 1">经办人姓名</span>：<span>{{ userMsg.name }}</span>
          <el-button v-if="$htgl_user.type == 1" type="text" class="addBtn" @click="showModal">经办人修改</el-button>
        </p>
        <p class="account-title">
          身份证号码：<span>{{
          userMsg.identityNum.replace(
		        userMsg.identityNum.substring(4, 14),
		        "**********"
	        )}}</span>
        </p>
      </div>
      <!-- 同意协议 -->
      <template v-if="!isSign">
        <div class="protocolbox">
          <el-checkbox v-model="checked">
            <span> 点击"立即开通"即同意 </span>
          </el-checkbox>
          <a @click="readProtocol">在线合同开户协议</a>
        </div>
        <!-- 立即开通 -->
        <footer class="footer">
          <el-button
                  :class="isSubmit ? 'btn-style' : 'btn-style1'"
                  @click="subEdit()"
                  :loading="isRequest"
                  :disabled="!isSubmit"
          >
            立即开通
          </el-button>
        </footer>
        <CommonModalTips
                :isVisible="isVisible"
                :tipsText="toast.tipsText"
                :mStatus="toast.mStatus"
                @close="closeToast"
        >
          <div slot="footer" class="toast">
            <el-button type="primary" @click="closeToast">知道了</el-button>
          </div>
        </CommonModalTips>
      </template>
    </el-form>
    <AddHandlerModal :userMsg='userMsg' @getIsOpenAccount='getIsOpenAccount' ref="addHandlerModal"/>
  </div>
</template>

<script>
	import { isvalidPhone } from "@/components/form/validate";
	import apiPact from "@/api/apiContract/apiContract.js";
	import apiUser from "@/api/apiUser";
	export default {
		name: "electronicContract",
		data() {
			return {
				codeFont: "获取验证码",
				codeNum: 60,
				loading: false,
				// 是否开户
				isSign: true,
				//  是否同意协议
				checked: true,
				//  按钮等待
				isRequest: false,
				//   数据填完是否可以提交
				isSubmit: false,
				//弹框是否显示
				isVisible: false,
				errorMsg:"",
				//弹框信息
				toast: {
					tipsText:
						'<p style="color:#333333">开户成功</P><p style="margin-top:9px">恭喜您，在线合同签约账户已开通！</p>',
					mStatus: "success",
				},
				// 用户开户信息
				userMsg: {
					// 企业名字
					enterprise: "",
					// 统一社会信用代码
					uscCode: "",
					account: "",
					tel: "",
					name: "",
					identityNum: "",
				},
				// 表单数据
				ruleForm: {
					username: "",
					verificationCode: "",
					name: "",
					identityCard: "",
				},
				// 正则验证是否
				verify: {
					ifGetCode: false,
					ifYZM: false,
					ifName: false,
					ifCode: false,
				},

				//  正则验证
				rules: {
					username: {
						required: true,
						validator: this.validPhone,
						trigger: "blur",
					},
					name: [{ required: true, validator: this.validName, trigger: "blur" }],
					verificationCode: [
						{ required: true, validator: this.validShort, trigger: "blur" },
					],
					identityCard: [
						{ required: true, message: "请输入身份证号码", trigger: "blur" },
						{ validator: this.validID, trigger: "blur" },
					],
				},
			};
		},
		components:{
			AddHandlerModal:()=>import('./components/addHandlerModal/addHandlerModal.vue'),
			CommonModalTips:()=>import('@/components/public/CommonModalTips')
		},
		created() {
			this.getCompanyMsg();
		},
		watch: {
			// 判断所有数据不为空
			verify: {
				handler: function (v, o) {
					if (v.ifGetCode && v.ifYZM && v.ifName && v.ifCode && this.checked) {
						this.isSubmit = true;
					} else {
						this.isSubmit = false;
					}
				},
				deep: true,
			},

		},
		methods: {
			showModal(){
				this.$refs.addHandlerModal.dialogVisible=true
			},
			//  --------------------------------- 获取企业信息
			async getCompanyMsg() {
				this.loading = true;
				let {data}=  await   apiUser.getCurrentUserCompanyInfo()
				let { companyName } = this.$htgl_user.companyName;
				this.userMsg.enterprise = companyName;
				this.userMsg.uscCode = data.data.attr2;
				this.getIsOpenAccount()

			},
			//  --------------------------------- 关闭提示框
			closeToast() {
				this.loading = true;
				this.isVisible = false;
				this.getIsOpenAccount();
			},
			//  --------------------------------- 验证手机
			validPhone(rule, value, callback) {
				if (!value) {
					callback(new Error("请输入手机号码"));
				} else if (!isvalidPhone(value)) {
					callback(new Error("手机号码格式错误"));
				} else {
					callback();
				}
			},
			// --------------------------验证真实姓名
			validName(rule, value, callback) {
				if (!value) {
					callback(new Error("请输入经办人姓名"));
					this.verify.ifName = false;
				} else if (value.length < 2 || value.length > 8) {
					this.verify.ifName = false;
					callback(new Error("姓名长度应在2-8个字之间"));
				} else {
					this.verify.ifName = true;
					callback();
				}
			},
			//---------------------------- 验证验证码
			validShort(rule, value, callback) {
				if (!value) {
					this.verify.ifYZM = false;
					callback(new Error("请输入验证码"));
				} else if (value.length != 6) {
					this.verify.ifYZM = false;
					callback(new Error("请输入正确的验证码"));
				} else {
					this.verify.ifYZM = true;
					callback();
				}
			},
			// --------------------------验证身份证
			async validID(rule, value, callback) {
				// 身份证号码为15位或者18位，15位时全为数字，18位前17位为数字，最后一位是校验位，可能为数字或字符X
				let reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
				if (reg.test(value)) {
					//   验证是否十八岁
					let age = await this.go(value.length);
					if (age < 0) {
						this.verify.ifCode = false;
						callback(new Error("身份证号码格式错误"));
					}
					if (age < 18 && age > 0) {
						this.verify.ifCode = false;
						callback(new Error("经办人不设置为未成年人"));
					}
					if (age > 18) {
						this.verify.ifCode = true;
						callback();
					}
				} else {
					this.verify.ifCode = false;
					callback(new Error("身份证号码格式错误"));
				}
			},

			//------------------- 验证身份证是否成年
			go(val) {
				let iden = this.ruleForm.identityCard;
				let myDate = new Date();
				let month = myDate.getMonth() + 1;
				let day = myDate.getDate();
				let age = 0;

				if (val === 18) {
					age = myDate.getFullYear() - iden.substring(6, 10) - 1;
					if (
						iden.substring(10, 12) < month ||
						(iden.substring(10, 12) == month && iden.substring(12, 14) <= day)
					) {
						age++;
					}
				}
				if (val === 15) {
					age = myDate.getFullYear() - iden.substring(6, 8) - 1901;
					if (
						iden.substring(8, 10) < month ||
						(iden.substring(8, 10) == month && iden.substring(10, 12) <= day)
					) {
						age++;
					}
				}
				return age;
			},
			//------------------- 手机号input事件
			changeTel() {
				if (this.ruleForm.username.length > 11) {
					this.ruleForm.username = this.ruleForm.username.slice(0, 11);
				}
				if (this.ruleForm.username.length == 11) {
					if (!isvalidPhone(this.ruleForm.username)) {
						this.verify.ifGetCode = false;
					} else {
						this.verify.ifGetCode = true;
					}
					return;
				}
				this.verify.ifGetCode = false;
			},
			//------------------- 点击获取验证码
			async getSMSLoginCode() {
				this.setTime();
				let req = {
					tel: this.ruleForm.username,
				};
				let { data } = await apiPact.getValidateCode(req);
				if (data.code == 200 && data.data === null) {
					this.$message({
						message: "发送成功",
						type: "success",
					});
					return;
				} else {
					this.$_toast({
						msg: "短信验证码发送失败，请稍后重试",
						type: "error",
					});
				}

				this.codeNum = data.data;
			},
			// ------------------- 点击之后获取60s计时
			setTime() {
				this.codeFont = --this.codeNum + "s";
				let setInter = setInterval(
					function () {
						this.codeFont = --this.codeNum + "s";
						if (this.codeNum == 0) {
							this.codeFont = "获取验证码";
							this.codeNum = 60;
							clearInterval(setInter);
						}
					}.bind(this),
					1000
				);
			},
			// ------------------- 打开阅读协议
			readProtocol() {
				this.$alert(
					"<div><div class='content'><p>欢迎访问由中国金融认证中心（简称“CFCA”）全资子公司北京中金国信科技有限公司建设、运维、管理的第三方电子缔约服务平台——安心签平台（以下简称“我们”或“安心签”）！对于您的隐私，我们将绝对尊重并予以保护。您在使用我们的产品与/或服务时，我们可能会收集和使用您的相关信息。我们希望通过《安心签用户个人信息保护政策》（以下简称“本政策”）向您说明，安心签平台（所涉域名为：www.anxinsign.com）是如何收集、存储、保护、使用您的信息以及您享有的权利。本政策正在不断改进中，随着我站服务范围的扩大，我们会随时更新我们的个人信息保护政策。</p><p>本政策与您所使用的安心签以及该服务所包括的各项业务功能（以下统称“我们的产品与/或服务”）息息相关，希望您在使用我们的产品与/或服务前仔细阅读并确认您已经充分理解本政策所写明的内容，并让您可以按照本政策的指引做出您认为适当的选择。您使用或在我们更新本政策后（我们会及时提示您更新的情况）继续使用我们的产品与/或服务，即意味着您同意本政策(含更新版本)内容，并且同意我们按照本政策收集、存储、保护和使用您的相关信息。</p><p>本政策的全部条款属于《安心签服务协议》的一部分。在同意安心签平台服务协议之时，即视为您已经阅读并同意本政策的全部内容，如果您不同意本政策的条款，应停止使用服务。</p><p>本政策将帮助您了解以下内容：</p><p>1、我们如何收集您的个人信息；</p><p>2、我们如何使用您的个人信息；</p><p>3、我们如何共享、转让、公开披露您的个人信息；</p><p>4、我们如何使用Cookie技术；</p><p>5、我们如何存储您的个人信息；</p><p>6、我们如何保护您的个人信息；</p><p>7、您如何管理个人信息；</p><p>8、未成年人个人信息保护；</p><p>9、免责声明；</p><p>10、如何联系我们；</p><p>11、个人信息保护政策的变更和修订。</p><p>1、我们如何收集您的个人信息</p><p>为了提供和优化您需要的服务，我们会根据合理性、合法性、必要性原则，按照如下方式收集并使用您的相关信息：</p><p>1.1您在注册时提供的信息</p><p>当您在注册为用户时，我们会要求您填写注册信息。</p><p>如果您是个人用户，注册信息将包括您的真实姓名、证件类型、证件号码、电话号码、地址和电子邮件地址；如您进行实名认证服务，我们还将收集您的身份证或其他有效证件照片、人脸识别视频、银行卡信息、手写签名及其他认证过程中您提供的认证信息。收集此类信息是为了满足相关法律法规的实名制要求，如您不提供相关信息，您将无法完成实名认证，亦无法申请数字证书用于签署电子文件。</p><p>如果您是企业用户，注册信息将包括公司名称、证件类型、证件号码、公司电话、公司地址、公司邮箱、法定代表人真实姓名及其有效证件号码或身份证正反面照片、经办人真实姓名及其有效证件号码或身份证正反面照片、经办人的电话号码、经办人的地址和经办人的电子邮件地址；此外，您还应提供法人授权经办人注册、管理安心签平台账户的授权书原件。如需进行企业实名认证服务，我们还将收集您公司的对公银行账户信息和其他认证过程中您提供的信息。</p><p>1.2您在使用过程中提供的信息</p><p>当您使用安心签服务时，我们会收集您主动上传的材信息，包括合同原文、哈希值或其他书面材料，这些信息可能涉及您的隐私信息或商业秘密，我们会对上述信息进行安全存储。如您提供的信息中包含他人的隐私信息，您需确认已获得信息主体的合法授权并保证对方知晓并同意本政策，如因您提供的信息给他人利益造成损害的，您承诺自行承担一切责任。同时，如果他人提出相反意见或明确向我们表示不接受本政策约束的，我们将删除相关信息。</p><p>此外，为了保障和优化我们的服务，我们还将收集如下信息：</p><p>（1）在您使用安心签服务访问网页时，自动接收并记录您的浏览器和计算机上的信息，包括您的IP地址、浏览器类型、访问日期和时间、软硬件特征信息及您需求的网页记录等数据。</p><p>（2）如您下载或使用安心签客户端软件，或访问移动网页使用安心签服务时，我们可能会读取与您位置和移动设备相关的信息，包括设备型号、设备识别码、操作系统、分辨率、电信运营商等。</p><p>（3）在您使用安心签服务时，我们会收集您的详细使用情况作为有关日志保存，包括接入网络的方式、类型和状态、网络质量数据、操作日志、服务日志信息等。</p><p>（4）当您通过我们的客服团队、网站留言、问卷调查或参加我们举办的活动等方式与我们联系的时候，我们将收集您提供和反馈的相关信息，并保存您的联系方式及通信/通话内容，以便与您联系或帮助您解决问题。</p><p>（5）为了提高您使用安心签服务时的安全性，更准确地预防钓鱼网站欺诈和木马病毒，我们可能会通过了解一些您的网络使用习惯等手段来判断您账户的风险。</p><p>1.3其他用途</p><p>本政策所列内容可能并未完全列举并涵盖未来将实现的所有功能和业务场景，为了更好的经营安心签产品和服务，我们将基于本政策未载明的其他特定目的收集您的信息，但会事先征求您的同意，通知方式包括但不限于网站公告、电子邮件、电话或短信等。</p><p>1.4例外</p><p>根据相关法律法规规定，以下情形中收集您的个人信息无需征得您的授权同意：</p><p>（1）与国家安全、国防安全有关的；</p><p>（2）与公共安全、公共卫生、重大公共利益有关的；</p><p>（3）与犯罪侦查、起诉、审判和判决执行等有关的；</p><p>（4）出于维护个人信息主体或其他个人的生命、财产等重大合法权益但又很难得到本人同意的；</p><p>（5）所收集的个人信息是个人信息主体自行向社会公众公开的；</p><p>（6）从合法公开披露的信息中收集的您的个人信息的，如合法的新闻报道、政府信息公开等渠道；</p><p>（7）根据您的要求签订合同所必需的；</p><p>（8）用于维护所提供的产品与/或服务的安全稳定运行所必需的，例如发现、处置产品与/或服务的故障；</p><p>（9）法律法规规定的其他情形。</p><p>2、我们如何使用您的个人信息</p><p>我们将严格遵守法律法规及与您的约定，将收集到的信息用作如下用途：</p><p>（1）帮助您成为安心签平台的注册用户；</p><p>（2）检验您提交的注册信息和您提交的相关证件复印件/原件来判断是否为您颁发有效的数字证书，并作为是否为您提供服务的依据；</p><p>（3）检验您提交的注册信息和您专有的数字证书信息来判断您的真实身份，并作为是否为您提供服务的依据；</p><p>（4）在获得您本人同意的前提下，委托有合法资质的第三方机构为您提供实名认证、意愿认证、存证等服务；</p><p>（5）安心签产品开发和服务优化的需要；</p><p>（6）当我们要将信息用于本政策未载明的其他用途或要将基于特定目的收集的信息用于其他目的时，会事先征求您的同意。</p><p>3、我们如何共享、转让、公开披露您的个人信息</p><p>3.1共享</p><p>我们一般不会向第三方主体共享您的个人信息，但以下情况除外：</p><p>（1）事先获得您明确的同意或授权。</p><p>（2）根据国家法律法规规定，或行政、司法机关依法提出的要求，对外共享您的个人信息。</p><p>（3）应您或您监护人的合法需求，协助处理您与他人的纠纷或争议时。</p><p>（4）根据与您签署的相关协议（包括在线签署的电子协议以及相应的平台规则）或其他的法律文件约定所提供。</p><p>（5）为实现本产品的服务目的，我们的某些服务可能由我们和合作机构共同提供，我们将根据法律法规和实际需求向合作伙伴共享您的某些个人信息。您的个人信息可能被传输至公证处、司法鉴定中心、法院、仲裁委、第三方身份认证机构等，我们仅会出于合法、正当、必要、特定、明确的目的共享您的个人信息，并且只会共享提供服务所必要的个人信息。同时，我们的合作机构无权将共享的用户个人信息用于其他任何用途。</p><p>（6）为了优化服务、保障产品安全、更好的了解我们产品运行情况，我们可能会记录相关信息或将收集到的信息用于数据分析。例如您使用产品的频率、故障信息、性能数据等，我们可能对外公开并与我们的合作伙伴共享经统计加工后不含身份识别及其他敏感信息的内容，用于了解用户的使用情况或让公众了解我们产品的总体使用情况。</p><p>3.2转让</p><p>我们一般不会向第三方主体转让您的个人信息，但以下情况除外：</p><p>（1）事先获得您明确的同意或授权。</p><p>（2）当安心签平台的服务提供者发生合并、收购、资产转让或其他类似情形时，如涉及到个人信息转让，我们会要求新的持有您个人信息的公司、组织、个人继续受本政策的约束，否则我们将要求该公司、组织、个人重新征得您的授权同意。</p><p>3.3公开披露</p><p>我们仅会在以下情况中，公开披露您的个人信息：</p><p>（1）已经获得您的明确同意。</p><p>（2）根据法律法规的要求、行政执法或司法要求所必须提供您个人信息的情况下，我们可能会依据所要求的信息类型和披露方式尽可能少的披露您的信息。在向行政执法或司法机关披露后且在前述机关允许的前提下，我们会以合理的方式及时通知您。</p><p>（3）法律法规规定的其他情形。</p><p>4、我们如何使用Cookie技术</p><p>为使您获得更轻松的访问体验，在您使用我们的产品或服务时，我们可能会通过采用各种技术收集和存储您访问安心签服务时的相关数据，其中包括您的IP地址、软硬件特征信息、您需求的网页记录、Cookie中的信息等。为确保网站正常运转，我们会在您的计算机或移动设备上存储名为Cookie的小数据文件。在您未拒绝接受Cookie的情况下，Cookie将被发送到您的浏览器，并储存在您的计算机硬盘。我们使用Cookie储存您访问我们网站的相关数据，在您访问或再次访问我们的网站时，我们能识别您的身份，并通过分析数据为您提供更好更多的服务。</p><p>您有权选择接受或拒绝接受Cookie。您可以通过修改浏览器的设置以拒绝接受Cookie，但是我们需要提醒您，因为您拒绝接受Cookie，您可能无法使用依赖于Cookie的我们网站的部分功能。</p><p>5、我们如何存储您的个人信息</p><p>（1）我们在中华人民共和国境内收集和产生的个人信息将存储在中华人民共和国境内。若为处理跨境业务，确需向境外机构传输境内收集的相关个人信息的，我们会按照法律、行政法规和相关监管部门的规定执行。我们会确保您的个人信息得到足够的保护，例如匿名化、安全存储等。</p><p>（2）收集的用户信息和资料都将加密保存在安心签平台及（或）其关联公司的服务器上。</p><p>（3）我们仅在为您提供安心签服务期间和法律法规要求的时限内存储您的个人信息。</p><p>（4）如我们停止运营产品或服务，我们将及时停止继续收集您个人信息的活动，将停止运营的通知以逐一送达或公告的形式通知您，并在法律法规要求的存储期限届满后，对我们存储的个人信息进行删除或匿名化处理。</p><p>6、我们如何保护您的个人信息</p><p>（1）对我们与之共享个人信息的公司、组织和个人，我们会与其签订严格的数据保护协议，要求其按照我们的说明、本隐私政策以及其他任何相关的保密和安全措施来处理个人信息。</p><p>（2）我们采用的是金融级别的数据安全存储方式，用符合业界最高标准的安全防护措施、安全技术解决方案来防止您的信息遭到未经授权的访问、使用、篡改，避免数据的损坏丢失或泄露。网络服务采取了多种加密技术，例如在某些服务中，我们将利用加密技术（例如SSL）对您的信息进行加密保存，并通过隔离技术进行隔离。同时我们建立了两地三中心（北京、上海）的运行和灾备体系，确保了数据的备份和恢复能力。目前，我们在信息安全方面已达到ISO</p><p>27001、信息安全等级保护（三级）、可信云等国际及国内权威认证标准的要求，并已获得了相应的认证。</p><p>（3）若不幸发生个人隐私数据泄露事件，我们将按照法律法规的要求，及时向您告知：个人隐私数据泄露的基本情况和可能的影响、我们已采取或将要采取的处置措施、您可自主防范和降低风险的建议、对您的补救措施等。我们同时将及时将事件相关情况以邮件、信函、电话、推送通知等方式告知您，难以逐一告知信息主体时，我们会采取合理、有效的方式发布公告。同时，我们还将按照监管部门要求，主动上报个人隐私数据泄露事件的处置情况。</p><p>7、您如何管理个人信息</p><p>我们非常重视您对个人信息的关注，并尽全力保护您对您个人信息访问、更正、删除的权利，以使您拥有充分的能力保障您的隐私和安全。</p><p>7.1访问、更正</p><p>您可以通过访问https://www.anxinsign.com或登录安心签APP，来查询、编辑您账号中的个人资料信息、签章信息、更改您的密码或添加安全信息等。在访问、更正上述信息时，我们可能会要求验证您的身份，以保障信息安全。如果您是企业用户，在申请变更法人代表、经办人时，我们还将要求您重新提交相应的证明文件复印件和授权书原件。</p><p>7.2删除</p><p>以下情形中，您可以通过拨打客服电话400-880-9888向我们提出删除个人信息的请求。</p><p>（1）如果我们收集、使用您的个人信息，却未获得您的授权同意。</p><p>（2）如果我们处理您的个人信息时违反了法律法规要求。</p><p>（3）如果我们处理您的个人信息时违反了与您的约定。</p><p>（4）如果我们终止服务及运营。</p><p>7.3注销</p><p>当您需要终止我们的服务时，可以通过拨打客服电话400-880-9888向我们提出注销账户的申请。</p><p>我们在此善意地提醒您，您注销账户的行为会使您无法继续使用安心签的相关服务，包括合同下载以及出证服务。注销账户后您的个人信息会保持不可被检索、访问的状态，我们将不会再使用或对外提供与该账户相关的个人信息，但您在使用安心签服务期间提供或产生的信息、我们仍需按照监管的要求保存5年以上，且在保存的时间内会依法配合有关机关的查询。</p><p>8、未成年人个人信息保护</p><p>如果您未满16周岁，您无权使用本公司服务，因此我们希望您不要向我们提供任何个人信息。</p><p>如果您是已满16周岁、但未满18周岁的未成年人，在使用我们的产品及相关服务前，应在您的父母或其他监护人监护、指导下共同阅读并同意本隐私政策。</p><p>我们根据国家相关法律法规的规定保护未成年人的个人信息，只会在法律允许、父母或其他监护人明确同意或保护未成年人所必要的情况下收集、使用、共享或披露未成年人的个人信息；如果我们发现在未事先获得可证实的父母或其他监护人同意的情况下收集了未成年人的个人信息，则会设法尽快删除相关信息。</p><p>若您是未成年人的监护人，当您对您所监护的未成年人的个人信息有相关疑问时，请通过本隐私政策公示的联系方式与我们联系。</p><p>9、免责声明</p><p>（1）安心签平台可能含有到其他网站的链接。我们对那些网站的隐私保护措施不负任何责任。我们可能在任何需要的时候增加商业伙伴或共用品牌的网站。</p><p>（2）因您个人原因导致账号密码泄露从而导致个人信息泄露的，安心签平台不负任何责任，但我们会积极地配合您找回密码或更改密码。</p><p>10、如何联系我们</p><p>如果您对本隐私声明或安心签平台的隐私保护措施以及您在使用时有任何意见和建议，欢迎通过安心签平台公布的联系方式和我们联系。</p><p>邮箱：anxinsign@cfca.com.cn</p><p>客服电话：400-880-9888（7*24小时）</p><p>11、隐私政策的变更和修订</p><p>为了给您提供更好的服务，本隐私政策也会随之更新。如该等变更会导致您在本政策项下权利的实质减损，我们将在变更生效前，通过在页面显著位置提示、向您发送电子邮件等方式通知您。在该种情况下，若您继续使用我们的服务，即表示同意受经修订的政策约束。</p></div></div>",
					"在线合同认证协议",
					{
						dangerouslyUseHTMLString: true,
						customClass: "lookOver-ElectronicContract",
						showConfirmButton:false
					}
				).then(() => {
					this.checked = true;
				});
			},

			// ------------------- 立即开通按钮
			subEdit() {
				this.$refs["ruleForm"].validate((ispass) => {
					if (ispass) {
						this.formSubmit();
					} else {
						return false;
					}
				});
			},
			// ------------------- 发送开户请求
			async formSubmit() {
				this.isRequest = true;
				let params = {
					phone: this.ruleForm.username,
					validateCode: this.ruleForm.verificationCode,
					name: this.ruleForm.name,
					identityCard: this.ruleForm.identityCard,
					creditCode: this.userMsg.uscCode,
					companyTel:this.ruleForm.username
				};
				let res = null
				if(this.$htgl_user.type == 0){
					params.identityCard = this.userMsg.identityNum
					params.name = this.userMsg.name
					res = await apiPact.personOpenAccount(params)
				}else {
					res = await apiPact.openAccount(params);
				}
				if (res.data.code == 200) {
					this.isVisible = true;
					this.toast.tipsText='<p style="color:#333333">开户成功</P><p style="margin-top:9px">恭喜您，在线合同签约账户已开通！</p>',
						this.toast.mStatus="success"
				} else if (res.data.code == 10000) {
					this.verify.ifYZM = false;
					this.errorMsg=res.data.msg
				}
				this.isRequest = false;
			},

			// -------------------是否开户
			async getIsOpenAccount() {
				let { data } = await apiPact.getOpenAccountMsg(this.$htgl_user.no);
				console.log(this.$htgl_user)
				if (data.data.status === 0) {
					this.isSign = false;
					if(this.$htgl_user.type == 0){ //个人身份才赋值
						this.verify.ifName = true;
						this.verify.ifCode = true;
						this.userMsg.name = this.$htgl_user.realName;
						this.userMsg.identityNum = data.data.identityCard
					}
				} else {
					this.isSign = true;
					let { csUserId, identityCard, name, phone,id } = data.data;
					// this.userMsg.enterprise=  companyName,
					//   this.userMsg.uscCode= creditCode
					this.userMsg.id = id
					this.userMsg.account = csUserId;
					this.userMsg.identityNum = data.data.identityCard
					this.userMsg.name = name;
					this.userMsg.tel = phone.replace(phone.substring(3, 7), "****");
				}
				this.loading = false;
			},

			//   errType (response) {
			//   switch (response.code) {
			//     case 1001: // 验证码为空
			//       this.rules.code = {
			//         required: false,
			//         validator: this.validCode,
			//         trigger: 'blur'
			//       }
			//       if (!this.showCode) {
			//         this.$_toast({ type: 'error', msg: '请输入验证码' })
			//       }
			//       this.showCode = true
			//       break
			//     case 1002: // 验证码错误
			//       this.$_toast({ type: 'error', msg: '验证码输入有误' })
			//       break
			//     case 1003: // 验证码已过期，请重新获取
			//       this.$_toast({ type: 'error', msg: '验证码已过期，请重新获取' })
			//       break
			//     case 2001: // 用户不存在
			//       this.$_toast({ type: 'error', msg: '该手机号未注册' })
			//       break
			//     case 2002: // 用户或密码错误
			//       this.$_toast({ type: 'error', msg: '手机号或密码有误，请重新输入' })
			//       this.form1.password = ''
			//       break
			//     case 2003: // 用户被禁用
			//       this.$_toast({ type: 'error', msg: '用户被禁用' })
			//       this.form1.password = ''
			//       break
			//   }
			// },
		},
	};
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
  .authentication-management-box {
    padding: 20px;
    min-height: calc(100vh - 225px);
    .authentication-title {
      font-size: 18px;
      color: #000000;
    }
    .information {
      width: 100%;
      /*margin-top: 31px;*/
      padding-bottom: 10px;
      .information-p {
        margin: 20px 0px;
        font-size: 14px;
        color: #666666;
        > span {
          color: #333333;
        }
      }
    }
    .demo-ruleForm {
      width: 100%;
      // margin: 0 auto;
    }

    .tips {
      position: absolute;
      top: 0px;
      left: 470px;
      color: #ff6600;
      font-size: 12px;
    }

    .apply-label {
      position: absolute;
      top: -12px;
      left: 450px;
      color: #0286df;
      line-height: 62px;
      cursor: pointer;

      img {
        margin: 0 20px;
        vertical-align: middle;
      }
    }
    .account-box {
      color: #666666;
      font-size: 14px;
      > p {
        margin: 20px 0px;
      }
    }
    .account-title {
      color: #666666;
      > span {
        color: #333333;
      }
      position: relative;
      .addBtn{
        // float: right;
        position: absolute;
        right: 0;
        top: -21px;
      }
    }
    .lookOver {
      width: 948px;
      height: 595px;
    }
    .title {
      height: 20px;
      padding-left: 10px;
      color: #0286df;
      font-size: 18px;
      line-height: 20px;
      border-left: 3px solid #409ee9;
      padding-bottom: 1px;
    }
    .line {
      width: 100%;
      height: 1px;
      border-bottom: 1px dashed #e4e7ed;
      margin: 11px 0 20px 0;
    }
    .titleTop {
      margin-top: 20px;
    }
    .getCode {
      width: 141px;
      height: 40px;
      // background: #e4e7ed;
      box-sizing: border-box;
      background: white;
      margin-left: 10px;
      line-height: 40px;
      text-align: center;
      font-size: 14px;
      font-weight: 400;
      // color: rgba(192, 196, 204, 1);
      border: 1px solid #0286df;
      color: #0286df;
      // border: 1px solid rgba(228, 231, 237, 1);
      border-radius: 4px;
      cursor: not-allowed;
    }
    .getCodeCked {
      background: white;
      color: #0286df;
      cursor: pointer;
    }
    .footer {
      box-sizing: border-box;
      display: flex;
      justify-content: left;
      padding-top: 9px;

      .btn-style {
        color: #ffffff;
        background-color: #0286df;
        width: 290px;
        height: 40px;
        border-radius: 4px;
        text-align: center;
      }
      .btn-style1 {
        color: #ffffff;
        background-color: #80c2ef;
        width: 290px;
        height: 40px;
        border-radius: 4px;
        text-align: center;
      }
    }
    .protocolbox {
      margin-top: 40px;
      text-align: left;
      font-size: 14px;
      // margin-bottom: 20px;
      span {
        color: #333333 !important ;
      }
      > a {
        color: #0286df;
        cursor: pointer;
      }
    }
    .toast {
      text-align: center;
      button {
        width: 98px;
        height: 40px;
      }
    }
    /deep/.el-form-item__label {
      text-align: right;
      color: #000000;
    }
    /deep/.el-form-item {
      margin-bottom: 26px;
    }
    /deep/.input-box {
      width: 297px;
    }
  }
</style>
<style lang="scss">
  .lookOver-ElectronicContract {
    height: 595px !important;
    width: 948px !important;
    .content {
      // border-top:1px solid #DFE4EA ;
      // width: 100%;
      overflow-y: auto;
      height: 490px;
      margin-top: 5px;
      padding-top: 15px;
    }
    .el-message-box__content {
      padding-top: 0px !important;
    }
    .el-message-box__header {
      border-bottom: 1px solid #dfe4ea;
    }
  }
</style>
