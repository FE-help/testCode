<template>
  <div class="editContractModule">
    <header>
      <div class="page-header">{{status}}合同模板</div>
      <el-form inline :model="contractTemplate" :rules="rules" ref="form">
        <el-form-item label="合同分类：">
          <span>{{$route.query.value}}</span>
          <!--<el-select-->
          <!--class="wd300"-->
          <!--v-model="contractTemplate.type"-->
          <!--placeholder="请选择"-->
          <!--clearable>-->
          <!--<el-option-->
          <!--v-for="item in types"-->
          <!--:key="item.key"-->
          <!--:label="item.value"-->
          <!--:value="item.key"></el-option>-->
          <!--</el-select>-->
        </el-form-item>
        <el-form-item label="模板名称:" prop="name">
          <el-input v-model="contractTemplate.name"
                    placeholder="请输入合同模板名称"
                    maxlength="32"
                    clearable
          ></el-input>
        </el-form-item>
        <el-form-item label="合同类型：" prop="category">
          <el-select
                  class="wd300"
                  v-model="contractTemplate.category"
                  placeholder="请选择"
                  clearable>
            <el-option
                    v-for="item in statuses"
                    :key="item.key"
                    :label="item.value"
                    :value="item.key"></el-option>
          </el-select>
        </el-form-item>

      </el-form>
    </header>
    <div class="line"></div>
    <el-row>
      <el-col :span="18">
        <div style="width: 917px;">
          <section>
            <div class="contractName">
              合同名称
              <!--<el-popover placement="top-start"-->
              <!--trigger="hover"-->
              <!--width="100"-->
              <!--class="item"-->
              <!--effect="dark"-->
              <!--offset="1"-->
              <!--content="创建合同引用当前模板,填写的合同名称">-->
              <!--<div slot="reference">-->
              <!--<img src="@/assets/personal/wenhao.png" alt=""></div>-->
              <!--</el-popover>-->
              <el-tooltip
                      class="item"
                      effect="dark"
                      content="创建合同引用当前模板,填写的合同名称"
                      placement="top"
              >
                <i class="el-icon-question"></i>
              </el-tooltip>
            </div>
            <div class="inputBox">
              甲方:
              <div class="fakerInput">
                <el-tooltip
                        class="item"
                        effect="dark"
                        content="创建合同引用当前模板,选择的甲方名称"
                        placement="top"
                >
                  <i class="el-icon-question"></i>
                </el-tooltip>
              </div>
            </div>
            <div class="inputBox">
              乙方:
              <div class="fakerInput">
                <el-tooltip
                        class="item"
                        effect="dark"
                        content="创建合同引用当前模板,选择的乙方名称"
                        placement="top"
                >
                  <i class="el-icon-question"></i>
                </el-tooltip>
              </div>
            </div>
          </section>
          <el-row style="padding: 0 20px">
            <el-col :span="24" v-for="(item,index) in TinymceData"
                    :key="`${index}`">
              <el-col :span="24" v-if="item.enabled == 1">
                <el-col :span="24"><div class="tc-20"></div></el-col>
                <el-col :span="20" class="contractRule" style="border-right: none">
                  <el-input maxlength="20"
                            class="wd400"
                            v-model="item.title"
                            placeholder="请输入合同段落标题（必填）">
                  </el-input>
                </el-col>
                <el-col :span="4" v-if="item.delTag == 1" style="border-left: none;text-align: right;line-height: 40px" class="contractRule" >
                  <div><i @click="deleteLine(item,index)" class="el-icon-remove-outline cursor" style="font-size: 22px;color:#FF6600"></i></div>
                </el-col>
                <el-col :span="24">
                  <tinymce v-model="item.rule"
                           :key="index"
                           :height="218"
                           :toolbar="toolbar"/>
                </el-col>
              </el-col>
            </el-col>
            <!--<el-col :span="24" v-for="(item,index) in TinymceData"-->
            <!--:key="`key2${key2}${index}`"-->
            <!--v-if="item.enabled == 1">-->
            <!--<el-col :span="24"><div class="tc-20"></div></el-col>-->
            <!--<el-col :span="24" >-->
            <!--<p class="title">-->
            <!--<span>{{item.title}}</span>-->
            <!--</p>-->
            <!--</el-col>-->
            <!--<el-col :span="24">-->
            <!--<tinymce v-model="item.rule"-->
            <!--:key="`key2${key2}${index}`"-->
            <!--:height="100"-->
            <!--:width="877"-->
            <!--:toolbar="toolbar"/>-->
            <!--</el-col>-->
            <!--</el-col>-->
          </el-row>
          <el-row style=" padding:20px;">
            <el-form label-width="124px">
              <el-col :span="12">
                <el-form-item label="甲方（盖章）：" class="fontColor">
                  <div class="fakerInput">
                    <el-tooltip
                            class="item"
                            effect="dark"
                            content="创建合同引用当前模板时,显示选择的甲方信息"
                            placement="top"
                    >
                      <i class="el-icon-question"></i>
                    </el-tooltip>
                  </div>
                </el-form-item>
                <el-form-item label="法定代表人：" class="fontColor">
                  <div class="fakerInput"></div>
                </el-form-item>
                <el-form-item label="授权委托人：" class="fontColor">
                  <div class="fakerInput"></div>
                </el-form-item>
                <el-form-item label="地址：" class="fontColor">
                  <div class="fakerInput"></div>
                </el-form-item>
                <el-form-item label="电话：" class="fontColor">
                  <div class="fakerInput"></div>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="乙方（盖章）：" class="fontColor">
                  <div class="fakerInput">
                    <el-tooltip
                            class="item"
                            effect="dark"
                            content="创建合同引用当前模板时,显示选择的乙方信息"
                            placement="top"
                    >
                      <i class="el-icon-question"></i>
                    </el-tooltip>
                  </div>
                </el-form-item>
                <el-form-item label="法定代表人：" class="fontColor">
                  <div class="fakerInput"></div>
                </el-form-item>
                <el-form-item label="授权委托人：" class="fontColor">
                  <div class="fakerInput"></div>
                </el-form-item>
                <el-form-item label="地址：" class="fontColor">
                  <div class="fakerInput"></div>
                </el-form-item>
                <el-form-item label="电话：" class="fontColor">
                  <div class="fakerInput"></div>
                </el-form-item>
              </el-col>
            </el-form>
          </el-row>
          <div id="btns" class="btns btnsIsFixed">
            <div @click="$removeTag('/contractModule')" :loading="loading" class="item-btn">取消</div>
            <el-button class="item-btn sub-btn" type="primary" @click="submitForm('form')" :loading="loading">保存</el-button>
          </div>
        </div>

      </el-col>
      <el-col :span="6">
        <div style="background-color: #F5F5F5"></div>
      </el-col>
    </el-row>
    <CommonModalTips1
            :isVisible="modelShow"
            :title="toast.title"
            :tipsText="toast.tips"
            :mStatus="toast.mStatus"
            :appendtTobody="toast.appendtTobody"
            @close="$removeTag('/contractModule')">
      <div slot="footer" class="toast" style="text-align: center;">
        <button7 v-if="contactBtn == 'error'" class="mr10" @click="$removeTag('/contractModule')">知道了</button7>
        <!--<el-button v-if="contactBtn == 'error'" type="primary" @click="savaContract()">保存</el-button>-->
        <el-button v-if="contactBtn != 'error'" class="mr10" @click="$router.push(`/previewModule?id=${ContractTemplateId}`)">预览模板</el-button>
        <el-button v-if="contactBtn != 'error'" type="primary" @click="goAdd()">继续添加</el-button>
      </div>
    </CommonModalTips1>
  </div>
</template>

<script>
	import toolbar from '../contractTemplate/toolbar'
	import apiContract from '@/api/apiContract/apiContract'

	export default {
		components:{
			CommonModalTips1: () => import("@/components/public/CommonModalTips.vue"),
			Tinymce: () => import("@/components/Tinymce")
		},
		data() {
			return {
				toast: {
					tips: '',
					mStatus: 'success',
					title: '',
					appendtTobody:true
				},
				status:'新增',
				contactBtn:'',
				ContractTemplateId:'',
				loading:false,
				modelShow:false,
				rules: {
					name: [{ required: true, message: "请输入合同模板名称", trigger: "blur" }],
					category: [{ required: true, message: "请选择合同类型", trigger: "blur" }],
					type: [{ required: true, message: "请选择合同分类", trigger: "blur" }],
				},
				contractTemplate:{
					category: '', //合同类型
					id: '',
					images: '',
					name: '',
					rule1: '',
					rule2: '',
					type: '', //合同分类
				},
				TinymceData:[
					// {title:'合同模板文本内容编辑区域一',rule:'可以在此编辑当前合同模板正文文本内容'},
				],
				key2:2,
				toolbar: toolbar,
				statuses: [], //合同分类下拉数据
				types: [], //合同类型下拉数据
			};
		},
		created() {
			if(this.$route.query.id){
				this.status = '编辑'
				this.getContactInfo()
			}
			if(this.$route.query.key){
				this.status = '新增'
				this.getContactInfoBykey()
			}
			this.getStatus()
		},
		methods:{
			deleteLine(val, index){ //删除合同其他条款弹框
				// if(val.rule){
				//   this.toast.title = '删除提示'
				//   this.toast.mStatus = 'warning'
				//   this.toast.tips = '当前合同段落存在内容，是否确定删除？'
				//   this.modelShow = true
				//   this.contactBtn = 'delRule'
				//   return
				// }
				this.TinymceData.splice(index, 1)
				this.$nextTick(() => {
					this.key2++
				})
			},
			async preview(){
				let id = row.id
				let res = await  apiContract.getModuleDetail(id)
				if(res.data.code == 200 && !res.data.data){
					this.modelShow = true
					this.toast.title = '提示'
					this.toast.tips = '当前合同模板状态已发生变更请重新选择合同模板'
					return
				}
				this.$router.push(`/previewModule?id=${row.id}`)
			},
			goAdd(){
				this.status = '新增'
				let key = this.contractTemplate.type
				if(this.$route.query.key){
					key = this.$route.query.key
				}
				/*?key=164023218878881&value=商品-admin1*/
				this.$removeTag(`/editContractModule?key=${key}&value=${this.$route.query.value}`)
				this.modelShow = false
				this.$refs['form'].resetFields();
				// this.editContractModule
			},
			//新增根据Key 查询模板信息
			async getContactInfoBykey(){
				this.contractTemplate.type = this.$route.query.key
				let obj = {
					typeNo: this.$route.query.key
				}
				let res = await apiContract.getfindByTypeNoList(obj)
				res.data.data.forEach(item=>{
					this.$set(item,'rule','')
					this.$set(item,'title',item.name)
				})
				this.TinymceData = res.data.data
				console.log(this.TinymceData)
			},
			//合同详情
			async getContactInfo(){
				let id = this.$route.query.id
				let res = await  apiContract.getModuleDetail(id)
				if(res.data.code == 200){
					this.contractTemplate.rule1 = JSON.parse(res.data.data.rule1)
					this.contractTemplate.category = res.data.data.category
					this.contractTemplate.type = res.data.data.type
					this.contractTemplate.name = res.data.data.name
					this.contractTemplate.id = res.data.data.id
					// let arr = JSON.parse(res.data.data.rule2)
					// arr.splice(0,1)
					// this.TinymceData = arr
					// this.TinymceData.unshift(JSON.parse(res.data.data.rule1))
					this.TinymceData = JSON.parse(res.data.data.rule2)
					this.TinymceData.unshift(JSON.parse(res.data.data.rule1))
					this.key2++
					this.TinymceData.forEach(item=>{
						if(item.disable !== 1){
							//自己组装数据，和1.0.6 的数据对不上
							this.$set(item,'enabled',1)
							this.$set(item,'delTag',1)
						}
					})
					console.log(this.TinymceData)
				}
			},
			async savaContract(){
				this.loading = true
				this.contactBtn = ''
				let res = await  apiContract.saveContractTemplate(this.contractTemplate)
				if(res.data.code == 200){
					this.ContractTemplateId = res.data.data
					this.toast.title = '模板保存成功'
					this.toast.tips = '合同模板保存成功，您可以继续添加合同模板或预览合同模板'
					this.modelShow = true
					this.loading = false
					// this.$emit('closeDialog')
					// this.$removeTag('/contractModule')
				}else {
					this.contactBtn = 'error'
					this.modelShow = true
					this.toast.mStatus = 'warning'
					this.toast.title = '提示'
					this.toast.tips = `${res.data.msg}`
					this.contractTemplate.id = ''
					this.loading = false
				}
			},
			//保存合同模板
			submitForm(formName) {
				this.$refs[formName].validate(async (valid) => {
					if (valid) {
						let flag = true
						this.loading = true
						this.contractTemplate.images = ''
						let arr = JSON.parse(JSON.stringify(this.TinymceData))
						this.contractTemplate.rule1 = JSON.stringify(this.TinymceData[0])
						arr.splice(0,1)
						for (let i = 0; i < this.TinymceData.length; i++) {
							if(Number(this.TinymceData[i].rule.length) > 50000){
								this.$message({
									message: '最大可输入50000个文字！',
									type: 'error'
								})
								this.loading = false
								return flag = false
							}
						}
						if(!flag){return}
						this.contractTemplate.rule2 = JSON.stringify(arr)
						if(this.$route.query.id){
							let res1 = await  apiContract.getModuleDetail(this.$route.query.id)
							if(res1.data.code == 200 && !res1.data.data){
								this.contactBtn = 'error'
								this.modelShow = true
								this.toast.mStatus = 'warning'
								this.toast.title = '提示'
								this.toast.tips = '当前合同模板已被删除，是否保存最新的合同模板内容？'
								this.contractTemplate.id = ''
								// this.savaContract()
								return
							}else {
								this.savaContract()
							}
							return
						}
						this.savaContract()
					} else {
						console.log('error submit!!');
						return false;
					}
				});
			},
			async getStatus() {
				let { data } = await apiContract.postContractCategory({});
				this.statuses = data.data;
				let res= await apiContract.getContractType();
				this.types = res.data.data
			}
		}
	};
</script>

<style lang="scss" scoped>
  .contractRule{
    /*background-color: #FAFAFA;*/
    /*border-top: 1px dashed #E4E5EC;*/
    /*border-bottom: 1px dashed #E4E5EC;*/
    padding: 10px  0;
    .title{
      padding: 10px 0;
      font-size: 16px;
      color: #333333;
      font-weight: bold;
    }
  }
  .fakerInput {
    width: 285px;
    height: 40px;
    background: #f5f7fa;
    border: 1px solid #e4e7ed;
    border-radius: 4px;
    position: relative;
    /deep/.el-tooltip {
      color: #c0c4cc;
      position: absolute;
      right: -30px;
      top: 10px;
    }
  }
  .editContractModule {
    header {
      padding: 0 20px;
    }
    section {
      div {
        display: flex;
      }
      .contractName {
        width: 100px;
        margin: 29px auto;
        font-size: 24px;
        color: #c0c4cc;
        position: relative;
        /deep/.el-tooltip {
          position: absolute;
          right: -23px;
          top: 7px;
        }
      }
      .inputBox {
        line-height: 40px;
        padding-left: 20px;
        .fakerInput {
          width: 629px;
          height: 40px;
          background: #f5f7fa;
          border: 1px solid #e4e7ed;
          border-radius: 4px;
          margin-bottom: 20px;
          margin-left: 14px;
          position: relative;
          /deep/.el-tooltip {
            color: #c0c4cc;
            position: absolute;
            right: -30px;
            top: 10px;
          }
        }
      }
    }
    .page-header {
      color: #000;
      font-size: 18px;
      padding: 16px 0px;
    }
    /deep/ .el-form-item {
      margin-right: 20px;
    }
    /deep/ .el-input {
      width: 200px;
    }
    /deep/ .el-icon-question {
      font-size: 20px;
    }
    .line {
      height: 1px;
      width: 100%;
      background: #e4e7ed;
    }
  }
  .btns {
    display: flex;
    justify-content: flex-end;
    background: #E5E5E5;
    .item-btn {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 120px;
      height: 54px;
      cursor: pointer;
      font-size: 14px;
      color: #333;
      &:hover {
        color: #0286DF;
      }
    }
    .sub-btn {
      border-radius: 0;
      background: #0286DF;
      color: #fff;
      font-size: 20px;
      &:hover {
        color: #fff;
      }
    }
  }
  .btns-fixed {
    position: fixed;
    bottom: 0;
    z-index: 999;
  }
  /*.contractRule{*/
  /*padding: 6px 10px;*/
  /*background-color: #FAFAFA;*/
  /*border:  1px solid #E4E7ED;*/
  /*border-bottom: none;*/
  /*i{*/
  /*padding: 4px 0;*/
  /*color: #FF6600;*/
  /*}*/
  /*}*/
  .contractRule-btn {
    text-align: left;
    .el-button {
      &.is-plain {
        border: 1px solid #0286df;
        border-radius: 4px;
        color: #0286df;
      }
    }
  }
</style>
