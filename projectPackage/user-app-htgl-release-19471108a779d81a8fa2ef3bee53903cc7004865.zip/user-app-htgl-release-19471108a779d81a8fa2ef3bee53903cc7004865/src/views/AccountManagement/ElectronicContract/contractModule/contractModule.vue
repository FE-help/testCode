<template>
  <div class="contractModule">
    <div class="page-header">合同模板</div>
    <el-form :inline="true" :model="form" ref="form" class="inline-form">
      <el-form-item label="创建时间:" class="cjsj">
        <el-date-picker
                v-model="times"
                type="daterange"
                range-separator="~"
                value-format="timestamp"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                clearable
        >
        </el-date-picker>
      </el-form-item>
      <el-form-item label="模板名称:" prop="name">
        <el-input
                placeholder="请输入合同模板名称"
                v-model="form.name"
                maxlength="32"
                clearable
        ></el-input>
      </el-form-item>
      <el-form-item label="合同类型:" prop="category" >
        <el-select v-model="form.category" placeholder="请选择" clearable>
          <el-option
                  v-for="item in categoryList"
                  :key="item.key"
                  :label="item.value"
                  :value="item.key"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="合同分类:" prop="type">
        <el-select v-model="form.type" placeholder="请选择" clearable>
          <el-option
                  v-for="item in typeList"
                  :key="item.key"
                  :label="item.value"
                  :value="item.key"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="search">查询</el-button>
        <el-button style="margin-left: 20px" @click="reset">重置</el-button>
      </el-form-item>
    </el-form>
    <div class="addBtn">
      <el-button type="primary" @click="addModule">新增模板</el-button>
    </div>
    <!-- 表格 -->
    <div class="table-wrap">
      <el-table
              :data="tableData"
              tooltip-effect="dark"
              :header-cell-style="setColumnDataColor"
              :cell-style="setCellStyle"
              empty-text=""
              border
              v-loading="loading"
      >
        <template slot="empty">
          <base-empty-data />
        </template>
        <el-table-column type="index" label="序号" width="96px">
        </el-table-column>
        <el-table-column
                prop="name"
                label="合同模板名称 "
                show-overflow-tooltip
                width="379"
        >
          <template slot-scope="scope">
            <div class="moduleName">{{ scope.row.name }}</div>
          </template>
        </el-table-column>
        <el-table-column
                prop="categoryName"
                label="合同类型"
                show-overflow-tooltip
                width="145"
        >
        </el-table-column>
        <el-table-column
                prop="typeName"
                label="合同分类"
                show-overflow-tooltip
                width="171"
        >
        </el-table-column>
        <el-table-column  label="模板创建时间" width="227">
          <template slot-scope="scope">
            <span>{{ scope.row.createTime | formatDate}}</span>
          </template>
        </el-table-column>

        <el-table-column label="操作" width="180">
          <template slot-scope="scope">
            <el-button type="text" @click="setData(scope.row)">编辑</el-button>
            <el-button type="text" @click="preview(scope.row)">预览</el-button>
            <el-button
                    type="text"
                    @click="deleteData(scope.row)"
                    class="deleteBtn"
            >删除</el-button
            >
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
              class="mt20"
              style="text-align: center"
              v-if="total > 0"
              @current-change="handleCurrentChange"
              :current-page.sync="params.page"
              :page-size="params.limit"
              layout="prev, pager, next, jumper"
              :total="total"
      ></el-pagination>
    </div>
    <CommonModalTips
            :isVisible="modelShow"
            :title="toast.title"
            :tipsText="toast.tips"
            :mStatus="toast.mStatus"
            :appendtTobody="toast.appendtTobody"
            @close="closeTips">
      <div slot="footer" class="toast">
        <el-button type="primary" @click="closeTips">知道了</el-button>
      </div>
    </CommonModalTips>
    <el-dialog title="请选择合同分类" :visible.sync="dialogFormVisible" width="30%">
      <el-form ref="dorm">
        <el-form-item label="合同分类">
          <el-select v-model="row" placeholder="请选择" clearable>
            <el-option
                    v-for="item in typeList"
                    :key="item.key"
                    :label="item.value"
                    :value="item"
            ></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer" style="text-align: center;margin-bottom: 20px;margin-top: -23px">
        <button7 @click="dialogFormVisible = false"><span style="color: #969696">取 消</span></button7>
        <el-button class="ml20" type="primary" @click="qrBtn">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
	import { setColumnDataColor, setCellStyle } from "@/components/table/style";
	import apiContract from "@/api/apiContract/apiContract.js";

	export default {
		data() {
			return {
				value:'',
				OpenAccountStatus:'',
				row:{},
				dialogFormVisible:false,
				toast: {
					tips: '',
					mStatus: 'warning',
					title: '',
					appendtTobody:true
				},
				modelShow:false,
				form: {
					name: "", // 模板名称
					category: "", //合同类型
					type: "", // 合同分类
				},
				times: [], //选择时间
				categoryList: [], //合同类型下拉数据
				typeList: [], //合同分类下拉数据

				tableData: [],
				loading: false,
				total: 1, // 总数
				params: {
					limit: 20,
					page: 1,
				},
			};
		},

		components: {
			CommonModalTips: () => import("@/components/public/CommonModalTips.vue"),
		},
		computed: {
			setColumnDataColor() {
				return setColumnDataColor;
			},
			setCellStyle() {
				return setCellStyle;
			},
		},
		created() {
			this.getModuleList()
			this.getType()
			this.getIsOpenAccount()
		},
		methods: {
			// -------------------是否开户
			async getIsOpenAccount() {
				let { data } = await apiContract.getOpenAccountMsg(this.$htgl_user.no);
				if(data.data.status == 0){
					this.$confirm('开通在线合同签约账户，即可使用在线合同签约', '提示', {
						confirmButtonText: '马上开通',
						cancelButtonText: '取消',
						type: 'warning',
					}).then(()=>{
            this.$router.push('/ElectronicContract')
          }).catch(() => {
						this.$router.push('/')
					});
				}
				this.OpenAccountStatus = data.data.status
				console.log(data)
				console.log(this.$htgl_user)
			},
			//获取合同类型和分类下拉
			async getType(){
				let data = await apiContract.getContractType();//合同分类
				let res = await apiContract.postContractCategory();//合同类型
				this.typeList=data.data.data
				this.categoryList=res.data.data
			},
			//搜索
			search() {
				this.getModuleList()
			},
			// 获取列表信息
			async getModuleList() {
				this.loading=true
				let req = {
					...this.form,
					...this.params,
					startTime: this.times[0] || "",
					endTime: this.times[1] || "",
				};
				let {data} = await apiContract.getModuleList(req);
				let {records,total}=data.data
				this.tableData=records
				this.total=total
				this.loading=false
			},
			//重置
			reset() {
				this.$refs.form.resetFields();
				this.times = [];
				this.getModuleList()
			},
			closeTips(){
				this.getModuleList()
				this.modelShow = false
			},
			//编辑
			async setData(row) {
				console.log(row)
				let id = row.id
				let res = await  apiContract.getModuleDetail(id)
				if(res.data.code == 200 && !res.data.data){
					this.modelShow = true
					this.toast.title = '提示'
					this.toast.tips = '当前合同模板状态已发生变更请重新选择合同模板'
					return
				}
				this.$router.push({
					path: '/editContractModule',
					query: { id: id, value: row.typeName }
				})
				// this.$router.push(`/editContractModule?id=${row.id}`)
			},
			//预览
			async preview(row) {
				let id = row.id
				let res = await  apiContract.getModuleDetail(id)
				if(res.data.code == 200 && !res.data.data){
					this.modelShow = true
					this.toast.title = '提示'
					this.toast.tips = '当前合同模板状态已发生变更请重新选择合同模板'
					return
				}
				let url = `/previewModule?id=${row.id}`
				window.open(url, "_blank");
				// window.open(`${process.env.VUE_APP_PERSONURL}/previewModule?id=${row.id}`);
				// this.$router.push(`/previewModule?id=${row.id}`)
			},
			//删除
			deleteData(data) {
				this.$confirm("删除后不可恢复，还要继续吗？", "删除提示", {
					confirmButtonText: "确定",
					cancelButtonText: "取消",
					type: "warning",
				}).then(() => {
					this.deleteApi(data.id)
				});
			},
			async deleteApi(id){
				let {data} = await apiContract.deleteModule(id)
				this.reset()
			},

			//分页
			handleCurrentChange(val) {
				this.params.page = val;
				this.search();
			},
			qrBtn(){
				if(!this.row.key){
					this.$message({
						message: `请选择合同分类`,
						type: 'warning'
					})
					return
				}
				console.log(this.row)
				this.$router.push({
					path: '/editContractModule',
					query: { key: this.row.key, value: this.row.value }
				})
			},
			//新增模板
			addModule() {
				this.dialogFormVisible = true
			},
			//格式类型
			formatterType(row, column){
				let val=""
				this.typeList.forEach(element => {
					if (element.key == row.type) {
						val=element.value
					}
				});
				return val
			},
			//格式分类
			formatterCategory(row, column){
				let val=""
				this.categoryList.forEach(element => {
					if (element.key == row.category) {
						val=element.value
					}
				});
				return val
			}
		},
	};
</script>

<style lang="scss" scoped>
  .contractModule {
    .el-form-item {
      margin-right: 20px;
    }
    .cjsj .el-form-item__content {
      width: auto;
    }
    .el-form-item__content {
      width: 200px;
    }
    .cjsj {
      /deep/ .el-input__inner {
        width: 250px;
      }
    }

    .el-form {
      padding: 0 20px;
      /*padding-top: 0px;*/
      .el-form-item {
        /deep/.el-form-item__label {
          color: #000;
          padding-right: 19px;
        }
      }
    }
    .addBtn {
      margin: 0px 0px 20px 20px;
    }
    .table-wrap {
      padding: 20px 20px;
      padding-top: 0;
    }
    .contract-status-1 {
      color: #f7ab01;
    }
    .contract-status-2 {
      color: #0286df;
    }
    .contract-status-3 {
      color: #78c06e;
    }
    .contract-status-4 {
      color: #c0c4cc;
    }
    .contract-status-5 {
      color: #ff6600;
    }
    .el-button--default {
      color: #0286df;
      border-color: #0286df;
      background: rgba($color: #0286df, $alpha: 0.1);
    }
    .mt20 {
      margin-top: 20px;
    }
    .cff6 {
      color: #ff6600;
    }
  }
  .page-header {
    color: #000;
    font-size: 18px;
    padding: 16px 20px;
  }
  .moduleName {
    max-width: 309px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .deleteBtn {
    color: #ff6600;
  }
  .toast {
    text-align: center;
    button {
      width: 98px;
      height: 40px;
    }
  }
</style>
