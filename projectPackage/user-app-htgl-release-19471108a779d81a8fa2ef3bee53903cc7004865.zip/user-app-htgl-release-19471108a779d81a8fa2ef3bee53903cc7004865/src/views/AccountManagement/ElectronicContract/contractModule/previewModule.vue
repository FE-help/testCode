<template>
  <div class="previewModule">
    <div class="page-header">合同模板预览</div>
    <div class="line"></div>
    <div class="contractName">
      合同名称
      <el-tooltip
              class="item"
              effect="dark"
              content="创建合同引用当前模板,需手动填写合同名称"
              placement="top"
      >
        <i class="el-icon-question"></i>
      </el-tooltip>
    </div>
    <div class="inputBox">
      甲方:XXXXXXXXXX
      <el-tooltip
              class="item"
              effect="dark"
              content="创建合同引用当前模板,根据订单选择甲方名称"
              placement="top"
      >
        <i class="el-icon-question"></i>
      </el-tooltip>
    </div>
    <div class="inputBox">
      乙方:XXXXXXXXXX
      <el-tooltip
              class="item"
              effect="dark"
              content="创建合同引用当前模板,根据订单选择乙方名称"
              placement="top"
      >
        <i class="el-icon-question"></i>
      </el-tooltip>
    </div>


    <el-row class="contractRule">
      <el-col :span="24" v-for="(item,index) in TinymceData" :key="`key2${index}`">
        <el-col :span="24"><div class="tc-20"></div></el-col>
        <el-col :span="24" >
          <p class="title">
            <span>{{item.title}}</span>
          </p>
        </el-col>
        <el-col :span="24">
          <div v-html="item.rule" style="width: 917px"></div>
          <!-- <tinymce v-model="item.rule"
                   :key="`key1${index}`"
                   :height="100"
                   :width="877"
                   :toolbar="toolbar"/> -->
        </el-col>
      </el-col>
    </el-row>





    <el-row class="msg">
      <el-col :span="12">
        <el-col :span="24"
        ><span>甲方（盖章）：XXXXXXXXXX</span><el-tooltip
                class="item"
                effect="dark"
                content="创建合同引用当前模板,显示选择的甲方信息"
                placement="top"
        >
          <i class="el-icon-question"></i> </el-tooltip
        ></el-col>
        <el-col :span="24"><span>法定代表人：XXXXXXXXXX</span></el-col>
        <el-col :span="24"><span>授权委托人：XXXXXXXXXX</span></el-col>
        <el-col :span="24"><span><i>* </i> 地址：XXXXXXXXXX</span></el-col>
        <el-col :span="24"><span><i>* </i>电话：XXXXXXXXXX</span></el-col>
      </el-col>
      <el-col :span="12">
        <el-col :span="24"
        ><span>乙方（盖章）：XXXXXXXXXX</span><el-tooltip
                class="item"
                effect="dark"
                content="创建合同引用当前模板,显示选择的乙方信息"
                placement="top"
        >
          <i class="el-icon-question"></i> </el-tooltip
        ></el-col>
        <el-col :span="24"><span>法定代表人：XXXXXXXXXX</span></el-col>
        <el-col :span="24"><span>授权委托人：XXXXXXXXXX</span></el-col>
        <el-col :span="24"><span><i>* </i>地址：XXXXXXXXXX</span></el-col>
        <el-col :span="24"><span><i>* </i>电话：XXXXXXXXXX</span></el-col>
      </el-col>
    </el-row>
  </div>
</template>

<script>
	import apiContract from '@/api/apiContract/apiContract'
	export default {
		components:{
			// Tinymce: () => import("@/components/Tinymce")
		},
		data(){
			return{
				TinymceData:[],
			}
		},
		created(){
			this.getDetail()
		},
		methods:{
			async getDetail(){
				let id=this.$route.query.id
				let {data}=await apiContract.getModuleDetail(id)
				this.TinymceData=JSON.parse(data.data.rule2)
				if(!data.data.rule1) return
				this.TinymceData.unshift(JSON.parse(data.data.rule1))
			}
		}
	};
</script>

<style  lang="scss" scoped>
  .previewModule {
    .page-header {
      color: #000;
      font-size: 18px;
      padding: 20px 20px;
    }
    .line {
      height: 1px;
      width: 100%;
      background: #e4e7ed;
    }

    .contractName {
      width: 100px;
      margin: 29px auto;
      font-size: 24px;
      color: #c0c4cc;
      position: relative;
      /deep/.el-tooltip {
        position: absolute;
        right: -23px;
        top: 7px;
      }
    }
    .inputBox {
      margin-bottom: 20px;
      padding-left: 20px;
      /deep/.el-tooltip {
        color: #c0c4cc;
        font-size: 20px;
        margin-left: 9px;
        vertical-align: text-bottom;
      }
    }
    .contractRule{
      border-top: 1px dashed #E4E5EC;
      border-bottom: 1px dashed #E4E5EC;
      padding: 0 20px 20px 20px;
      .title{
        padding: 10px 0;
        font-size: 16px;
        color: #333333;
        font-weight: bold;
      }
    }
    .msg {
      padding-left: 20px;
      font-size: 16px;
      padding-top: 31px;
      /deep/.el-tooltip {
        position: absolute;
        color: #c0c4cc;
        font-size: 20px;
        margin-left: 9px;
        top: 32px;
      }
      span{
        display: inline-block;
        width: 216px;
        text-align: right;
        margin-bottom: 26px;
      }
      i{
        color: #FF6600;
      }
    }

  }
</style>
