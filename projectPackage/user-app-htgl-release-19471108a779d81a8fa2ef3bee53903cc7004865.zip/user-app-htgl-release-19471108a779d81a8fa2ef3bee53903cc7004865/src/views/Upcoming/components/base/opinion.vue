<!-- 审批意见 -->
<template>
  <div class="opinion">
    <el-form ref="ruleForm" class="demo-ruleForm">
      <el-form-item label="审批意见:" class="opinionItem">
        <el-input type="textarea" v-model.trim="opinion" class="opinionParams" maxlength="300"
                  placeholder="请输入审批意见,最多可输入300字" @blur="transferData"></el-input>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  name: "opinion",
  props: {
    opinionSay: {
      type: String,
      default: '',
    }
  },
  data() {
    return {
      opinion: '',
      // opinion
      prop: '',
    }
  },
  methods: {
    transferData() {
      this.$emit('update:opinionSay', this.opinionSay)
    },
  }
}
</script>

<style scoped lang="scss">
  .opinion {
    /deep/ .opinionItem {
      padding: 10px 14px;
      margin-bottom: 0;

      .el-form-item__label {
        color: #333;
      }

      .el-form-item__content {
        flex: 1;
      }

      .opinionParams {
        ::-webkit-scrollbar {
          width: 2px;
        }

        textarea {
          resize: none;
          height: 118px;
        }
      }
    }
  }
</style>
