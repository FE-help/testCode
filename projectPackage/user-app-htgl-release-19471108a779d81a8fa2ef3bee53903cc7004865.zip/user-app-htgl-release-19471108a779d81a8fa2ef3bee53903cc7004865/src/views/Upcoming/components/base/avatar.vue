<template>
  <div :class="['myAvatar',size?'big':'small',avatarType?'':'back']">
    <!--头像-->
    <div class="userAvatar" v-if="avatarType||iconImg">
      <p v-if="iconImg=='noIcon'">{{ setName }}</p>
      <img :src="setAvatar" alt="" v-else>
    </div>
    <!-- 小标 -->
    <img :src="setStatus" alt="" class="smallMark" v-if="status!=='none'">
    <p class="name" v-if="!avatarType&&!iconImg">{{ setName }}</p>
  </div>
</template>

<script>
export default {
  name: "avatar",
  props: {
    //显示的名字
    name: String,
    //头像大小 true大 false小
    size: {
      type: Boolean,
      default: true,
    },
    //审批状态  -1:待审批,0:拒绝，1：通过 3：转交
    status: {
      type: [Number, String],
      default: 'none',
    },
    //头像 1发起申请 2审批 3抄送
    avatarType: {
      type: String,
    },
    //用户真实头像
    iconImg: {
      type: String,
    }
  },
  computed: {
    //设置头像名字
    setName() {
      //取名字的最后两位
      if (!this.name) return
      let userName = this.name.replace(/[\(（][^\)）]+[\)）]/ig, '').replace(/\s/ig, '')
      let len = userName.length;
      return len > 2 ? userName.slice(len - 2, len) : userName;
    },
    //设置小标图片
    setStatus() {
      let icon = [1, 3, null].includes(this.status) ? 'success' : this.status == -1 ? 'Approval' : this.status == 0 ? 'forward' : 'fail';
      return require(`@/assets/Approve/${ icon }.png`)
    },
    //设置大图
    setAvatar() { //发起申请 审批      抄送
      if (this.iconImg) return this.iconImg;
      console.log(this.iconImg, '**头像')
      let img = {
        //发起
        START: 'Initiate',
        //审批
        USER_EVENT: 'Approve',
        //抄送
        CC_EVENT: 'copyFor',
      }
      return require(`@/assets/Approve/${ img[this.avatarType] }.png`)
    }
  }
}
</script>

<style scoped lang="scss">
  .myAvatar {
    border-radius: 10px;
    font-size: 14px;
    font-family: MicrosoftYaHei;
    color: #FFFFFF;
    text-align: center;
    position: relative;
    user-select: none;

    .smallMark {
      width: 18px;
      height: 18px;
      position: absolute;
      bottom: -2px;
      right: -6px;
    }
  }

  .big {
    width: 44px;
    height: 44px;
    font-size: 14px;
    line-height: 44px;
    position: absolute;
    top: 0;
    left: -22px;

    &:after, &:before {
      content: '';
      width: 4px;
      height: 6px;
      display: block;
      position: absolute;
      top: 44px;
      left: 19px;
      background: white;
    }

    &:before {
      top: -6px;
    }

    .userAvatar {
      width: 44px;
      height: 44px;
      overflow: hidden;
      border-radius: 10px;
      background: #0286DF;

      img {
        min-width: 44px;
        min-height: 44px;
        width: 100%;
      }
    }
  }

  .back {
    background: #0286DF;
  }

  .small {
    line-height: 30px;
    width: 32px;
    height: 32px;
    font-size: 11px;
    border-radius: 5px;

    .name {
      transform: scale(0.95);
    }

    .userAvatar {
      width: 32px;
      height: 32px;
      overflow: hidden;
      border-radius: 5px;

      img {
        min-height: 32px;
        min-width: 32px;
      }
    }
  }
</style>
