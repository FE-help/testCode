<!-- 右侧审批 -->
<script>
import Avatar from "@/views/Upcoming/components/base/avatar";

export default {
  name: "Process",
  components: { Avatar },
  props: {
    //流程
    approve: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      //当前展开的节点
      unfold: [],
    }
  },
  mounted() {
    this.user = this.$htgl_user;
  },
  methods: {
    //根据节点状态返回颜色
    colorSet(status, type = 1) {
      //type 0是节点状态   1是个人审批状态
      // 个人审批状态 -1:待审批,0:拒绝，1：通过 3：转交
      if (type == 1) {
        switch (status) {
          case -1:
          case 3: {
            return '#0286DF';
          }
          case 0:
            return '#FF6600'
          case 1:
            return '#78C06E'
        }
      } else {
        // 节点审批状态 (-1, '待审批'), (0, '审批中'),(1, '通过'),(2, '拒绝'); (4, '拒绝之后的节点')
        switch (status) {
          case 0:
          case -1:
            return '#0286DF';
          case 1:
            return '#78C06E';
          case 2:
            return '#FF6600'
        }
      }
    },
    //展开 收缩
    openUp(nodeIndex) {
      if (this.unfold.includes(nodeIndex)) {
        this.unfold.splice(this.unfold.indexOf(nodeIndex), 1)
        return;
      }
      this.unfold.push(nodeIndex)
    },
    //创建节点描述
    createForDes(num, approveType, nodeStatus, nodeType) {
      // approveType 节点审批人类型 '1'： '会签' ； '2': '或签' ； '3': '依次审批'
      let type = ['会签', '或签', '依次审批']
      let statusType = {
        '-1': '待审批',
        '0': '审批中',
        1: '已通过',
        2: '拒绝'
      };
      //如果是审批节点
      if (nodeType == 'USER_EVENT') {
        return (
          <p class="nodeDescription">
            <span>{ num }人{ type[Number(approveType) - 1] }</span>
            <span style={ { color: this.colorSet(nodeStatus, 0) } }
                  class="desStatus">({ statusType[nodeStatus] })</span>
          </p>
        )
      } else {
        return (
          <p class="nodeDescription">
            <span>{ nodeStatus === 1 ? '已' : '' }抄送{ num }人</span>
          </p>
        )
      }
    },
    //加载一个节点
    createNode(item, index) {
      let { nodeType, nodeStatus, nodeDetail, nodeName, approverType } = item;
      nodeDetail = nodeDetail || [];
      let start = nodeType === 'START';
      let dl = nodeDetail.length;
      let user = start || dl === 1 ? nodeDetail[0] : {};
      //是否展示节点描述
      let canShow = ['USER_EVENT', 'CC_EVENT'].includes(nodeType) && dl > 1
      let nodeIndex = 'node-' + index;
      let classList = () => {
        let classArray = ['node'];
        //未到的节点展示虚线
        if (nodeStatus == -1) classArray.push('notArrived');
        //最后一个节点不展示border
        if (this.approve.length == index + 1) classArray.push('notBorder')
        return classArray
      }
      return (
        <li
          class={ classList() }
          ref={ nodeIndex }
        >
          <avatar avatar-type={ nodeType } status={ nodeStatus }
                  iconImg={ !start && dl === 1 ? user.icon || 'noIcon' : '' }
                  name={ user.icon ? null : user.name }></avatar>
          <div class="node-item">
            <div class="nodeName">
              <p>{ nodeName }</p>

              { canShow && dl > 6 ?
                <img
                  src={ require('@/assets/Approve/put.png') } alt="" onClick={ () => this.openUp(nodeIndex) }
                  class={ [this.unfold.includes(nodeIndex) ? '' : 'shrink', 'unfold'] }
                /> : ''
              }

            </div>
            { canShow ? this.createForDes(dl, approverType, nodeStatus, nodeType) : '' }

            {
              start
                //如果是发起人节点GG
                ? this.createTimer(user.name, user.approvalTime)
                //其他节点
                : this.createForNode(item, nodeIndex)
            }
          </div>
        </li>
      )
    },
    //节点多个人
    createForNode(item, nodeIndex) {
      //将有审批原因的放在最前面展示
      let cache = [];
      let { nodeDetail } = item;
      nodeDetail = nodeDetail || [];
      let len = nodeDetail.length
      nodeDetail = nodeDetail.filter(item => {
        if (!item.reason) return item
        cache.push(item);
      })
      return (
        <div class={ ['content', this.unfold.includes(nodeIndex) ? "upInfo" : ''] }
             style={ { height: len > 6 ? (Math.ceil(len / 6) * 66.5 - 7) + 'px' : 'auto' } }>
          <ul>
            { ...cache.map(({ name, approvalTime, approveStatus, reason }) => {
              return (
                <li class="hasReason">
                  { this.createTimer(name, approvalTime, approveStatus) }
                  <p class="reason">{ reason }</p>
                </li>
              )
            }) }

            { ...nodeDetail.map(({ icon, name }) => {
              return (
                <li class="list-item">
                  <avatar size={ false }
                          iconImg={ icon }
                          name={ name }></avatar>
                  <p class={ ['name', name.length > 2 ? 'long' : ''] }>{ name }</p>
                </li>
              )
            }) }
          </ul>
        </div>
      )
    },
    createTimer(name, time, status) {
      //approveStatus
      // 个人审批状态 -1:待审批,0:拒绝，1：通过 3：转交
      let [username, operating] = name.split(' ')
      return (
        <p class="timerUser">
          <p>
            <span>{ username }</span>
            {
              operating
                ? <span
                  class="operating"
                  style={ { color: this.colorSet(status, 1) } }
                >{ operating }</span> : ''
            }
          </p>
          <span class="time-box">{ time }</span>
        </p>
      )
    }
  },
  render() {
    let { approve } = this;
    return (
      <div class='Approve'>
        <ul>
          { ...approve.map((item, index) => this.createNode(item, index)) }
        </ul>
      </div>
    )
  }
}
</script>

<style lang="scss" scoped>
  * {
    margin: 0;
    padding: 0;
  }


  .Approve {
    flex: 1;
    padding-right: 18px;
    box-sizing: border-box;
    padding-left: 40px;
    height: 580px;
    overflow-y: scroll;
    overflow-x: hidden;
    border-bottom: 1px solid #E4E7ED;

    .node {
      width: 370px;
      min-height: 90px;
      padding-bottom: 26px;
      border-left: 2px solid #DDD;
      position: relative;
      padding-left: 42px;
      box-sizing: border-box;

      .node-item {
        width: 326px;

        .nodeName {
          height: 18px;
          font-size: 16px;
          font-family: MicrosoftYaHei;
          color: #000;
          margin-bottom: 10px;
          display: flex;
          justify-content: space-between;

          img {
            cursor: pointer;
          }
        }

        .nodeDescription {
          font-size: 14px;
          font-family: MicrosoftYaHei;
          color: #666;
          line-height: 14px;
          margin-bottom: 10px;

          .desStatus {
            margin-left: 6px;
          }
        }

        .timerUser {
          justify-content: space-between;
          font-size: 14px;
          font-family: MicrosoftYaHei;
          color: #666666;
          display: flex;

          .operating {
            margin-left: 6px;
          }
          .time-box{
            padding-right: 10px;
          }
        }

        .content {
          transition: .4s;
          overflow: hidden;

          ul {
            width: 326px;
            display: flex;
            flex-wrap: wrap;

            .hasReason {
              width: 326px;

              .reason {
                width: 326px;
                font-size: 14px;
                font-family: MicrosoftYaHei;
                color: #333;
                margin: 10px 0;
              }
            }

            .list-item {
              width: 32px;
              margin-right: 26px;
              margin-bottom: 14px;
              flex-shrink: 0;
              user-select: none;

              &:nth-of-type(6n) {
                margin-right: 0;
              }

              .name {
                width: 32px;
                font-size: 12px;
                font-family: MicrosoftYaHei;
                color: #333;
                text-align: center;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                margin-top: 5px;
              }

              .long {
                width: 36px;
                margin-left: -1px;
              }
            }
          }
        }
      }
    }

    .notArrived {
      border-left: 2px dashed #DDD;
    }

    .notBorder {
      border-left: 2px dashed transparent;
    }

    .upInfo {
      height: 56px !important;
    }

    .unfold {
      transition: .6s;
    }

    .shrink {
      transform: rotateX(180deg);
    }
  }
</style>
