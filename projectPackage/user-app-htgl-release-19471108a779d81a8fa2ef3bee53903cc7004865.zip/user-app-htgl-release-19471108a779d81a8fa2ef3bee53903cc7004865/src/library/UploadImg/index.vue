<template>
  <div class="upload-contianer">
    <div class="avatar-uploader-container">
      <el-upload
        v-if="!maxLength"
        class="avatar-uploader"
        :action="action"
        :show-file-list="false"
        :on-success="handleAvatarSuccess"
        :before-upload="beforeAvatarUpload"
        v-loading="uploadImgLoading"
        element-loading-text="拼命上传中"
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(0, 0, 0, 0.8)"
      >
        <div class="uploadIcon">
          <img src="@/assets/images/shangchuan.png" />
          <p>点击上传</p>
        </div>
      </el-upload>
      <el-upload
        v-if="maxLength && imgList.length < maxLength"
        class="avatar-uploader"
        :action="action"
        :show-file-list="false"
        :on-success="handleAvatarSuccess"
        :before-upload="beforeAvatarUpload"
        v-loading="uploadImgLoading"
        element-loading-text="拼命上传中"
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(0, 0, 0, 0.8)"
        :multiple="multiple"
        :limit="maxLength"
        :on-exceed="exceed"
      >
      <div class="uploadIcon">
        <img src="@/assets/images/shangchuan.png" />
        <p>点击上传</p>
      </div>
      </el-upload>
      <div class="img-coantiner" v-for="(item, index) in imgList" :key="index">
        <img :src="item" alt="" />
        <div class="img-mask">
          <i
            class="el-icon-zoom-in"
            @click="handlePictureCardPreview(item)"
          ></i>
          <i class="el-icon-delete" @click="handleRemove(index)"></i>
        </div>
      </div>
    </div>
    <!-- <div class="upload-img-container"> -->

    <!-- </div> -->
    <p class="msg"  v-if="showMsg ||(maxLength && imgList.length < maxLength) ">{{ msg }}</p>
    <el-dialog :visible.sync="dialogVisible">
      <img width="100%" :src="dialogImageUrl" alt="" />
    </el-dialog>
  </div>
</template>
<script>
export default {
  name: "UploadImg",
  data() {
    return {
      action: `${process.env.VUE_APP_API_USER}/file/add`,
      dialogImageUrl: "",
      dialogVisible: false,
      disabled: false,
      uploadImgLoading: false
    };
  },
  // computed: {
  //   msg: function() {
  //     return this.maxLength
  //       ? `请上传${this.size}M以内的${this.aceptType}格式图片;最多上传${
  //           this.maxLength
  //         }张`
  //       : `请上传${this.size}M以内的${this.aceptType}格式图片`;
  //   }
  // },
  props: {
    imgList: {
      type: Array,
      default: function() {
        return [];
      }
    },
    maxLength: {
      //最多上传图片张数
      type: Number
    },
    aceptType: {
      //限制上传图片格式
      type: String
    },
    size: {
      //限制上传图片大小
      type: Number
    },
    width: {
      //限制上传图片宽
      type: Number
    },
    height: {
      //限制上传图片高
      type: Number
    },
    multiple: {
      //是否支持上传
      type: Boolean,
      default: false
    },
    msg: {
      type: String,
      default: function() {
        return this.maxLength
          ? `请上传${this.size}M以内的${this.aceptType}格式图片;最多上传${
              this.maxLength
            }张`
          : `请上传${this.size}M以内的${this.aceptType}格式图片`;
      }
    },
    showMsg: {
      //是否展示图片提示信息
      type: Boolean,
      default: false
    }
  },
  mounted() {},
  destroyed() {},
  methods: {
    handleRemove(index) {
      this.imgList.splice(index, 1);
      this.$emit("delImg");
    },
    handlePictureCardPreview(url) {
      this.dialogImageUrl = url;
      this.dialogVisible = true;
    },
    handleDownload(file) {
      console.log(file);
    },
    beforeAvatarUpload(file) {
      this.uploadImgLoading = true;
      let istype = true;
      let isSize = true;
      let isWidthAndHeight = true;
      // 限制图片格式
      if (this.aceptType) {
        let type = file.type.split("/");
        type = type[1] || "";
        type = type.toLowerCase();
        let aceptType = this.aceptType.split(",");
        istype = aceptType.indexOf(type) !== -1;
        if (!istype) {
          this.$message.error(`图片支持格式：${aceptType.join("、")}！`);
          this.uploadImgLoading = false;
        }
      }
      if (this.size) {
        // 限制图片大小
        isSize = file.size / 1024 / 1024 < this.size;
        if (!isSize) {
          this.$message.error(`上传图片大小不能超过 ${this.size}MB!`);
          this.uploadImgLoading = false;
        }
      }
      if (this.width && this.height) {
        // 限制图片宽高
        isWidthAndHeight = new Promise((resolve, reject) => {
          let _URL = window.URL || window.webkitURL;
          let image = new Image();
          image.src = _URL.createObjectURL(file);
          image.onload = () => {
            let valid =
              image.width == this.width && image.height == this.height;
            valid ? resolve() : reject(new Error("error"));
          };
        }).then(
          () => {
            return file;
          },
          () => {
            this.$message.error(
              `上传图片尺寸不符合，只能是${this.width}*${this.height}!`
            );
            this.uploadImgLoading = false;
            return Promise.reject(new Error("error"));
          }
        );
      }

      return istype && isSize && isWidthAndHeight;
    },
    handleAvatarSuccess(response, file) {
      if (response.code == 200) {
        this.$emit("uploadSuccess", response.data);
      }
      this.uploadImgLoading = false;
    },
    // 选择超出限制数量时
    exceed(files, fileList) {
      this.$message.warning(`最多上传${this.maxLength}张`);
    }
  }
};
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
.avatar-uploader {
  width: 142px;
  height: 142px;
  margin-right: 10px;
  margin-bottom: 10px;
  .el-loading-mask {
    width: 142px;
    height: 142px;
  }
}
.uploadIcon {
  width: 140px;
  padding: 36.5px 0;
  img {
    display: block;
    width: 44px;
    height: 33px;
    margin: 0 auto 10px;
  }
  p {
    margin: 0;
    width: 100%;
    font-size: 14px;
    font-family: MicrosoftYaHei;
    font-weight: 400;
    color: rgba(2, 134, 223, 1);
    line-height: 24px;
    text-align: center;
  }
}
// .upload-img-container {
//   display: flex;
//   flex-wrap: wrap;
// }
.img-coantiner {
  display: inline-block;
  margin-right: 10px;
  margin-bottom: 10px;
  width: 142px;
  height: 142px;
  position: relative;
  img {
    width: 100%;
    height: 100%;
    border-radius: 6px;
  }
  .img-mask {
    position: absolute;
    display: none;
    top: 0;
    left: 0;
    width: 142px;
    height: 142px;
    border-radius: 6px;
    background-color: rgba($color: #000000, $alpha: 0.5);
    color: #fff;
    line-height: 142px;
    font-size: 24px;
    > i:nth-of-type(1) {
      display: inline-block;
      margin: 0 32px;
      cursor: pointer;
    }
  }
  &:hover {
    .img-mask {
      display: block;
    }
  }
}

.msg {
  font-size: 12px;
  margin-top: -13px;
  color: #666;
}
.upload-contianer {
  // display: flex;
}
.avatar-uploader-container {
  display: flex;
  flex-wrap: wrap;
  // margin-right: 10px;
  // position: relative;
}
// .msg{
//   position: absolute;
//   left: 0;
//   bottom: -10px;
// }
</style>
