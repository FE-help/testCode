<template>
  <div id="enquiry">
    <el-dialog
    :visible.sync="dialogVisible"
    :before-close="handleClose"
    :modal="dialogVisible"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    width="800px">
      <header class="dialog-title" slot="title">函询</header>
      <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="135px" class="demo-ruleForm">
        <el-form-item class="margin-bottom_10" label="请选择函询类型：" prop="enquiryType">
          <div ref="typeContainer" class="type-container" :class="{'height-38':!showMore}">
            <el-radio-group v-model="ruleForm.enquiryType">
              <el-radio-button class="enquiry-type-item" v-for="item in typeList" :key="item.id" :label="item.id">
                {{item.enquiryType}}
              </el-radio-button>
            </el-radio-group>
            <span v-if="hasMoreBtn" class="show-more-btn" :class="{'color-FF6600':showMore}" @click="showMore = !showMore">
              {{showMore ? '收起':'展开'}}
              <i :class="[showMore ? 'el-icon-arrow-up':'el-icon-arrow-down']"></i>
            </span>
          </div>
        </el-form-item>
        <div class="dashed-line"></div>
        <el-form-item label="疑问事项：" prop="questionMatters">
          <el-input
            type="textarea"
            :rows="3"
            maxlength="200"
            show-word-limit
            placeholder="请输入最少5个字，最多200字"
            v-model="ruleForm.questionMatters">
          </el-input>
        </el-form-item>
        <el-form-item label="我的理解：" prop="comprehend">
          <el-input
            type="textarea"
            :rows="3"
            maxlength="200"
            show-word-limit
            placeholder="最多输入200字"
            v-model="ruleForm.comprehend">
          </el-input>
        </el-form-item>
        <el-form-item label="请求答复：" prop="requestAnswer">
          <el-input
            type="textarea"
            :rows="3"
            maxlength="200"
            show-word-limit
            placeholder="最多输入200字"
            v-model="ruleForm.requestAnswer">
          </el-input>
        </el-form-item>
        <div class="more-form-item" v-for="(item,index) in moreFromItem" :key="item.id" >
          <el-form-item class="width-135" label-width="0px" >
            <el-input
              type="text"
              maxlength="10"
              placeholder="最多输入10字"
              v-model="item.name">
            </el-input>
          </el-form-item>
          <el-form-item class="width-600" label-width="0px" :rules="[
            { required: true, message: '请输入字段值', trigger: 'blur' },
          ]">
            <el-input
              type="textarea"
              maxlength="200"
              :rows="3"
              show-word-limit
              placeholder="最多输入200字"
              v-model="item.content">
            </el-input>
          </el-form-item>
          <i class="el-icon-remove-outline del-more-btn" @click="delFormItem(index)"></i>
        </div>
        <el-form-item v-if="moreFromItem.length < 5" label="" prop="delivery">
          <span class="plus-btn" @click="addFormItem">
            <i class="el-icon-plus"></i>
            新增
          </span>
          <span class="color-666">
            最多新增5个字段，标题最多输入10字，内容最多输入200字
          </span>
        </el-form-item>
        <el-form-item label="上传文件：" prop="filedList">
          <UploadFile v-show="ruleForm.filedList.length < 5" @uploadSuccess='uploadSuccess' :aceptType="'rar,zip,doc,docx,pdf,jpg'" :size="10">
            <div class="upload-container">
              <i class="el-icon-plus"></i>
              <p>上传</p>
            </div>
          </UploadFile>
          <ul class="file-list">
            <li v-for="(item,index) in ruleForm.filedList" :key="item.url" class="file-item">
              <div>
                <i class="el-icon-document"></i>
                <span class="file-name text-hidden">{{item.name}}</span>
              </div>
              <i class="el-icon-circle-check"></i>
              <i class="el-icon-close" @click="delFile(index)"></i>
            </li>
          </ul>
        </el-form-item>
        <div class="btn-center">
          <el-button class="el-btn-del" @click="handleClose">取消</el-button>
          <el-button class="el-btn-submit" :loading="submitLoad" type="primary" @click="submitForm('ruleForm')">提交</el-button>
        </div>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import store from "@/store/index.js";
import apiEnquiry from '@/api/apiEnquiry.js'
export default {
  name: "Enquiry",
  data() {
    return {
      dialogVisible: false,
      tipBox:false,
      callback: null,//回调函数
      requestData:{},
      ruleForm: {
          enquiryType: '',
          questionMatters:'',
          comprehend: '',
          requestAnswer: '',
          consequences: '',
          anonymous: 0,
          filedList:[]
        },
      moreFromItem:[],
      rules: {
        enquiryType: [
          { required: true, message: '请选择函询类型', trigger: 'blur' },
        ],
        questionMatters:[
          { required: true, message: '请输入疑问事项', trigger: 'blur' },
          {minLength:5,message: '最少5个字', trigger: 'blur'}
        ]
      },
      typeList:[],
      showMore:true,
      hasMoreBtn:false,
      submitLoad:false
    };
  },
  computed: {},
  components: {
    UploadFile: () => import("@/components/uploadFile"), // 上传文件
  },
  mounted() {

  },
  destroyed() {
    if (this.dialogVisible) {
      this.$destroy(true);
      this.deleteDialog();
    }
  },
  methods: {
    // 获取函询类型
    async getTypeList(){
      const {
        businessType//业务类型 1 转让 2需求 3 服务 4 团队
      } = this.requestData
      let res = await apiEnquiry.enquiryType(businessType);
      if(res.data.code == 200){
        this.typeList = res.data.data || [];
        this.typeList.length ? this.$set(this.ruleForm,'enquiryType',this.typeList[0].id) :''
        this.getHasMoreBtn()
      }
    },
    getHasMoreBtn(){
      this.$nextTick(function(){
        let height = this.$refs.typeContainer.offsetHeight;
        this.hasMoreBtn = height > 38
        console.log('height',height)
      })
    },
    async showDialog(){
      // let $store = store.state
      const {userType,answerNo,answerName,parentMethod,businessId} = this.requestData;
      const{ tenantNo,type,id:no} =  this.$htgl_auth_user || {}
      let isShelves = parentMethod
        ? await parentMethod(businessId || "initDetail")
        : true; // 商品是否上架
      if (!isShelves) {
        this.handleClose();
        return;
      } ;//如果商品已经下架，则不进行后面的咨询流程
      if(type == 2 || (userType != 1 && userType != 0)){
        this.handleClose();
        this.$htgl_funConstruct();
        return
      }
      const {id} = $store.user || {}
      if (!id) {
        this.handleClose();
        this.loginIndex();
        return;
      }
      if(answerNo == tenantNo || (type == 0 &&answerNo == no)){
      // if(answerNo == tenantNo || (answerNo == no)){
        this.$message.warning('自己不能函询自己的数据!');
        this.handleClose();
        return
      }
      this.getTypeList()
      this.dialogVisible = true
    },
    // 登录
    loginIndex() {
      let data = {
        callBack: function() {
          this.$store.dispatch("setUser");
        }.bind(this)
      };
      // this.$_login(data);
      this.$router.push('/login')
    },
    // 提交成功
    define() {
      this.callback("confirm");
      this.deleteDialog();
    },
    // 取消提交
    handleClose() {
      this.callback("cancel");
      this.deleteDialog()
    },
    // 删除弹框
    deleteDialog(){
      this.dialogVisible = false;
      this.$el.parentNode.removeChild(this.$el);
      let pageBody = document.getElementsByTagName("body")[0]
      pageBody.classList.remove("el-popup-parent--hidden");
      pageBody.setAttribute('style', 'padding-right: 0px !important');
    },
    submitForm(formName) {
      this.$refs[formName].validate(async valid => {
        if (valid) {
          try {
            this.submitLoad = true;
            let errorIndex = this.moreFromItem.findIndex(item => !item.content || !item.name)
            console.log('errorIndex',errorIndex)
            if(errorIndex !== -1 ){
              console.log('进入')
              this.$message.warning('新增标题与内容需全部填写!');
              return
            }
            const {phone,type,tenantName,tenantNo,name,id} =  this.$htgl_auth_user || {}
            const {
              userType,//发布数据类型 0 个人 1企业 2团队
              answerNo,answerName,businessTitle,businessId,
            businessType,//业务类型 1 转让 2需求 3 服务 4 团队
            enterpriseType//企业服务类型 1 服务大厅 2商标转让 3 专利转让 4 版权转让 5 公司转让 6资产转让 7需求大厅 8专业团队
            } = this.requestData
            let dealData = {
              answerCompanyName:userType == 1 ? answerName :undefined,
              answerCompanyNo:userType == 1 ? answerNo :undefined,
              answerUserName:userType == 0 ? answerName :undefined,
              answerUserNo:userType == 0 ? answerNo :undefined,
              businessTitle,
              businessId,
              businessType
            }
            let reportData = {
              questionCompanyName:type == 1 ? tenantName :undefined,
              questionCompanyNo:type == 1 ? tenantNo :undefined,
              questionUserName:type == 0 ? name :undefined,
              questionUserNo:type == 0 ? id :undefined,
            }
            let requestData = {
              ...this.ruleForm,
              ...dealData,
              ...reportData,
              enterpriseType,
              filedList:JSON.stringify(this.ruleForm.filedList),
              customFieldList:JSON.stringify(this.moreFromItem)
            }
            let res = await apiEnquiry.enquirySave(requestData)
            if(res.data.code == 200){
              this.$message.success('函询成功！');
              this.define()
            }
          } catch (error) {
            console.log('error',error)
          }finally{
            this.submitLoad = false
          }
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    // 文件上传成功
    uploadSuccess(file){
      this.ruleForm.filedList.push(file)
    },
    // 删除文件
    delFile(index){
      this.$confirm('您确定要删除该文件?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.ruleForm.filedList.splice(index,1)
      })
    },
    // 添加字段
    addFormItem(){
      let item = {
        id:new Date().getTime(),
        name:'',
        content:''
      }
      this.moreFromItem.push(item)
    },
    // 删除字段
    delFormItem(index){
      this.$confirm('您确定要删除当前字段吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.moreFromItem.splice(index,1)
      })
    }
  },
};
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
.dialog-title{
  font-size: 18px;
  color: #000;
  // border-bottom: 1px solid #DFE4EA;
  margin: 0 -20px;
  padding: 0 20px 20px;
}
.demo-ruleForm{
   margin-top: -20px;
  // padding-right: 45px;
}
.upload-container{
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100px;
  height: 100px;
  background: #FFFFFF;
  border: 1px solid #E4E7ED;
  color: #969696;
  line-height: 24px;
  i{
    color: #0286DF;
    font-size: 24px;
  }
}
.file-item{
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 5px;
  margin-top: 5px;
  >div{
    height: 26px;
    line-height: 26px;
    display: flex;
    align-items: center;
    i{
      margin-right: 10px;
    }
    .file-name{
      display: inline-block;
      width: 300px;
    }
  }
  .el-icon-close{
    display: none;
    cursor: pointer;
  }
  .el-icon-circle-check{
    color: #67c23a;
  }
  &:hover{
    background-color: #f5f7fa;
    .el-icon-close{
      display: inline-block;
    }
    .el-icon-circle-check{
      display: none;
    }
  }
}
.type-container{
  display: flex;
}
.show-more-btn{
  flex-shrink: 0;
  cursor: pointer;
  font-size: 12px;
  color: #666;
  height: 36px;
  line-height: 36px;
}
.color-FF6600{
  color: #FF6600;
}
.enquiry-type-item{

  /deep/ .el-radio-button__inner{
    border: none;
    border-radius: 4px;
    color: #000;
    padding: 12px 15px;
  }
  /deep/ &:first-child .el-radio-button__inner,/deep/ &:last-child .el-radio-button__inner{
    border-left: none;
    border-radius: 4px;
  }
  /deep/ .el-radio-button__orig-radio:checked+.el-radio-button__inner{
    background-color: #B79255;
    border-color: #B79255;
    box-shadow: -1px 0 0 0 #B79255;
    color: #fff;
  }

}
.plus-btn{
  display: inline-block;
  width: 89px;
  height: 40px;
  background: #FFFFFF;
  border: 1px solid #0286DF;
  border-radius: 4px;
  line-height: 40px;
  text-align: center;
  color: #0286DF;
  cursor: pointer;
  margin-right: 20px;
}
.btn-center{
  text-align: center;
  margin:  5px 0 10px;
  .el-btn-del{
    margin-right: 10px;
  }
}
.more-form-item{
  display: flex;
  width: calc(100% + 40px);;
}
.width-135{
  width: 130px;
  flex-flow: 0;
  margin-right: 5px;
}
.width-600{
  width: 580px;
}
.del-more-btn{
  font-size: 20px;
  color: red;
  margin-left: 10px;
  margin-top: 20px;
}
.height-38{
  height: 38px;
  overflow: hidden;
}
.dashed-line{
  width: 100%;
  height: 1px;
  box-sizing: border-box;
  border-bottom: 1px dashed #E4E7ED;
  margin-bottom: 20px;
}
.margin-bottom_10{
  margin-bottom: 10px !important;
  /deep/ .el-form-item__error{
    top: 90% !important;
  }
}
/deep/ .el-form-item{
  margin-bottom: 20px;
}
/deep/ .el-form-item__label{
  color: #000;
}
/deep/ .el-radio-button:focus:not(.is-focus):not(:active):not(.is-disabled){
  box-shadow: none;
}
</style>
