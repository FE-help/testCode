<template>
  <div>
    <!-- <div class="uploadIcon" @click="selectImg">
      <img src="@/static/img/shop/shangchuan.png" />
      <p>点击上传</p>
    </div> -->
    <el-upload
      class="avatar-uploader upload-img-multiple"
      :class="{
        'hidden-upload-btn': maxLength && showImgList.length >= maxLength,  
        'margin-15': showImgList.length>0
      }"
      ref="upload"
      id="upload"
      list-type="picture-card"
      :action="action"
      :auto-upload="false"
      :before-upload="beforeAvatarUpload"
      :on-change="uploadChange"
      :on-remove="handleRemove"
      v-loading="uploadImgLoading"
      element-loading-text="拼命上传中"
      element-loading-spinner="el-icon-loading"
      element-loading-background="rgba(0, 0, 0, 0.8)"
      :multiple="multiple"
      :limit="maxLength"
      :file-list="showImgList"
      :on-exceed="exceed"
    >
    <div class="uploadIcon">
      <img src="@/assets/images/shangchuan.png" />
      <p>点击上传</p>
    </div>
    </el-upload>
    <p 
      v-if="maxLength && showImgList.length < maxLength" class="msg" 

    >{{ msg }}</p>
        <!--  -->
  </div>
</template>
<script>
import apiAssets from "@/api/apiAssets";
export default {
  name: "UploadImgMultiple",
  data() {
    return {
      action: `${process.env.VUE_APP_API_USER}/file/add`,
      dialogImageUrl: "",
      dialogVisible: false,
      disabled: false,
      uploadImgLoading: false,
      noneUploadToServe: [], //尚未上传到服器的图片
      showImgList: [],
      isInit: true
    };
  },
  computed: {
    msg: function() {
      return this.maxLength
        ? `请上传${this.size}M以内的${this.aceptType}格式图片;最多上传${
            this.maxLength
          }张`
        : `请上传${this.size}M以内的${this.aceptType}格式图片`;
    }
    // showImgList: function() {
    //   let newList = [];
    //   this.imgList.map(item => {
    //     let newItem = {
    //       uid: item,
    //       url: item
    //     };
    //     newList.push(newItem);
    //   });
    //   let showList = newList.concat(this.noneUploadToServe);
    //   return showList;
    // }
  },
  watch: {
    imgList: {
      handler: function() {
        if (this.isInit && this.imgList.length > 0) {
          this.showImgList = [];
          this.imgList.map(item => {
            let newItem = {
              uid: item,
              url: item
            };
            this.showImgList.push(newItem);
          });
          this.isInit = false; //防止图片提交服务器后，页面显示得图片会先消失，再显示
        }
      },
      immediate: true,
      deep: true
    }
  },
  props: {
    imgList: {
      type: Array,
      default: function() {
        return [];
      }
    },
    maxLength: {
      //最多上传图片张数
      type: Number
    },
    aceptType: {
      //限制上传图片格式
      type: String
    },
    size: {
      //限制上传图片大小
      type: Number
    },
    width: {
      //限制上传图片宽
      type: Number
    },
    height: {
      //限制上传图片高
      type: Number
    },
    multiple: {
      //是否支持上传
      type: Boolean,
      default: false
    }
  },
  mounted() {},
  destroyed() {},
  methods: {
    selectImg() {
      // this.$refs.upload.$el.click();
      // document.getElementById('upload').click();
      this.$refs.upload.getFile();
      console.log("点击按钮", this.$refs.upload, this.$refs.upload.getFile());
    },
    handleRemove(file, fileList) {
      let imgIndex = this.imgList.findIndex(imgItem => imgItem == file.url);
      if (imgIndex !== -1) {
        this.imgList.splice(imgIndex, 1);
      } else {
        let noneUploadIndex = this.noneUploadToServe.findIndex(
          noneUploadItem => noneUploadItem.uid == file.uid
        );
        noneUploadIndex !== -1
          ? this.noneUploadToServe.splice(noneUploadIndex, 1)
          : "";
      }
      let showImgIndex = this.showImgList.findIndex(
        showImgItem => showImgItem.uid == file.uid
      );
      showImgIndex !== -1 ? this.showImgList.splice(showImgIndex, 1) : "";
    },
    handlePictureCardPreview(url) {
      this.dialogImageUrl = url;
      this.dialogVisible = true;
    },
    handleDownload(file) {
      console.log(file);
    },
    beforeAvatarUpload(file) {
      this.uploadImgLoading = true;
      let istype = true;
      let isSize = true;
      let isWidthAndHeight = true;
      // 限制图片格式
      if (this.aceptType) {
        let type = file.type.split("/");
        type = type[1] || "";
        type = type.toLowerCase();
        let aceptType = this.aceptType.split(",");
        istype = aceptType.indexOf(type) !== -1;
        if (!istype) {
          this.$message.error(`图片支持格式：${aceptType.join("、")}！`);
          this.uploadImgLoading = false;
        }
      }
      if (this.size) {
        // 限制图片大小
        isSize = file.size / 1024 / 1024 < this.size;
        if (!isSize) {
          this.$message.error(`上传图片大小不能超过 ${this.size}MB!`);
          this.uploadImgLoading = false;
        }
      }
      if (this.width && this.height) {
        // 限制图片宽高
        isWidthAndHeight = new Promise((resolve, reject) => {
          let _URL = window.URL || window.webkitURL;
          let image = new Image();
          image.src = _URL.createObjectURL(file);
          image.onload = () => {
            let valid =
              image.width == this.width && image.height == this.height;
            valid ? resolve() : reject(new Error("error"));
          };
        }).then(
          () => {
            return file;
          },
          () => {
            this.$message.error(
              `上传图片尺寸不符合，只能是${this.width}*${this.height}!`
            );
            this.uploadImgLoading = false;
            return Promise.reject(new Error("error"));
          }
        );
      }

      return istype && isSize && isWidthAndHeight;
    },
    // 选择超出限制数量时
    exceed(files, fileList) {
      fileList = [];
      this.$message.warning(`最多上传${this.maxLength}张`);
    },
    uploadChange(file, fileList) {
      this.noneUploadToServe = [];
      this.showImgList = fileList;
      fileList.map(item => {
        if (item.status != "success" || item.row) {
          this.noneUploadToServe.push(item);
        }
      });
      this.$forceUpdate();
      this.$emit("uploadSuccess");
    },
    // 上传图片至服务器
    async uploadeImgToserve() {
      let uploadFiles = this.noneUploadToServe;
      let formData = new FormData();
      // 文件对象
      uploadFiles.map(item => {
        formData.append("file", item.raw);
      });
      let res = await apiAssets.addFiles(formData);
      if (res.data && res.data.code == 200) {
        let data = res.data.data || [];
        data.map(item => this.imgList.push(item));
      }
    }
  }
};
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
.avatar-uploader {
  
}
.margin-15 {
  margin-bottom: -25px;
}
.uploadIcon {
  width: 140px;
  // height: 140px;
  // border: 1px dashed #d9d9d9;
  // border-radius: 6px;
  cursor: pointer;
  padding: 36.5px 0;
  img {
    display: block;
    width: 44px;
    height: 33px;
    margin: 0 auto 10px;
  }
  p {
    margin: 0;
    width: 100%;
    font-size: 14px;
    font-family: MicrosoftYaHei;
    font-weight: 400;
    color: rgba(2, 134, 223, 1);
    line-height: 24px;
    text-align: center;
  }
}
.upload-img-container {
  display: flex;
  flex-wrap: wrap;
}
.img-coantiner {
  margin-right: 10px;
  margin-top: 10px;
  width: 142px;
  height: 142px;
  position: relative;
  img {
    width: 100%;
    height: 100%;
    border-radius: 6px;
  }
  .img-mask {
    position: absolute;
    display: none;
    top: 0;
    left: 0;
    width: 142px;
    height: 142px;
    border-radius: 6px;
    background-color: rgba($color: #000000, $alpha: 0.5);
    color: #fff;
    line-height: 142px;
    font-size: 24px;
    > i:nth-of-type(1) {
      display: inline-block;
      margin: 0 32px;
      cursor: pointer;
    }
  }
  &:hover {
    .img-mask {
      display: block;
    }
  }
}

.msg {
  font-size: 12px;
  margin-top: -2px;
  color: #666;
}
.upload-img-multiple /deep/ .el-upload-list,
.upload-img-multiple /deep/ .el-upload-list--picture-card {
  // display: block !important;
  margin-bottom: -15px;
}
.upload-img-multiple /deep/ .el-upload--picture-card {
  background-color: #fff !important;
  margin-bottom: 20px;
}
.upload-img-multiple /deep/ .el-upload-list__item-status-label {
  display: none;
  
}
/deep/ .el-upload-list--picture-card .el-upload-list__item{
  width: 140px;
  height: 140px;
  // line-height: 140px;
}
/deep/ .el-upload--picture-card{
  width: 138px;
  height: 138px;
  line-height: 138px;

}
</style>
<style>
.hidden-upload-btn .el-upload {
  display: none !important;
}
</style>
