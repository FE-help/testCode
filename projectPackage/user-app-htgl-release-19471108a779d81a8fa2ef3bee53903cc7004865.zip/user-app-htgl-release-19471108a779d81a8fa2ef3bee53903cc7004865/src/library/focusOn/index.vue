<template>
  <span class="pointer focus-btn btn" :class="[isFocus == 0 ? 'focused-class' : 'unfocus-class' ]" @click.stop="chat">
    <span v-if="!customStyle" class="focus-btn-container">
      <img v-if="showIcon" :src="[isFocus == 0 ? focusedIcon : unFocusIcon ]" alt="">{{ isFocus == 0 ?'已关注':'关注' }}
    </span>
    <slot v-if="customStyle"></slot>
  </span>

</template>
<script>
import apiCompanyService from "@/api/apiCompanyService";
import unFocus from '@/assets/images/unFocus.png'
import focused from '@/assets/images/focused.png'
export default {
  name: "FocusOn",
  data() {
    return {
      hanlding:false,//是否正在处理中
      isFocus:1,//1--取消关注，0-关注
      focusId:undefined,//关注数据id
    };
  },
  props:{
    itemId:{
      type:[Number,String]
    },
    parentMethod:{
      type:Function
    },
    customStyle:{//是否自定义样式
      type:Boolean,
      default:false
    },
    type:{
      type:[Number,String],
      default:1,//关注分类 1资产 2需求 3专利 4版权 5商标 6公司 7 服务
    },
    propFocusId:{//关注数据id
      type:[Number,String]
    },
    propStatus:{//关注状态是否由父组件传值,如果由父组件传值则不调用后端接口获取当条数据的关注状态
      type:Boolean,
      default:false
    },
    showIcon:{//是否显示关注icon
      type:Boolean,
      default:true
    },
    unFocusIcon:{//未关注时显示的icon
      type:String,
      default:unFocus
    },
    focusedIcon:{//关注后显示的icon
      type:String,
      default:focused
    },
  },
  watch: {
    itemId:{
      handler:function(newVal,oldVal) {
        this.getFocusStatus()
      },
      immediate:true
    },
    'userInfo.no':{
      handler:function(newVal,oldVal) {
        if(!newVal){
          this.isFocus = 1;
          return
        }
        this.getFocusStatus()
      },
      immediate:true
    },
    propFocusId:{
      handler:function(newVal,oldVal) {
        if(newVal){
          this.focusId = newVal;
          this.isFocus = 0;
        }
      },
      immediate:true
    }
  },
  computed:{
    userInfo() {
      return this.$htgl_user || {};
    },
  },
  mounted() {
  },
  methods: {
        //获取当前数据关注的状态
    async getFocusStatus() {
      if (this.propStatus) return;
      const {no} = this.userInfo;
      if(!this.itemId || !no) return
      let res = await apiCompanyService.focusStatus({
        userNo:no,
        dataId: this.itemId,
        type: this.type
      });
      if (res.data && res.data.code == 0) {
        let data = res.data.data || []
        this.isFocus = data.length === 0 ? 1 : 0;
        this.focusId = data[0].id;
      }
    },
    async chat() {

      try {
        if(this.hanlding == true) return;
        this.hanlding = true;
        let isShelves = this.parentMethod
          ? await this.parentMethod(this.itemId || "initDetail")
          : true; // 商品是否上架

        if (!isShelves) {
          //如果商品已经下架，则不进行后面的咨询流程
          return;
        }
        const {id,no} = this.userInfo
        if (!id) {
          this.loginIndex();
          return;
        }
        await this.handleFocus(no)
      } catch (e) {

      }finally{
        this.hanlding = false
      }
    },
    //关注/取消关注
    async handleFocus(attentionNo) {
      let res = await apiCompanyService.focus({
        attentionNo,
        attentionNot: !this.isFocus ? 1 : 0,
        id: this.itemId,
        type: this.type,
        dataId:this.focusId
      });
      if (res.data && res.data.code == 0) {
        let data = res.data.data || [];
        this.isFocus = !this.isFocus ? 1 : 0;
        if(this.isFocus == 0){
          this.$message({
            message: '关注成功',
            type: 'success'
          })
          this.focusId = data;
          return
        }
        this.$message('已取消关注');
        this.focusId = undefined;
        this.$emit("initList",this.itemId);
      }
    },
    loginIndex() {
      this.$store.dispatch("LOGIN_OUT");
      this.$router.push('/login')
    },
  }
};
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
.btn-container{
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  img{
    margin-right: 5px;
  }
}
.unfocus-class{
  width: 50%;
  background: #FFFFFF;
  border: 1px solid #E4E7ED;
  color: #969696;
  &:hover{
    color: #969696;
  }
}
.focused-class{
  width: 50%;
  background: #FFFFFF;
  border: 1px solid #F7AB01;
  color: #F7AB01 ;
  &:hover{
    color: #F7AB01;
  }
}
.pointer{
  cursor: pointer;
}
.btn{min-width: 110px !important}
.focus-btn{
  vertical-align: top;
}
.focus-btn-container{
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
