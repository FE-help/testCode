<template>
  <div class="none-data" :class="{'border':border}" :style="{ height: `${height ? height : 500}px` }">
    <img
      :style="{ height: `${imgHeight ? imgHeight : 177}px` }"
      :src="imgUrl || zanwushuju"
      alt=""
    />
    <p>{{ text || "暂无数据" }}</p>
  </div>
</template>
<script>
import zanwushuju from "@/assets/images/zanwushuju-2@2x.png";
export default {
  name: "NoneData",
  props: {
    text: {
      type: String
    },
    imgUrl: {
      type: String
    },
    height: {
      type: Number
    },
    imgHeight: {
      type: Number
    },
    border: {//是否需要边框
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      zanwushuju
    };
  },
  methods: {},
  mounted() {},
  destroyed() {}
};
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
.none-data {
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #fff;
  p {
    color: #666666;
    font-size: 16px;
    margin-top: 10px;
  }
}
.border{
  border: 1px solid #e4e7ed;
}
</style>
