<template>
  <div class="tip-container">
    <el-dialog :visible.sync="tipBox"     
      :close-on-click-modal="false"
      :close-on-press-escape="false" 
       :before-close="deleteDialog"
      width="600px">
      <div class="tip-title" slot="title">
        温馨提示
      </div>
      <div class="tip-content">
        <img src="~@/assets/images/jianshe.png" alt="" />
        <p>该功能正在建设中，敬请期待</p>
      </div>
    </el-dialog>
  </div>
</template>
<script>
export default {
  name: "FunConstruct",
  data() {
    return {
      tipBox:true,
      callback: null,//回调函数
    };
  },
  computed: {

  },
  components: {

  },

  mounted() {
    // this.tipBox = true
  },
  destroyed() {

  },
  methods: {
    // 删除弹框
    deleteDialog(){
      this.tipBox = false;
      this.callback();
      this.$el.parentNode.removeChild(this.$el);
      let pageBody = document.getElementsByTagName("body")[0]
      pageBody.classList.remove("el-popup-parent--hidden");
      pageBody.setAttribute('style', 'padding-right: 0px !important');
    },
  },
};
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
// .tip-container{
//   position: fixed;
//   top: 0;
//   left: 0;
// }
.tip-title {
  color: #000;
  font-size: 18px;
  margin: 0 -15px;
  padding: 0 0 0 15px;
}
.tip-content {
  text-align: center;
  color: #969696;
  font-size: 16px;
  line-height: 32px;
  padding: 7px 0 8px;
}
</style>
