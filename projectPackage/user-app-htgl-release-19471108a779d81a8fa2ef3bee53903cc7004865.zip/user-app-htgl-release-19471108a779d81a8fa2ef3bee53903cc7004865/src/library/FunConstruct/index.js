import Vue from "vue"; // 引入 Vue 是因为要用到 Vue.extend() 这个方法
import Index from "./index.vue"; // 引入刚才的 toast 组件

let hasDom = false;//是否已经创建dom,确保每次只生成一次自定义组件
const confirmConstructor = Vue.extend(Index); // 这个在前面的前置知识内容里面有讲到
const FunConstruct = (
 
) => {
  return hasDom ? false : new Promise((reslove, reject) => {
    const confirmDom = new confirmConstructor({
      el: document.createElement("template"),
      data() {
        return {
          tipBox:true
        };
      }
    });
    confirmDom.callback = action => {
      hasDom = false;
    };
    document.body.appendChild(confirmDom.$el);
    hasDom = true;
  });
};

export default FunConstruct;
