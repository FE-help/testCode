// 函数式组件调用提示弹窗
<template>
  <CommonModalTips
    :title="title"
    :isVisible="dialogVisible"
    :mStatus="'warning'"
    :tipsText="msg"
    :isDistory="true"
    @close="deleteDialog"
  >
    <div slot="footer" class="foot‐btn‐group‐blue submit-btn-container">
      <el-button
        v-if="showCancelBtn"
        @click="deleteDialog"
        >{{ cancelBtnText }}</el-button
      >
      <el-button
        :class="{'htgl__margin-left-20': showCancelBtn }"
        type="primary"
        @click="deleteDialog('confirm')"
        >{{ confirmBtnText }}</el-button
      >
    </div>
  </CommonModalTips>
</template>
<script>
export default {
  name: "msgDialog",
  data() {
    return {
      dialogVisible: true,
      title: "温馨提示", //标题
      msg: "删除后将无法恢复，确定删除？",
      callback: null, //回调函数
      confirmBtnText: "确定",
      cancelBtnText: "取消",
      showCancelBtn: true,//是否显示取消按钮
      showConfirmBtn: true,//是否显示确认按钮
    };
  },
  computed: {},
  components: {
    CommonModalTips: () => import("@/components/CommonModalTips.vue")
  },
  mounted() {},
  destroyed() {},
  methods: {
    // 删除弹框
    deleteDialog(callbackData) {
      this.dialogVisible = false;
      this.callback(callbackData || "cancel");
      this.$el.parentNode.removeChild(this.$el);
      let pageBody = document.getElementsByTagName("body")[0];
      pageBody.classList.remove("el-popup-parent--hidden");
      pageBody.setAttribute("style", "padding-right: 0px !important");
    }
  }
};
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
.submit-btn-container {
  text-align: center;
  margin-top: 40px;
  margin-bottom: 10px;
}
.htgl__margin-left-20 {
  margin-left: 20px;
}
.el-button {
  font-weight: 400;
}
</style>
