/**
 * appBus 事件名常量
 * */


// 跳转到登录页面
export const REDIRECT_LOGIN = 'redirectLogin'
