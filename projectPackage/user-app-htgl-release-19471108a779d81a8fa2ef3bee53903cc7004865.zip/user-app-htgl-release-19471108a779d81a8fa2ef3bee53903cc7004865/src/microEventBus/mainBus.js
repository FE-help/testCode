

function emptyBus () {
  // 警告：提示当前使用的是空 Action
  console.warn('Current execute mainBus is empty!')
}
class MainBus {
  constructor () {
    this.mainAppBus = emptyBus
  }

  setMainBus (bus) {
    this.mainAppBus = bus
  }
}

export default new MainBus()
