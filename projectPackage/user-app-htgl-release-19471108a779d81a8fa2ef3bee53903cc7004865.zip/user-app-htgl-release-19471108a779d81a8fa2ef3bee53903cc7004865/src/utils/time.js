/**
 * 时间相关函数
 * */
import dayjs from "dayjs";

/**
 * 时间格式化
 * link: https://dayjs.fenxianglu.cn/category/display.html#格式化
 YY | 18 | 年，两位数
 YYYY | 2018 | 年，四位数
 M | 1-12 | 月，从1开始
 MM | 01-12 | 月，两位数字
 MMM | Jan-Dec | 月，英文缩写
 D | 1-31 | 日
 DD | 01-31 | 日，两位数
 H | 0-23 | 24小时
 HH | 00-23 | 24小时，两位数
 h | 1-12 | 12小时
 hh | 01-12 | 12小时，两位数
 m | 0-59 | 分钟
 mm | 00-59 | 分钟，两位数
 s | 0-59 | 秒
 ss | 00-59 | 秒，两位数
 */
export const timestampToTime = (time, format = "YYYY-MM-DD HH:mm:ss") => {
  if (!time || time === "undefined" || time === "null") return "";
  return dayjs(time).format(format);
};
