import Vue from "vue";
import "./library.js";
import * as filters from "@/filters/index.js";
// 注册全局过滤器
Object.keys(filters).map(key => {
  Vue.filter(key, filters[key]);
});
// /**
//  * @Descripttion 公共组件挂载 简化页面级引用
//  * @Func {requireComponent} 获取目标文件下所有匹配子文件
//  * @event func(directory, useSubdirectories, regExp)
//  * @params {directory} 其组件目录的相对路径
//  * @params {useSubdirectories} 是否查询其子目录
//  * @params {regExp} 匹配基础组件文件名的正则表达式
//  * @regExp [/^\.\/(.*)\.\w+$/] 剥去文件名开头的 './' 和结尾的扩展名
//  */
// const requireComponent = require.context(
//   "@/components/baseComponents",
//   false,
//   /[base|Base][A-Z]\w+\.(vue|js)$/
// );
// requireComponent.keys().forEach(fileName => {
//   const componentConfig = requireComponent(fileName);
//   let componentName = fileName.replace(/^\.\/(.*)\.\w+$/, "$1");
//   // 全局注册组件
//   // 如果这个组件选项是通过 `export default` 导出的，
//   // 那么就会优先使用 `.default`，
//   // 否则回退到使用模块的根。
//   Vue.component(componentName, componentConfig.default || componentConfig);
// });
