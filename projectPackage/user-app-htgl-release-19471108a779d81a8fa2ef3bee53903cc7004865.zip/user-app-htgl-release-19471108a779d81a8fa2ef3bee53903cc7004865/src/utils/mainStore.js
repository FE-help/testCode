import Vue from "vue";
import mainStore from "@/mainStore";
import { needKeyList } from "@/config/mainStore";
// 获取主应用store中的变量
export function getMainStore(propsMainStore, keyList = needKeyList) {
  const mStore = propsMainStore || (mainStore && mainStore.store);
  const { state = {} } = mStore;
  let result = {};
  keyList.map(item => {
    result[item] = state[item];
  });
  return result;
}
// 将主应用store中的变量设置为当前子项目的全局变量
export function setMainStoreProto(propsMainStore, keyList = needKeyList) {
  let resMainStore = getMainStore(propsMainStore, keyList);
  for (let key in resMainStore) {
    Vue.prototype[`$htgl_${key}`] = resMainStore[key];
  }
}
// 删除挂载在Vue.prototype上的全局变量
export function delMainStoreProto(keyList = needKeyList) {
  keyList.map(item => {
    delete Vue.prototype[`$htgl_${item}`];
  });
}
