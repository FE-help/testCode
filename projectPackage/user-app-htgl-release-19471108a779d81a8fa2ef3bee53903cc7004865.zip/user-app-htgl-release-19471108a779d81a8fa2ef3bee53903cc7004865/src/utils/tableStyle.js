const setColumnDataColor = ({ row, column, rowIndex, columnIndex }) => {
  // if (column.property === 'title' || column.property === 'strongLevel' || column.property === 'cangchu_proper') {
  if (rowIndex === 0 && column.type != "selection") {
    return (
      "color: #333333;" +
      "padding: 10px 0;" +
      "font-weight: 400;" +
      "background-color:#FAFAFA;" +
      "font-size:14px;" +
      "font-weight: bold;"
    );
  }
  if (column.type == "selection") {
    return (
      "border-right:1px solid #E4E7ED;" +
      "background-color:#FAFAFA;" +
      "text-align: center"
    );
  }
};
const setCellStyle = ({ row, column, rowIndex, columnIndex }) => {
  if (column.type != "selection") {
    return {
      color: "#666666",
      // cursor: 'pointer',
      padding: "0",
      height: "44px"
    };
  }
  if (column.type == "selection") {
    return "border-right:1px solid #E4E7ED;text-align: center";
  }
};
//无内容显示占位符
const formatterCellval = ({ row, column, cellValue, index }) => {
  return cellValue || "/";
};
export { setColumnDataColor, setCellStyle, formatterCellval };
