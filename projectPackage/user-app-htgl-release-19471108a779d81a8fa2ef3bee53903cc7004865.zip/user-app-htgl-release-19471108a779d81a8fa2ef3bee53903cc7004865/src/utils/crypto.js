import CryptoJS from "crypto-js";
import apiServe from "@/api/apiServe";

var KEY = ""; //密钥
// 获取密钥
export async function getCryptoKey() {
  let res = await apiServe.getSecretKey();
  if (res && res.data && res.data.code == 0) {
    let data = res.data.data || "";
    data = CryptoJS.enc.Utf8.parse(data);
    return data;
  }
}
// //加密数据
export async function encryptByAES(data) {
  KEY = await getCryptoKey();
  let encrypted = CryptoJS.AES.encrypt(JSON.stringify(data), KEY, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  });
  let encData = encrypted.ciphertext.toString();
  // let decryptData = await decryptByAES(encData, KEY);
  // console.log("加密结果", encData);
  // console.log("解密结果", decryptData);
  return encData;
}
//解密
export function decryptByAES(encData, key = KEY) {
  var encryptedHexStr = CryptoJS.enc.Hex.parse(encData);
  var encryptedBase64Str = CryptoJS.enc.Base64.stringify(encryptedHexStr);
  var decryptedData = CryptoJS.AES.decrypt(encryptedBase64Str, key, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  });
  var decryptedStr = decryptedData.toString(CryptoJS.enc.Utf8);
  decryptedStr = JSON.parse(decryptedStr);
  return decryptedStr;
}
// encryptByAES({id:454,name:'ndjgkh你的房间'});
