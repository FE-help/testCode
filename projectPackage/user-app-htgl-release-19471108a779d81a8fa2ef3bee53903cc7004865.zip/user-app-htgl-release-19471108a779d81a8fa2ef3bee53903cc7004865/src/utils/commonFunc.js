import qyfwAxios from "@/request/index.js";
/**
 * 下载文件
 * @param {String}} url 下载文件地址
 * @param {String}} name 下载文件名称
 */
export const downloadFile = async function(fileUrl, fileName) {
  if (!fileUrl) return;
  let res = await qyfwAxios({
    method: "get",
    url: fileUrl,
    responseType: "blob"
  });
  let newUrl = window.URL.createObjectURL(res.data);
  let a = document.createElement("a");
  a.href = newUrl;
  a.download = fileName;
  a.click();
  a.remove();
  //在资源下载完成后 可以人工清除createObjectURL 占用的缓存资源
  window.URL.revokeObjectURL(newUrl);
};
