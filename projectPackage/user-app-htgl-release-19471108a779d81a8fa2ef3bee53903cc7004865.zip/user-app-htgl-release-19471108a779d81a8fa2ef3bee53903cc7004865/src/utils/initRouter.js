let BaseRoutes = []
export const initRouter = async (router, menu, callback) => {

	let menus = await formatRoutes(menu)
	router.addRoutes(menus)
	router.options.routes = menus
	callback && callback()
}

export const formatRoutes = aMenu => {
	const aRouter = []
	aMenu.forEach(oMenu => {
		const {
			component,
			path,
			title,
			icon,
			name,
			display,
			children,
			id
		} = oMenu
		if (component) {
			const oRouter = {
				path: path,
				component: resolve =>
					component === 'BaseRouter'
						? import('@/components/public/BaseRouter.vue')
						: import(`@/views/${component}.vue`),
				meta: {
					isMenu: display,
					Title: title,
					id: id,
					componentPath: component
				},
				name: name,
				// icon: icon ? require(`@/assets/center/menuIcon/${icon}.png`) : '',
				children: children ? formatRoutes(children) : ''
			}
			aRouter.push(oRouter)
		}
	})
	return aRouter
}
