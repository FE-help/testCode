// 手机号验证
export const isPhoneNumber = val => {
  let reg = /^1(3|4|5|6|7|8|9)\d{9}$/;
  return reg.test(val);
};

// 电话号验证
export const contactNumberMesges = (rule, value, callback) => {
  const mobile = /^1(3|4|5|6|7|8|9)\d{9}$/;
  const phone = /^0\d{2,3}-?\d{7,8}$/;
  if (!value) {
    callback(new Error('请输入联系电话号码,或座机号码'));
  } else if (!phone.test(value) && !mobile.test(value)) {
    callback(new Error('请填写正确的手机号或座机号'));
  } else {
    callback();
  }
};
