import Vue from "vue";
// import UploadImg form "@/library/UploadImg/index.vue";
// import UploadImgMultiple form "@/library/UploadImgMultiple/index.vue";
// import DelConfirm form "@/library/DelConfirm/index.js"; //删除/上下架提示确认框
// import Venice form "@/library/Venice/index.vue"; //立即咨询按钮
// import NoneData form "@/library/NoneData/index.vue"; //暂无数据缺省页
// import Enquiry form "@/library/Enquiry/index.js"; //函询
// import FunConstruct form "@/library/FunConstruct/index.js"; //功能正在建设中弹窗
// import FocusOn form "@/library/focusOn/index.vue"; //企业服务关注按钮
// Vue.prototype.$htgl_delConfirm = DelConfirm;
// Vue.prototype.$htgl_enquiry = Enquiry;
// Vue.prototype.$htgl_funConstruct = FunConstruct;
// Vue.component(UploadImg.name, UploadImg);
// Vue.component(UploadImgMultiple.name, UploadImgMultiple);
// Vue.component(`htgl-${Venice.name}`, Venice);
// Vue.component(NoneData.name, NoneData);
// Vue.component(`HTGL${FocusOn.name}`, FocusOn);

// 删除挂载在Vue.prototype上的函数式组件
export function delVuePrototype() {
  // delete Vue.prototype.$htgl_delConfirm;
  // delete Vue.prototype.$htgl_enquiry;
  // delete Vue.prototype.$htglfunConstruct;
}
