<template>
  <!--XXX 各模块自己命名空间id-->
  <div id="htglApp">
    <keep-alive v-if="$route.meta.keepAlive">
      <router-view />
    </keep-alive>
    <router-view v-else />
    <ImChart></ImChart>
    <CompanyChart></CompanyChart>
  </div>
</template>

<style lang="scss">
@import "~@/styles/common";
</style>
<script>
import ImChart from "@/components/imChart/index";
import CompanyChart from "@/components/imChart/serviceList";
export default {
  components: { ImChart, CompanyChart },
  name: "app",
	// 使用reload刷新 在组件内 export default 下加入 inject: ['reload'],      使用 this.reload() 调用
	provide() {
		return {
			reload: this.reload
		};
	},
  created() {},
  methods:{
	  reload() {
		  this.isRouterAlive = false;
		  this.$nextTick(function() {
			  this.isRouterAlive = true;
		  });
	  },
  }
};
</script>
<style scoped>
  #htglApp{
    background-color: #ffffff;
  }
</style>
