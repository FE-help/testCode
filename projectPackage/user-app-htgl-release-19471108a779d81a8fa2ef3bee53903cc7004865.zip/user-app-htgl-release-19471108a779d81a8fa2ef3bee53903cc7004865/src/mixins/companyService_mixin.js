const companyService_mixin = {
  data() {
    return {
      isSubmit:false,//是否已经提交
    };
  },
  created() {
    this.isSubmit = false
  },
  beforeRouteLeave (to, from, next) {
    if (this.isSubmit) {
      next();
      return
    }
    this.$confirm('当前操作会丢失已填写的信息，确定是否继续？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }).then(() => {
      next();
      this.isSubmit = false
    }).catch(() => { 
      next(false)      
    });
  },
  methods: {
    handleCancel(path){
      this.isSubmit = true;
      this.$confirm('取消发布后，当前页面信息将丢失', '提示', {
        confirmButtonText: '确定取消发布',
        cancelButtonText: '不了，我再看看',
        type: 'warning'
      }).then(() => {
        path ? this.$router.push(path) : this.$router.go(-1)
      }).catch(() => {  
        this.isSubmit = false;       
      });
    }, 
  }
};
export {
  companyService_mixin
};
