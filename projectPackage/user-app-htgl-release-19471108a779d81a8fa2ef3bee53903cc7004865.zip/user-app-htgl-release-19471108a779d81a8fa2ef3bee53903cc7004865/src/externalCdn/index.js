/**
 * 修改本文件内容需要重新运行项目
 * */
const isProduction = process.env.NODE_ENV === 'production'
/**
 * @property {String} label - 标签名称
 * @property {String} label - js 插件的包名称
 * @property {String} scope - js 插件的暴露给window的名称
 * @property {Boolean} render - 是否渲染script标签，script 标签使用。有些情况我们需要webpack.config.externals 去匹配window 变量，但不需要加载script 标签。场景：主应用，子应用共用cdn 依赖时我们只需要挂载变量，不需要渲染script标签。子应用使用自有cdn 依赖时，我们需要挂载变量，并且渲染script 标签。
 * @property {String} props - 标签属性
 * @property {Boolean} props.ignore - 是否添加ignore 属性。qiankun微服务使用；https://juejin.cn/post/6856569463950639117#heading-15。如果和主应用复用公共依赖，加入此属性。
 * @property {String} content - 标签内部内容
 * */
const externalsData = [
  {
		label: 'script',
		name: 'crypto-js',
		scope: 'crypto-js',
		name: 'cryptoJs',
		scope: 'cryptoJs',
		props: { src: 'https://cdn.static.jingyingbang.com/web/libs/zjkj/spiderHack/spiderHack.umd.min.js' },
		content: ''
		}
  // {
  //   label: 'link',
  //   name: '',
  //   scope: '',
  //   props: { href: 'https://cdn.jsdelivr.net/npm/normalize.css@8.0.1/normalize.min.css', ignore: true },
  //   content: ''
  // },
  // {
  //   label: 'script',
  //   name: 'axios',
  //   scope: 'axios',
  //   render: false,
  //   props: {src: 'https://cdn.jsdelivr.net/npm/axios@0.21.1/dist/axios.min.js', ignore: true},
  //   content: ''
  // },
  // {
  //   label: 'script',
  //   name: 'vue',
  //   scope: 'Vue2',
  //   render: false,
  //   props: {
  //     src: isProduction ? 'https://cdn.jsdelivr.net/npm/vue@2.6.11/dist/vue.min.js' : 'https://cdn.jsdelivr.net/npm/vue@2.6.11/dist/vue.js',
  //     ignore: true
  //   },
  //   content: ''
  // },
  // {
  //   label: 'script',
  //   name: 'vue-router',
  //   scope: 'VueRouter',
  //   render: false,
  //   props: {
  //     src: isProduction ? 'https://cdn.jsdelivr.net/npm/vue-router@3.2.0/dist/vue-router.min.js' : 'https://cdn.jsdelivr.net/npm/vue-router@3.2.0/dist/vue-router.js',
  //     ignore: true
  //   },
  //   content: ''
  // },
  // {
  //   label: 'script',
  //   name: 'vuex',
  //   scope: 'Vuex',
  //   render: false,
  //   props: {
  //     src: isProduction ? 'https://cdn.jsdelivr.net/npm/vuex@3.4.0/dist/vuex.min.js' : 'https://cdn.jsdelivr.net/npm/vuex@3.4.0/dist/vuex.js',
  //     ignore: true
  //   },
  //   content: ''
  // },
  // {
  //   label: 'script',
  //   name: 'js-cookie',
  //   scope: 'Cookies',
  //   render: false,
  //   props: {
  //     src: isProduction ? 'https://cdn.jsdelivr.net/npm/js-cookie@3.0.0-rc.1/dist/js.cookie.min.js' : 'https://cdn.jsdelivr.net/npm/js-cookie@3.0.0-rc.1/dist/js.cookie.js',
  //     ignore: true
  //   },
  //   content: ''
  // },
  // {
  //   label: 'script',
  //   name: 'dayjs',
  //   scope: 'dayjs',
  //   render: false,
  //   props: {src: 'https://cdn.jsdelivr.net/npm/dayjs@1.10.4/dayjs.min.js', ignore: true},
  //   content: ''
  // },
  // {
  //   label: 'script',
  //   name: 'element-ui',
  //   scope: 'ELEMENT',
  //   render: false,
  //   props: {
  //     src: isProduction ? 'https://cdn.jsdelivr.net/npm/element-ui@2.15.0/lib/index.min.js' : 'https://cdn.jsdelivr.net/npm/element-ui@2.15.0/lib/index.js',
  //     ignore: true
  //   },
  //   content: ''
  // },
  // {
  //   label: 'link',
  //   name: '',
  //   scope: '',
  //   props: { href: 'https://cdn.jsdelivr.net/npm/element-ui@2.15.0/lib/theme-chalk/index.css', ignore: true },
  //   content: ''
  // }
]

module.exports.externalsData = externalsData


// 其他的external
const otherExternalsData = {
  'vue-quill-editor': 'VueQuillEditor', // 主应用已经引入
  axios: 'axios', // 主应用已经引入
  vue: 'Vue2', // 主应用已经引入
  'vue-router': 'VueRouter', // 主应用已经引入
  vuex: 'Vuex', // 主应用已经引入
  'js-cookie': 'Cookies', // 主应用已经引入
  dayjs: 'dayjs', // 主应用已经引入
  'element-ui': 'ELEMENT' // 主应用已经引入
}

// 获取configureWebpack -> config.externals 配置
exports.getExternalModules = () => {
  const externals = {} // 结果
  externalsData.forEach(item => {
    // 遍历配置
    if (item.name && item.scope) {
      externals[item.name] = item.scope
    }
  })
  return { ...externals, ...otherExternalsData }
}
