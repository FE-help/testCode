import "element-ui/lib/theme-chalk/index.css";
import "./public-path";
import Vue from "vue";
import App from "./App.vue";
import router from "./router/index.js";
import store from "./store";
import { setMainStoreProto, delMainStoreProto } from "@/utils/mainStore";
import { getAppRouter } from "@/api/apply";
import { HTGL_APP } from "@/app_config/applyName";
import mainBus from "@/microEventBus/mainBus";
import mainStore from "@/mainStore";
import { initRouter } from "@/utils/initRouter";
import { delVuePrototype } from "@/utils/library";
import "@/utils/commonContext";
import { Message } from "element-ui";
// import chatIm form "vue-chat-im";
// chatIm.mergeStore(store, router); //vuex 注册im模块
// Vue.use(chatIm);
Vue.config.productionTip = false;

let instance = null;

export async function bootstrap() {
  console.log("子应用--react app bootstraped");
}
//
async function render(props = {}) {
  if (props.mainStore.getters.isLogin) {
    await getAppRouter(HTGL_APP).then(res => {
      let { data, code, msg } = res.data;
      // if (code === 200) {
        initRouter(router, data, function() {});
      // } else {
      //   Message.warning(msg);
      // }
    });
  }
  const { container } = props;
  mainBus.setMainBus(props.mainAppBus);
  mainStore.setMainStore(props.mainStore);
  // 将主应用中的store指定的字段挂载到vue的原型上
  setMainStoreProto(props.mainStore);
  /**
   * 每个子应用 里 好像只能写一个onGlobalStateChange监听函数
   * */
  props.onGlobalStateChange((state, prev) => {
    // state: 变更后的状态; prev 变更前的状态
    console.log("---子应用main.js onGlobalStateChange", state);
  });
  instance = new Vue({
    router,
    store,
    render: h => h(App)
  }).$mount(container ? container.querySelector("#htglApp") : "#htglApp");
}

if (!window.__POWERED_BY_QIANKUN__) {
  render();
}

export async function mount(props) {
  render(props);
}

export async function unmount() {
  /**
   * 有时候`instance`不存在
   * */
  if (instance) {
    instance.$destroy();
    instance.$el.innerHTML = "";
    instance = null;
  }
  // 删除全局挂载的组件
  delVuePrototype();
  // 将主应用中的store指定的字段挂载到vue的原型上的属性删除
  delMainStoreProto();
}

/**
 * 可选生命周期钩子，仅使用 loadMicroApp 方式加载微应用时生效
 */
export async function update(props) {
  console.log("update props", props);
}
