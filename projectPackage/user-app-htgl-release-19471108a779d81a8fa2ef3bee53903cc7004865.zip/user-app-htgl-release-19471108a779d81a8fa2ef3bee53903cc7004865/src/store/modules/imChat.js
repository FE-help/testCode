const imChat = {
  strict: true,
  state: {
    chartsDialog: false,
    chartsCompany: {
      companyNo: "",
      companyName: ""
    },
    companyChartList: [],//企业客服列表
  },
  mutations: {
    // 企业咨询-选择客服弹框
    SET_CHARTSdIALOG(state, val) {
      state.chartsDialog = val;
    },
    SET_CHARTS_COMPANY(state, data) {
      state.chartsCompany = {
        companyNo: data.companyNo || "",
        companyName: data.companyName || ""
      };
    },
    // 保存企业客服列表
    SET_COMPANY_CHAT_LIST(state, data) {
      state.companyChartList = data;
    }
  },
  actions: {},
  getters: {}
};
export default imChat;
