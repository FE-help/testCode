import Vue from "vue";
import Vuex from "vuex";
Vue.use(Vuex);
//导入modules文件中的所有js
const files = require.context("./modules", false, /.js$/);
let storeMap = {};
files.keys().forEach(key => {
  let item = {};
  let itemKey = key.split(".js") || [];
  itemKey = itemKey[0].split("./") || [];
  itemKey = itemKey && itemKey.length > 1 ? itemKey[1] : "";
  item[itemKey] = files(key).default;
  item[itemKey] ? (storeMap = Object.assign(storeMap, item)) : "";
});
const store = new Vuex.Store({
  // modules: {
  //   user,
  //   common
  // },
  modules: storeMap,
  strict: process.env.NODE_ENV !== "production"
});

export default store;
