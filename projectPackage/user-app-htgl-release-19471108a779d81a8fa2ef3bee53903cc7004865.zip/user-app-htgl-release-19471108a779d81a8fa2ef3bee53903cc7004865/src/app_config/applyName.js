/**
 * 前端微服务应用名称
 *
 * */


export const MAIN_APP = 'main_app' // 主应用标识
export const HTGL_APP = 'jyb-app-htgl' // 合同管理 标识
