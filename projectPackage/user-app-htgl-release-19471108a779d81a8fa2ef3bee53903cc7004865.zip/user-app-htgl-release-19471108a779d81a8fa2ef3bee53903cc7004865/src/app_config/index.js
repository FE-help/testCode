// import * as applyName form './applyName';
const applyName = require('./applyName')

/**
 * @property {String} localAddress - 本地运行地址
 * */

module.exports = {
  // 物流服务
  [applyName.HTGL_APP]: {
    localAddress: ' http://localhost:9299'
  }
}

