module.exports = {
  // cookie过期时间 天
  tokenExpired: 14
}
