module.exports = {
  needKeyList: ["auth_user", "user", "token"] //需要从主应用的store中导入值的字段名
};
