const {
  externalsData,
  getExternalModules
} = require("./src/externalCdn/index.js");
const path = require("path");
// 代码压缩
const TerserPlugin = require("terser-webpack-plugin");
const CompressionWebpackPlugin = require("compression-webpack-plugin");
// 代码分析
const BundleAnalyzerPlugin = require("webpack-bundle-analyzer")
  .BundleAnalyzerPlugin;
const isProduction = process.env.NODE_ENV === "production";
const { title, publicPath } = require("./src/settings");
const packageName = require("./package.json").name;
function resolve(dir) {
  return path.join(__dirname, "./", dir);
}
module.exports = {
  publicPath: publicPath,
  assetsDir: "static",
  outputDir: "dist",
  productionSourceMap: !isProduction,
  parallel: require("os").cpus().length > 1,
  pages: {
    index: {
      // 入口
      entry: "src/main.js",
      // 模板来源
      template: "public/index.html",
      // 在 dist/index.html 的输出
      // filename: '../viewer/index.ejs',
      // 当使用 title 选项时，
      // template 中的 title 标签需要是 <title><%= htmlWebpackPlugin.options.title %></title>
      title: title,
      // 在这个页面中包含的块，默认情况下会包含
      // 提取出来的通用 chunk 和 vendor chunk。
      externalsData: externalsData
    }
  },
  devServer: {
    port: "9266",
    headers: {
      "Access-Control-Allow-Origin": "*"
    }
  },
  configureWebpack: config => {
    config.output.library = "jyb-app-htgl";
    config.output.libraryTarget = "umd";
    config.output.jsonpFunction = `webpackJsonp_${packageName}`;
    config.externals = {
      ...config.externals,
      ...getExternalModules()
    };
    const defaultPlugins = [];
    config.plugins = [...config.plugins, ...defaultPlugins];
    if (isProduction) {
      const plugins = [];
      // 代码压缩
      plugins.push(
        new CompressionWebpackPlugin({
          test: /\.js$|\.html$|.\css/, // 匹配文件名
          threshold: 10240, // 对超过10k的数据压缩
          deleteOriginalAssets: false // 不删除源文件
        })
      );

      config.plugins = [...config.plugins, ...plugins];
    } else {
      // 为开发环境修改配置...
    }
    // VUE_APP_CURRENT_MODE === 'production' 时使用的插件
    const proPlugins = [
      // 移除console.log
      new TerserPlugin({
        terserOptions: {
          warnings: false,
          compress: {
            drop_console: true,
            drop_debugger: true,
            pure_funcs: ["console.log"]
          },
          format: {
            comments: false // 去掉注释内容
          }
        },
        extractComments: false, //是否将注释剥离到单独的文件中
        sourceMap: false,
        parallel: true //使用多进程并发运行以提高构建速度
      })
    ];

    if (process.env.VUE_APP_CURRENT_MODE === "production") {
      config.plugins = [...config.plugins, ...proPlugins];
    }
  },
  chainWebpack: config => {
	  config.module
		  .rule('worker')
		  .test(/\.worker\.js$/)
		  .use('worker-loader').loader('worker-loader')
		  .options({
			  inline: true,
			  fallback: false
		  }).end();
    /**
     * 打包分析
     */
    if (process.env.IS_ANALYZ) {
      config.plugin("webpack-report").use(BundleAnalyzerPlugin, [
        {
          analyzerMode: "static"
        }
      ]);
    }
	  // 移除 preload 插件
	  config.plugins.delete('preload')
	  // 移除 prefetch 插件
	  config.plugins.delete('prefetch')
	  //config.plugins.delete('preload-${name}')//可配置移除预加载的页面。eg:login.html则添加config.plugins.delete('preload-login'),

    /**
     * 别名
     */
    config.resolve.alias.set("@", resolve("src"));
  },
  // css相关配置
  css: {
    // 是否使用css分离插件 ExtractTextPlugin
    // extract: false,
    // 开启 CSS source maps?
    // sourceMap: false,
    // css预设器配置项
    loaderOptions: {
      // pass options to sass-loader
      sass: {
        // 引入全局变量样式
        prependData: '@import "~@/styles/variables.scss";'
      }
    },
    // 启用 CSS modules for all css / pre-processor files.
    requireModuleExtension: true
  }
};
