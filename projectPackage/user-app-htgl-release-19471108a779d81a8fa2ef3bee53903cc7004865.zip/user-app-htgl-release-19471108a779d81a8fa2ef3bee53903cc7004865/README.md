# aquarius-web(水瓶座)

## Project setup
```
npm install
```

### 开发环境运行
```
npm run serve
```
### 生产环境运行
```
npm run serve:prod
```
### 预生产环境打包
```
npm run alpha
```
### 测试环境打包
```
npm run test
```
### 打包分析
```
npm run analyz
```
### 生产打包
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

### 代码风格
1. 页面名称、router path 使用**横线连接 (kebab-case)**

### 规范

#### css
项目通用全局css 命名空间：`am`

本项目全局css 命名空间： `co`

全局scss 变量命名空间：`$co`

### 插件
[dayjs](https://dayjs.gitee.io/zh-CN)/[dayjs 中文](https://dayjs.fenxianglu.cn/category/) - 日期格式化。

[qrcode](https://github.com/soldair/node-qrcode) - 二维码生成

[js-cookie](https://github.com/js-cookie/js-cookie) - cookie

lodash [中文](https://www.lodashjs.com/) [官网](https://lodash.com/)
